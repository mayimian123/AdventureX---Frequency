#!/usr/bin/env python3
"""
尝试添加地点定位字段到数据库表
"""

from supabase import create_client, Client

# Supabase配置
SUPABASE_URL = 'https://xyjsbpahmcisxvydbkxr.supabase.co'
SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh5anNicGFobWNpc3h2eWRia3hyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNjcwMDUsImV4cCI6MjA2ODk0MzAwNX0.DWMcfP28qQKCVmhJvrFyU1ROglbtKaPPRlQSPQemwTI'

def try_add_location_columns():
    """尝试通过SQL添加地点定位字段"""
    supabase = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)
    
    print("🔧 尝试添加地点定位字段到数据库...")
    
    # 要执行的SQL命令
    sql_commands = [
        """
        ALTER TABLE hz_coffee_chat_activities 
        ADD COLUMN IF NOT EXISTS location_name VARCHAR(255),
        ADD COLUMN IF NOT EXISTS latitude DECIMAL(10, 8),
        ADD COLUMN IF NOT EXISTS longitude DECIMAL(11, 8),
        ADD COLUMN IF NOT EXISTS place_id VARCHAR(255);
        """,
        """
        CREATE INDEX IF NOT EXISTS idx_hz_coffee_chat_activities_location 
        ON hz_coffee_chat_activities(latitude, longitude);
        """
    ]
    
    for i, sql in enumerate(sql_commands, 1):
        try:
            print(f"执行SQL命令 {i}...")
            response = supabase.rpc('exec', {'sql': sql}).execute()
            print(f"✅ SQL命令 {i} 执行成功")
        except Exception as e:
            print(f"❌ SQL命令 {i} 执行失败: {e}")
            # 如果RPC不可用，尝试其他方法
            return False
    
    return True

def create_basic_activities():
    """创建基础活动（不含地点定位信息）"""
    supabase = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)
    
    print("📝 创建基础活动（不含地点信息）...")
    
    from datetime import datetime, timezone, timedelta
    
    # 设置时区为中国时间 (UTC+8)
    china_tz = timezone(timedelta(hours=8))
    organizer_id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
    
    # 基础活动数据（不含地点字段）
    activities = [
        {
            'title': '周末咖啡交流会',
            'description': '在温馨的咖啡厅里，和同频的朋友分享生活中的小美好，交流工作心得，放松周末时光。地点：星巴克静安店（上海市静安区南京西路1168号）',
            'start_datetime': datetime(2025, 1, 28, 14, 0, 0, tzinfo=china_tz).isoformat(),
            'end_datetime': datetime(2025, 1, 28, 16, 0, 0, tzinfo=china_tz).isoformat(),
            'location_country': '国内',
            'location_province': '上海市',
            'location_city': '上海',
            'location_address': '上海市静安区南京西路1168号',
            'location_detailed_address': '星巴克静安店',
            'max_participants': 6,
            'current_participants': 1,
            'goal': '分享生活中的美好，交流工作心得，建立温暖的社交圈',
            'target_tags': ['生活分享', '工作交流', '咖啡', '周末时光', '社交'],
            'organizer_id': organizer_id,
            'status': 'recruiting'
        },
        {
            'title': '职场新人午餐聚会',
            'description': '刚入职场的小伙伴一起聚餐，分享求职经验，讨论职场生活，互相鼓励成长。地点：Costa咖啡人民广场店（上海市黄浦区南京东路299号）',
            'start_datetime': datetime(2025, 1, 30, 12, 0, 0, tzinfo=china_tz).isoformat(),
            'end_datetime': datetime(2025, 1, 30, 14, 0, 0, tzinfo=china_tz).isoformat(),
            'location_country': '国内',
            'location_province': '上海市',
            'location_city': '上海',
            'location_address': '上海市黄浦区南京东路299号',
            'location_detailed_address': 'Costa咖啡人民广场店',
            'max_participants': 8,
            'current_participants': 1,
            'goal': '职场新人互助，分享经验，建立职场社交网络',
            'target_tags': ['职场新人', '求职经验', '职场成长', '午餐聚会', '互助'],
            'organizer_id': organizer_id,
            'status': 'recruiting'
        },
        {
            'title': '创业者晚间交流',
            'description': '创业路上的朋友们聚在一起，分享创业心得，讨论商业想法，寻找合作机会。地点：WeWork静安寺店（上海市静安区愚园路68号）',
            'start_datetime': datetime(2025, 2, 1, 19, 0, 0, tzinfo=china_tz).isoformat(),
            'end_datetime': datetime(2025, 2, 1, 21, 0, 0, tzinfo=china_tz).isoformat(),
            'location_country': '国内',
            'location_province': '上海市',
            'location_city': '上海',
            'location_address': '上海市静安区愚园路68号',
            'location_detailed_address': 'WeWork静安寺店',
            'max_participants': 10,
            'current_participants': 1,
            'goal': '创业者交流心得，分享商业想法，寻找合作伙伴',
            'target_tags': ['创业', '商业', '合作', '晚间交流', '创新'],
            'organizer_id': organizer_id,
            'status': 'recruiting'
        }
    ]
    
    created_activities = []
    
    for i, activity in enumerate(activities, 1):
        try:
            print(f"  创建活动 {i}: {activity['title']}...")
            
            response = supabase.table('hz_coffee_chat_activities').insert(activity).execute()
            
            if response.data and len(response.data) > 0:
                created_activity = response.data[0]
                created_activities.append(created_activity)
                print(f"    ✅ 成功创建活动: {created_activity['id']}")
                print(f"    📍 地点: {activity['location_detailed_address']}")
                print(f"    📅 时间: {activity['start_datetime']}")
            else:
                print(f"    ❌ 创建活动失败，无返回数据")
                
        except Exception as e:
            print(f"    ❌ 创建活动 {activity['title']} 时出错: {e}")
    
    # 添加组织者参与记录
    if created_activities:
        print("👥 添加组织者参与记录...")
        for activity in created_activities:
            try:
                participant_data = {
                    'activity_id': activity['id'],
                    'user_id': organizer_id,
                    'status': 'confirmed',
                    'confirmed_at': datetime.now(timezone.utc).isoformat()
                }
                
                response = supabase.table('hz_activity_participants').insert(participant_data).execute()
                print(f"  ✅ 为活动 '{activity['title']}' 添加组织者参与记录")
            except Exception as e:
                print(f"  ❌ 为活动 '{activity['title']}' 添加参与记录时出错: {e}")
    
    print(f"✅ 成功创建 {len(created_activities)} 个基础活动！")
    return created_activities

def main():
    print("🚀 尝试解决数据库地点字段缺失问题")
    print("=" * 60)
    
    # 首先尝试添加字段
    if try_add_location_columns():
        print("✅ 成功添加地点字段，现在可以重新运行主脚本")
    else:
        print("⚠️ 无法通过代码添加地点字段")
        print("📝 将创建基础活动作为临时解决方案")
        
        # 创建基础活动
        activities = create_basic_activities()
        
        if activities:
            print("\n🎉 基础活动创建完成！")
            print("=" * 60)
            print("⚠️ 重要提醒：")
            print("  - 当前活动缺少地点定位字段（latitude, longitude）")
            print("  - 地点信息已包含在活动描述中")
            print("  - 距离筛选功能暂时无法使用")
            print("\n🔧 要启用完整的地点定位功能，需要：")
            print("  1. 在Supabase Dashboard的SQL编辑器中执行以下命令：")
            print("     ALTER TABLE hz_coffee_chat_activities ")
            print("     ADD COLUMN location_name VARCHAR(255),")
            print("     ADD COLUMN latitude DECIMAL(10, 8),")
            print("     ADD COLUMN longitude DECIMAL(11, 8),")
            print("     ADD COLUMN place_id VARCHAR(255);")
            print("\n  2. 然后重新运行完整的数据库重建脚本")
            print("\n🌐 现在可以测试基础功能：")
            print("  网站：https://jtd3iy3dwr9g.space.minimax.io")
            print("  账户：naovcaln@minimax.com / Jn3OLmh0xd")

if __name__ == "__main__":
    main()
