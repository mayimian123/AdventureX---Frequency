-- 创建测试用户（申请者）
INSERT INTO hz_users (
    id,
    auth_user_id,
    email,
    nickname,
    role,
    avatar_url,
    bio,
    tags,
    location_country,
    location_province,
    location_city,
    location_address,
    created_at,
    updated_at
) VALUES 
(
    'test-user-1',
    'test-auth-1',
    'zhangkaifa@test.com',
    '张开发',
    '前端工程师',
    '/avatars/avatar1.jpg',
    '5年前端开发经验，专注React和Vue技术栈',
    '["JavaScript", "React", "Vue", "前端开发"]',
    '国内',
    '北京市',
    '北京',
    '中关村',
    NOW(),
    NOW()
),
(
    'test-user-2',
    'test-auth-2',
    'lichanpin@test.com',
    '李产品',
    '产品经理',
    '/avatars/avatar2.jpg',
    '3年产品经验，熟悉B端和C端产品设计',
    '["产品设计", "用户体验", "项目管理"]',
    '国内',
    '北京市',
    '北京',
    '望京',
    NOW(),
    NOW()
);

-- 创建测试活动
INSERT INTO hz_coffee_chat_activities (
    id,
    title,
    organizer_id,
    description,
    start_datetime,
    end_datetime,
    location_country,
    location_province,
    location_city,
    location_address,
    location_detailed_address,
    max_participants,
    current_participants,
    goal,
    target_tags,
    status,
    created_at,
    updated_at
) VALUES 
(
    'test-activity-1',
    '测试删除功能 - Coffee Chat技术分享',
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    '这是一个用于测试删除和审核功能的Coffee Chat活动。可以在这里测试删除按钮和审核申请者功能。',
    '2025-07-26 14:00:00+00',
    '2025-07-26 16:00:00+00',
    '国内',
    '北京市',
    '北京',
    '中关村创业大街',
    'WeWork 3号楼',
    4,
    3,
    '测试系统功能，验证删除和审核流程',
    '["技术分享", "测试"]',
    'recruiting',
    NOW(),
    NOW()
),
(
    'test-activity-2',
    '创业交流 - 如何找到合适的联合创始人',
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    '和有创业想法的朋友一起讨论如何找到合适的合伙人，分享创业经验和教训。',
    '2025-07-28 19:00:00+00',
    '2025-07-28 21:00:00+00',
    '国内',
    '上海市',
    '上海',
    '陆家嘴金融中心',
    NULL,
    5,
    1,
    '建立创业者网络，分享创业经验',
    '["创业", "合伙人"]',
    'recruiting',
    NOW(),
    NOW()
);

-- 创建参与者记录
INSERT INTO hz_activity_participants (
    id,
    activity_id,
    user_id,
    status,
    applied_at,
    confirmed_at,
    what_to_bring,
    what_to_get,
    created_at
) VALUES 
-- 活动1的组织者参与记录
(
    'test-participant-1',
    'test-activity-1',
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    'confirmed',
    NOW(),
    NOW(),
    NULL,
    NULL,
    NOW()
),
-- 活动1的待审核申请者1
(
    'test-participant-2',
    'test-activity-1',
    'test-user-1',
    'pending',
    NOW(),
    NULL,
    '我能带来前端开发经验和项目案例分享，以及团队协作的实践经验',
    '希望学习后端技术和系统架构知识，了解全栈开发的最佳实践',
    NOW()
),
-- 活动1的待审核申请者2
(
    'test-participant-3',
    'test-activity-1',
    'test-user-2',
    'pending',
    NOW(),
    NULL,
    '产品设计思维和用户体验研究方法',
    '想了解技术实现的局限性，如何更好地与开发团队合作',
    NOW()
),
-- 活动2的组织者参与记录
(
    'test-participant-4',
    'test-activity-2',
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    'confirmed',
    NOW(),
    NOW(),
    NULL,
    NULL,
    NOW()
);
