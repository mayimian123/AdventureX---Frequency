-- 为测试用户创建Coffee Chat活动
INSERT INTO hz_coffee_chat_activities (
    id,
    title,
    organizer_id,
    description,
    start_datetime,
    end_datetime,
    location_country,
    location_province,
    location_city,
    location_address,
    max_participants,
    current_participants,
    goal,
    target_tags,
    status,
    created_at,
    updated_at
) VALUES (
    gen_random_uuid(),
    '测试删除功能 - Coffee Chat技术分享',
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', -- 测试用户ID
    '这是一个用于测试删除和审核功能的Coffee Chat活动',
    '2025-07-26 14:00:00+00',
    '2025-07-26 16:00:00+00',
    '国内',
    '北京市',
    '北京',
    '中关村创业大街',
    4,
    1,
    '测试系统功能',
    '["技术分享", "测试"]',
    'recruiting',
    NOW(),
    NOW()
);

-- 添加组织者参与记录
INSERT INTO hz_activity_participants (
    id,
    activity_id,
    user_id,
    status,
    applied_at,
    confirmed_at,
    created_at
) VALUES (
    gen_random_uuid(),
    (SELECT id FROM hz_coffee_chat_activities WHERE title = '测试删除功能 - Coffee Chat技术分享' LIMIT 1),
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    'confirmed',
    NOW(),
    NOW(),
    NOW()
);

-- 创建一个模拟申请者（用于测试审核功能）
INSERT INTO hz_activity_participants (
    id,
    activity_id,
    user_id,
    status,
    applied_at,
    what_to_bring,
    what_to_get,
    created_at
) VALUES (
    gen_random_uuid(),
    (SELECT id FROM hz_coffee_chat_activities WHERE title = '测试删除功能 - Coffee Chat技术分享' LIMIT 1),
    'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', -- 假设的申请者ID
    'pending',
    NOW(),
    '我能带来前端开发经验和项目案例分享',
    '希望学习后端技术和系统架构知识',
    NOW()
);
