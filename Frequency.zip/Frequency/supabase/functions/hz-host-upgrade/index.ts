const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
};

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        // 获取请求数据
        const requestData = await req.json();
        const { action } = requestData;

        // 获取认证信息
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('未提供认证信息');
        }

        const token = authHeader.replace('Bearer ', '');
        
        // 获取环境变量
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase 配置缺失');
        }

        // 验证token并获取用户信息
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('认证失败，请重新登录');
        }

        const userData = await userResponse.json();
        const userId = userData.id;
        const userEmail = userData.email;

        console.log('VIP subscription request:', { action, userId });

        // 根据action处理不同的请求
        switch (action) {
            case 'check_vip_status': {
                // 检查用户VIP状态
                const checkStatusResponse = await fetch(`${supabaseUrl}/rest/v1/rpc/check_vip_subscription_status`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ user_uuid: userId })
                });

                if (!checkStatusResponse.ok) {
                    throw new Error('查询VIP状态失败');
                }

                const statusResult = await checkStatusResponse.json();
                const vipStatus = statusResult[0] || {
                    is_vip: false,
                    subscription_type: null,
                    activities_remaining: 0,
                    expires_at: null
                };

                return new Response(JSON.stringify({
                    data: {
                        isVip: vipStatus.is_vip,
                        subscriptionType: vipStatus.subscription_type,
                        activitiesRemaining: vipStatus.activities_remaining,
                        expiresAt: vipStatus.expires_at
                    }
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
            }

            case 'get_vip_packages': {
                // 获取VIP套餐列表
                const packagesResponse = await fetch(`${supabaseUrl}/rest/v1/hz_vip_packages?is_active=eq.true&order=price.asc`, {
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    }
                });

                if (!packagesResponse.ok) {
                    throw new Error('获取VIP套餐失败');
                }

                const packages = await packagesResponse.json();

                return new Response(JSON.stringify({
                    data: { packages }
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
            }

            case 'create_subscription_checkout': {
                // 创建Stripe订阅支付会话
                const { packageType } = requestData;

                if (!stripeSecretKey) {
                    throw new Error('Stripe配置缺失，暂时无法处理支付');
                }

                // 获取套餐信息
                const packageResponse = await fetch(`${supabaseUrl}/rest/v1/hz_vip_packages?package_type=eq.${packageType}&is_active=eq.true`, {
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    }
                });

                if (!packageResponse.ok) {
                    throw new Error('获取套餐信息失败');
                }

                const packages = await packageResponse.json();
                if (packages.length === 0) {
                    throw new Error('无效的套餐类型');
                }

                const packageInfo = packages[0];

                // 创建Stripe Checkout Session
                const checkoutSession = await fetch('https://api.stripe.com/v1/checkout/sessions', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${stripeSecretKey}`,
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        'mode': 'subscription',
                        'customer_email': userEmail,
                        'success_url': `${req.headers.get('origin') || 'https://sv482gregeq6.space.minimax.io'}?vip_subscription=success&session_id={CHECKOUT_SESSION_ID}`,
                        'cancel_url': `${req.headers.get('origin') || 'https://sv482gregeq6.space.minimax.io'}?vip_subscription=cancelled`,
                        'line_items[0][price_data][currency]': packageInfo.currency.toLowerCase(),
                        'line_items[0][price_data][product_data][name]': packageInfo.name,
                        'line_items[0][price_data][product_data][description]': packageInfo.description,
                        'line_items[0][price_data][unit_amount]': (packageInfo.price * 100).toString(),
                        'line_items[0][price_data][recurring][interval]': packageType.includes('monthly') ? 'month' : packageType.includes('quarterly') ? 'month' : 'year',
                        'line_items[0][price_data][recurring][interval_count]': packageType.includes('quarterly') ? '3' : '1',
                        'line_items[0][quantity]': '1',
                        'metadata[user_id]': userId,
                        'metadata[package_type]': packageType,
                        'metadata[package_id]': packageInfo.id
                    })
                });

                if (!checkoutSession.ok) {
                    const errorText = await checkoutSession.text();
                    console.error('Stripe checkout error:', errorText);
                    throw new Error('创建支付会话失败');
                }

                const sessionData = await checkoutSession.json();

                return new Response(JSON.stringify({
                    data: {
                        checkoutUrl: sessionData.url,
                        sessionId: sessionData.id
                    }
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
            }

            case 'handle_subscription_success': {
                // 处理订阅成功后的逻辑
                const { sessionId } = requestData;

                if (!stripeSecretKey || !sessionId) {
                    throw new Error('参数缺失');
                }

                // 从Stripe获取会话信息
                const sessionResponse = await fetch(`https://api.stripe.com/v1/checkout/sessions/${sessionId}`, {
                    headers: {
                        'Authorization': `Bearer ${stripeSecretKey}`
                    }
                });

                if (!sessionResponse.ok) {
                    throw new Error('验证支付会话失败');
                }

                const sessionData = await sessionResponse.json();
                const { metadata, subscription: stripeSubscriptionId, amount_total } = sessionData;

                // 激活VIP订阅
                const activateResponse = await fetch(`${supabaseUrl}/rest/v1/rpc/activate_vip_subscription`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        user_uuid: userId,
                        subscription_type_param: metadata.package_type,
                        stripe_subscription_id_param: stripeSubscriptionId,
                        payment_amount: amount_total / 100 // Stripe以分为单位
                    })
                });

                if (!activateResponse.ok) {
                    const errorText = await activateResponse.text();
                    throw new Error(`激活VIP订阅失败: ${errorText}`);
                }

                return new Response(JSON.stringify({
                    data: {
                        success: true,
                        message: '🎉 恭喜成为赫兹VIP主理人！现在您可以创建专属的Coffee Chat活动了！',
                        subscriptionType: metadata.package_type
                    }
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
            }

            default:
                throw new Error('无效的操作类型');
        }

    } catch (error) {
        console.error('VIP subscription error:', error);

        const errorResponse = {
            error: {
                code: 'VIP_SUBSCRIPTION_ERROR',
                message: error.message || 'VIP订阅处理失败，请稍后重试'
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});