/**
 * Hz Coffee Chat Location Service
 * 处理地理位置相关的功能
 */

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const requestData = await req.json();
        console.log('Location service request:', requestData);
        
        const { action, ...params } = requestData;

        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        console.log('Supabase config:', { supabaseUrl: !!supabaseUrl, serviceRoleKey: !!serviceRoleKey });

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        let result;

        console.log('Executing action:', action, 'with params:', params);

        switch (action) {
            case 'cache_user_location':
                result = await cacheUserLocation(supabaseUrl, serviceRoleKey, params);
                break;
            case 'get_user_location':
                result = await getUserLocation(supabaseUrl, serviceRoleKey, params);
                break;
            case 'get_activities_with_distance':
                result = await getActivitiesWithDistance(supabaseUrl, serviceRoleKey, params);
                break;
            case 'cleanup_expired_cache':
                result = await cleanupExpiredCache(supabaseUrl, serviceRoleKey);
                break;
            case 'search_places':
                result = await searchPlaces(params);
                break;
            case 'get_place_details':
                result = await getPlaceDetails(params);
                break;
            case 'reverse_geocode':
                result = await reverseGeocode(params);
                break;
            default:
                throw new Error(`Unknown action: ${action}`);
        }

        return new Response(JSON.stringify(result), {
            status: 200,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Location service error:', error);
        return new Response(JSON.stringify({ 
            error: error.message,
            details: error.toString()
        }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

// 缓存用户位置
async function cacheUserLocation(supabaseUrl, serviceRoleKey, params) {
    const { userId, latitude, longitude, address, city } = params;

    console.log('Caching user location:', { userId, latitude, longitude, address, city });

    const cacheResponse = await fetch(`${supabaseUrl}/rest/v1/rpc/upsert_user_location`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            p_user_id: userId,
            p_latitude: latitude,
            p_longitude: longitude,
            p_address: address,
            p_city: city
        })
    });

    if (!cacheResponse.ok) {
        const errorText = await cacheResponse.text();
        console.error('Failed to cache user location:', errorText);
        throw new Error('Failed to cache user location: ' + errorText);
    }

    console.log('User location cached successfully');

    return {
        success: true,
        message: 'Location cached successfully',
        cached_at: new Date().toISOString()
    };
}

// 获取用户缓存的位置
async function getUserLocation(supabaseUrl, serviceRoleKey, params) {
    const { userId } = params;

    console.log('Getting user cached location for:', userId);

    const locationResponse = await fetch(
        `${supabaseUrl}/rest/v1/hz_user_location_cache?user_id=eq.${userId}&select=*`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    if (!locationResponse.ok) {
        const errorText = await locationResponse.text();
        console.error('Failed to get user location:', errorText);
        throw new Error('Failed to get user location: ' + errorText);
    }

    const locations = await locationResponse.json();
    console.log('User location query result:', locations);

    if (locations.length === 0) {
        return {
            success: false,
            message: 'No cached location found',
            location: null
        };
    }

    const location = locations[0];
    const now = new Date();
    const updatedAt = new Date(location.updated_at);
    const ageHours = (now.getTime() - updatedAt.getTime()) / (1000 * 60 * 60);

    // 检查缓存是否过期（2小时）
    if (ageHours > 2) {
        console.log('Cached location expired, age:', ageHours, 'hours');
        return {
            success: false,
            message: 'Cached location expired',
            location: null,
            expired: true
        };
    }

    return {
        success: true,
        location: {
            latitude: parseFloat(location.latitude),
            longitude: parseFloat(location.longitude),
            address: location.address,
            city: location.city,
            cached_at: location.updated_at,
            age_hours: ageHours
        }
    };
}

// 获取带距离的活动列表
async function getActivitiesWithDistance(supabaseUrl, serviceRoleKey, params) {
    const { userLatitude, userLongitude, maxDistanceKm } = params;

    console.log('Getting activities with distance:', { userLatitude, userLongitude, maxDistanceKm });

    const functionResponse = await fetch(`${supabaseUrl}/rest/v1/rpc/get_activities_with_distance`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            user_lat: userLatitude,
            user_lng: userLongitude,
            max_distance_km: maxDistanceKm || null
        })
    });

    if (!functionResponse.ok) {
        const errorText = await functionResponse.text();
        console.error('Failed to get activities with distance:', errorText);
        throw new Error('Failed to get activities with distance: ' + errorText);
    }

    const activities = await functionResponse.json();
    console.log('Activities with distance result count:', activities.length);

    // 格式化距离显示
    const formattedActivities = activities.map(activity => ({
        ...activity,
        distance_km: activity.distance_km ? parseFloat(activity.distance_km) : null,
        distance_display: formatDistance(activity.distance_km)
    }));

    return {
        success: true,
        activities: formattedActivities,
        user_location: {
            latitude: userLatitude,
            longitude: userLongitude
        },
        filter: {
            max_distance_km: maxDistanceKm
        }
    };
}

// 清理过期缓存
async function cleanupExpiredCache(supabaseUrl, serviceRoleKey) {
    console.log('Cleaning up expired location cache...');

    const cleanupResponse = await fetch(`${supabaseUrl}/rest/v1/rpc/cleanup_expired_location_cache`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json'
        }
    });

    if (!cleanupResponse.ok) {
        const errorText = await cleanupResponse.text();
        console.error('Failed to cleanup expired cache:', errorText);
        throw new Error('Failed to cleanup expired cache: ' + errorText);
    }

    const deletedCount = await cleanupResponse.json();
    console.log('Cleaned up expired cache, deleted:', deletedCount, 'records');

    return {
        success: true,
        deleted_count: deletedCount,
        cleaned_at: new Date().toISOString()
    };
}

// Google Places API - 搜索地点
async function searchPlaces(params) {
    const { query, latitude, longitude, radius = 5000 } = params;
    
    console.log('Searching places:', { query, latitude, longitude, radius });

    // 这里需要使用Google Places API
    // 暂时返回模拟数据，实际实现时需要调用Google API
    const mockPlaces = [
        {
            place_id: 'ChIJN1t_tDeuEmsRUsoyG83frY4',
            name: '星巴克静安店',
            address: '上海市静安区南京西路1376号',
            location: {
                lat: 31.2304,
                lng: 121.4737
            },
            types: ['cafe', 'establishment'],
            rating: 4.2,
            price_level: 2
        },
        {
            place_id: 'ChIJrTLr-GyuEmsRBfy61i59si0',
            name: 'Costa咖啡南京路店',
            address: '上海市黄浦区南京东路353号',
            location: {
                lat: 31.2317,
                lng: 121.4789
            },
            types: ['cafe', 'establishment'],
            rating: 4.0,
            price_level: 2
        }
    ];

    // 如果有坐标，计算距离
    if (latitude && longitude) {
        mockPlaces.forEach(place => {
            const distance = calculateDistanceJS(
                latitude, longitude,
                place.location.lat, place.location.lng
            );
            place.distance_km = distance;
            place.distance_display = formatDistance(distance);
        });
        
        // 按距离排序
        mockPlaces.sort((a, b) => (a.distance_km || 999) - (b.distance_km || 999));
    }

    return {
        success: true,
        places: mockPlaces,
        query: query
    };
}

// 获取地点详情
async function getPlaceDetails(params) {
    const { placeId } = params;
    
    console.log('Getting place details for:', placeId);

    // 模拟地点详情
    const mockPlaceDetails = {
        place_id: placeId,
        name: '星巴克静安店',
        address: '上海市静安区南京西路1376号',
        formatted_address: '上海市静安区南京西路1376号',
        location: {
            lat: 31.2304,
            lng: 121.4737
        },
        types: ['cafe', 'establishment'],
        rating: 4.2,
        price_level: 2,
        opening_hours: {
            open_now: true,
            weekday_text: [
                '周一: 07:00 - 22:00',
                '周二: 07:00 - 22:00',
                '周三: 07:00 - 22:00',
                '周四: 07:00 - 22:00',
                '周五: 07:00 - 22:00',
                '周六: 07:00 - 22:00',
                '周日: 07:00 - 22:00'
            ]
        },
        phone: '+86 21-1234-5678',
        website: 'https://www.starbucks.com.cn'
    };

    return {
        success: true,
        place: mockPlaceDetails
    };
}

// 反向地理编码
async function reverseGeocode(params) {
    const { latitude, longitude } = params;
    
    console.log('Reverse geocoding:', { latitude, longitude });

    // 模拟反向地理编码结果
    const mockResult = {
        formatted_address: '上海市静安区南京西路1376号',
        address_components: [
            { long_name: '1376', short_name: '1376', types: ['street_number'] },
            { long_name: '南京西路', short_name: '南京西路', types: ['route'] },
            { long_name: '静安区', short_name: '静安区', types: ['sublocality'] },
            { long_name: '上海市', short_name: '上海', types: ['locality'] },
            { long_name: '中国', short_name: 'CN', types: ['country'] }
        ],
        location: {
            lat: latitude,
            lng: longitude
        }
    };

    return {
        success: true,
        result: mockResult
    };
}

// JavaScript距离计算函数（Haversine公式）
function calculateDistanceJS(lat1, lng1, lat2, lng2) {
    const R = 6371; // 地球半径（公里）
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
}

// 格式化距离显示
function formatDistance(distanceKm) {
    if (!distanceKm) return null;
    
    const distance = parseFloat(distanceKm);
    
    if (distance < 1) {
        return `${Math.round(distance * 1000)}米`;
    } else if (distance < 10) {
        return `${distance.toFixed(1)}公里`;
    } else {
        return `${Math.round(distance)}公里`;
    }
}
