Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { imageData, fileName, userId } = await req.json();

        if (!imageData || !fileName || !userId) {
            throw new Error('Image data, filename, and user ID are required');
        }

        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // 提取base64数据
        const base64Data = imageData.split(',')[1];
        const mimeType = imageData.split(';')[0].split(':')[1];

        // 转换为二进制数据
        const binaryData = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0));

        // 生成唯一文件名
        const timestamp = Date.now();
        const fileExtension = fileName.split('.').pop();
        const uniqueFileName = `avatar_${userId}_${timestamp}.${fileExtension}`;

        // 上传到Supabase Storage
        const uploadResponse = await fetch(`${supabaseUrl}/storage/v1/object/hz-avatars/${uniqueFileName}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'Content-Type': mimeType,
                'x-upsert': 'true'
            },
            body: binaryData
        });

        if (!uploadResponse.ok) {
            const errorText = await uploadResponse.text();
            throw new Error(`Upload failed: ${errorText}`);
        }

        // 获取公开URL
        const publicUrl = `${supabaseUrl}/storage/v1/object/public/hz-avatars/${uniqueFileName}`;

        // 更新用户头像
        const updateUserResponse = await fetch(`${supabaseUrl}/rest/v1/hz_users?auth_user_id=eq.${userId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                avatar_url: publicUrl,
                updated_at: new Date().toISOString()
            })
        });

        if (!updateUserResponse.ok) {
            const errorText = await updateUserResponse.text();
            throw new Error(`Failed to update user avatar: ${errorText}`);
        }

        const updatedUser = await updateUserResponse.json();

        return new Response(JSON.stringify({
            data: {
                avatar_url: publicUrl,
                user: updatedUser[0]
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Avatar upload error:', error);
        
        const errorResponse = {
            error: {
                code: 'AVATAR_UPLOAD_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});