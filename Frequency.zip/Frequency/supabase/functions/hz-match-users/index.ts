Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { userId } = await req.json();

        if (!userId) {
            throw new Error('User ID is required');
        }

        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // 获取当前用户信息
        const currentUserResponse = await fetch(`${supabaseUrl}/rest/v1/hz_users?id=eq.${userId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });

        if (!currentUserResponse.ok) {
            throw new Error('Failed to fetch current user');
        }

        const currentUserData = await currentUserResponse.json();
        if (!currentUserData || currentUserData.length === 0) {
            throw new Error('Current user not found');
        }

        const currentUser = currentUserData[0];

        // 获取所有其他用户
        const usersResponse = await fetch(`${supabaseUrl}/rest/v1/hz_users?id=neq.${userId}&is_profile_complete=eq.true`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });

        if (!usersResponse.ok) {
            throw new Error('Failed to fetch users');
        }

        const users = await usersResponse.json();

        // 计算匹配度算法
        const calculateMatchScore = (user1, user2) => {
            let score = 0;
            
            // 兴趣标签重叠度 (40%)
            const tags1 = user1.interest_tags || [];
            const tags2 = user2.interest_tags || [];
            const commonTags = tags1.filter(tag => tags2.includes(tag));
            const totalTags = new Set([...tags1, ...tags2]).size;
            const tagScore = totalTags > 0 ? (commonTags.length / totalTags) * 40 : 0;
            
            // 城市距离 (20%) - 同城得满分
            const cityScore = user1.location_city === user2.location_city ? 20 : 
                             user1.location_province === user2.location_province ? 10 : 0;
            
            // 专业领域关联 (20%)
            const fields1 = user1.professional_fields || [];
            const fields2 = user2.professional_fields || [];
            const commonFields = fields1.filter(field => fields2.includes(field));
            const totalFields = new Set([...fields1, ...fields2]).size;
            const fieldScore = totalFields > 0 ? (commonFields.length / totalFields) * 20 : 0;
            
            // 年龄互动潜力 (20%) - 年龄差距越小分数越高
            const ageDiff = Math.abs(user1.age - user2.age);
            const ageScore = Math.max(0, 20 - ageDiff * 2);
            
            score = Math.round(tagScore + cityScore + fieldScore + ageScore);
            return Math.min(100, Math.max(1, score));
        };

        // 计算所有用户的匹配度
        const matches = users.map(user => ({
            user,
            score: calculateMatchScore(currentUser, user)
        }));

        // 按匹配度排序显示所有用户（不再过滤）
        const allMatches = matches
            .sort((a, b) => b.score - a.score);

        // 保存匹配结果到数据库
        for (const match of allMatches) {
            const existingMatchResponse = await fetch(
                `${supabaseUrl}/rest/v1/hz_matches?user1_id=eq.${userId}&user2_id=eq.${match.user.id}`,
                {
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey
                    }
                }
            );

            const existingMatches = await existingMatchResponse.json();
            
            if (!existingMatches || existingMatches.length === 0) {
                await fetch(`${supabaseUrl}/rest/v1/hz_matches`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        user1_id: userId,
                        user2_id: match.user.id,
                        match_score: match.score
                    })
                });
            }
        }

        return new Response(JSON.stringify({
            data: {
                matches: allMatches,
                total_count: allMatches.length
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Match users error:', error);
        
        const errorResponse = {
            error: {
                code: 'MATCH_USERS_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});