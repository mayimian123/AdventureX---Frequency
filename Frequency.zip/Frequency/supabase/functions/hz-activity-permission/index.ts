const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
};

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        // 获取请求数据
        const requestData = await req.json();
        const { action } = requestData;

        // 获取认证信息
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('未提供认证信息');
        }

        const token = authHeader.replace('Bearer ', '');
        
        // 获取环境变量
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase 配置缺失');
        }

        // 验证token并获取用户信息
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('认证失败，请重新登录');
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        console.log('Activity permission request:', { action, userId });

        // 根据action处理不同的请求
        switch (action) {
            case 'check_create_permission': {
                // 所有已登录用户都可以免费创建活动
                // 不再检查VIP状态，直接返回允许创建
                return new Response(JSON.stringify({
                    data: {
                        canCreate: true,
                        reason: 'free_for_all',
                        message: '您可以免费创建 Coffee Chat 活动，连接志同道合的朋友！'
                    }
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
            }

            case 'consume_activity_quota': {
                // 消费一次VIP活动额度（仅适用于VIP用户的额外功能）
                const { activityId } = requestData;

                if (!activityId) {
                    throw new Error('活动ID是必需的');
                }

                // 检查活动是否存在且属于该用户
                const activityResponse = await fetch(`${supabaseUrl}/rest/v1/hz_coffee_chat_activities?id=eq.${activityId}&select=organizer_id`, {
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    }
                });

                if (!activityResponse.ok) {
                    throw new Error('查询活动信息失败');
                }

                const activities = await activityResponse.json();
                if (activities.length === 0) {
                    throw new Error('活动不存在');
                }

                if (activities[0].organizer_id !== userId) {
                    throw new Error('无权操作此活动');
                }

                // 检查是否已经消费过额度
                const transactionResponse = await fetch(`${supabaseUrl}/rest/v1/hz_credit_transactions?user_id=eq.${userId}&type=eq.activity_creation&description=like.*${activityId}*`, {
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    }
                });

                if (transactionResponse.ok) {
                    const transactions = await transactionResponse.json();
                    if (transactions.length > 0) {
                        return new Response(JSON.stringify({
                            data: {
                                success: true,
                                message: 'VIP活动额度已消费',
                                alreadyConsumed: true
                            }
                        }), {
                            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                        });
                    }
                }

                // 调用数据库函数消费活动额度（仅针对VIP用户）
                const consumeResponse = await fetch(`${supabaseUrl}/rest/v1/rpc/consume_activity_quota`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ user_uuid: userId })
                });

                if (!consumeResponse.ok) {
                    const errorText = await consumeResponse.text();
                    throw new Error(`消费VIP额度失败: ${errorText}`);
                }

                const consumeResult = await consumeResponse.json();

                if (!consumeResult) {
                    // 非VIP用户也可以创建活动，只是不消费VIP额度
                    return new Response(JSON.stringify({
                        data: {
                            success: true,
                            message: '活动创建成功',
                            isVipUser: false
                        }
                    }), {
                        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                    });
                }

                return new Response(JSON.stringify({
                    data: {
                        success: true,
                        message: '成功消费VIP活动额度',
                        quotaConsumed: 1
                    }
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
            }

            case 'get_activity_stats': {
                // 获取用户活动统计信息
                const vipStatusResponse = await fetch(`${supabaseUrl}/rest/v1/rpc/check_vip_subscription_status`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ user_uuid: userId })
                });

                if (!vipStatusResponse.ok) {
                    throw new Error('查询VIP状态失败');
                }

                const vipResult = await vipStatusResponse.json();
                const vipInfo = vipResult[0] || {
                    is_vip: false,
                    subscription_type: null,
                    activities_remaining: 0,
                    expires_at: null
                };

                // 获取用户创建的活动数量
                const activitiesResponse = await fetch(`${supabaseUrl}/rest/v1/hz_coffee_chat_activities?organizer_id=eq.${userId}&select=id`, {
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    }
                });

                let totalActivities = 0;
                if (activitiesResponse.ok) {
                    const activities = await activitiesResponse.json();
                    totalActivities = activities.length;
                }

                return new Response(JSON.stringify({
                    data: {
                        isVip: vipInfo.is_vip,
                        subscriptionType: vipInfo.subscription_type,
                        activitiesRemaining: vipInfo.activities_remaining,
                        expiresAt: vipInfo.expires_at,
                        totalActivitiesCreated: totalActivities
                    }
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
            }

            default:
                throw new Error('无效的操作类型');
        }

    } catch (error) {
        console.error('Activity permission error:', error);

        const errorResponse = {
            error: {
                code: 'ACTIVITY_PERMISSION_ERROR',
                message: error.message || '活动权限检查失败，请稍后重试'
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});