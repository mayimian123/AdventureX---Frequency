Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const requestData = await req.json();
        console.log('发送消息请求:', requestData);
        
        const { senderId, receiverId, content, messageType = 'text' } = requestData;

        // 验证必要参数
        if (!senderId || !receiverId || !content) {
            throw new Error('发送者ID、接收者ID和消息内容都是必需的');
        }

        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        console.log('Supabase配置:', { supabaseUrl: !!supabaseUrl, serviceRoleKey: !!serviceRoleKey });

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // 检查或创建对话
        let conversationId;
        
        // 查找现有对话
        const findConversationResponse = await fetch(
            `${supabaseUrl}/rest/v1/hz_conversations?or=(and(participant1_id.eq.${senderId},participant2_id.eq.${receiverId}),and(participant1_id.eq.${receiverId},participant2_id.eq.${senderId}))`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            }
        );

        if (!findConversationResponse.ok) {
            const errorText = await findConversationResponse.text();
            console.error('查找对话失败:', errorText);
            throw new Error('Failed to find conversation: ' + errorText);
        }

        const existingConversations = await findConversationResponse.json();
        console.log('现有对话:', existingConversations);

        if (existingConversations && existingConversations.length > 0) {
            conversationId = existingConversations[0].id;
            console.log('使用现有对话:', conversationId);
        } else {
            // 创建新对话
            console.log('创建新对话');
            const createConversationResponse = await fetch(`${supabaseUrl}/rest/v1/hz_conversations`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=representation'
                },
                body: JSON.stringify({
                    participant1_id: senderId,
                    participant2_id: receiverId,
                    last_message_at: new Date().toISOString()
                })
            });

            if (!createConversationResponse.ok) {
                const errorText = await createConversationResponse.text();
                console.error('创建对话失败:', errorText);
                throw new Error('Failed to create conversation: ' + errorText);
            }

            const newConversation = await createConversationResponse.json();
            conversationId = newConversation[0].id;
            console.log('新对话创建成功:', conversationId);
        }

        // 创建消息
        const messageData = {
            conversation_id: conversationId,
            sender_id: senderId,
            content: content.trim(),
            message_type: messageType,
            is_read: false,
            created_at: new Date().toISOString()
        };

        console.log('创建消息数据:', messageData);

        const createMessageResponse = await fetch(`${supabaseUrl}/rest/v1/hz_messages`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify(messageData)
        });

        if (!createMessageResponse.ok) {
            const errorText = await createMessageResponse.text();
            console.error('创建消息失败:', errorText);
            throw new Error('Failed to create message: ' + errorText);
        }

        const message = await createMessageResponse.json();
        console.log('消息创建成功:', message[0]);

        // 更新对话的最后消息时间
        const updateConversationResponse = await fetch(`${supabaseUrl}/rest/v1/hz_conversations?id=eq.${conversationId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                last_message_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            })
        });

        if (!updateConversationResponse.ok) {
            console.error('更新对话时间失败:', await updateConversationResponse.text());
            // 不抛出错误，因为消息已经成功创建
        } else {
            console.log('对话时间更新成功');
        }

        const result = {
            message: message[0],
            conversationId: conversationId
        };

        console.log('消息发送完成:', result);

        return new Response(JSON.stringify({ data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('发送消息错误:', error);
        
        const errorResponse = {
            error: {
                code: 'SEND_MESSAGE_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});