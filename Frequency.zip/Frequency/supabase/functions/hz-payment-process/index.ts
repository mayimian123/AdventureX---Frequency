import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3'
import Stripe from 'https://esm.sh/stripe@14.14.0'

interface PaymentRequest {
  action: 'create_payment_intent' | 'confirm_payment' | 'get_packages'
  userId?: string
  packageId?: string
  paymentIntentId?: string
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
  'Access-Control-Max-Age': '86400',
  'Access-Control-Allow-Credentials': 'false'
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') ?? '', {
      apiVersion: '2023-10-16'
    })

    const { action, userId, packageId, paymentIntentId }: PaymentRequest = await req.json()

    console.log('Payment request:', { action, userId, packageId, paymentIntentId })

    switch (action) {
      case 'get_packages': {
        // 获取积分套餐列表
        const { data: packages, error } = await supabaseClient
          .from('hz_credit_packages')
          .select('*')
          .eq('is_active', true)
          .order('sort_order')

        if (error) {
          throw new Error(`Failed to get packages: ${error.message}`)
        }

        return new Response(JSON.stringify({ data: packages }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
      }

      case 'create_payment_intent': {
        if (!userId || !packageId) {
          throw new Error('userId and packageId are required')
        }

        // 获取套餐信息
        const { data: package_, error: packageError } = await supabaseClient
          .from('hz_credit_packages')
          .select('*')
          .eq('id', packageId)
          .eq('is_active', true)
          .single()

        if (packageError || !package_) {
          throw new Error('Package not found or inactive')
        }

        // 获取用户信息
        const { data: user, error: userError } = await supabaseClient
          .from('hz_users')
          .select('email, nickname')
          .eq('id', userId)
          .single()

        if (userError) {
          throw new Error(`Failed to get user: ${userError.message}`)
        }

        // 创建或获取Stripe客户
        let customer
        const existingCustomers = await stripe.customers.list({
          email: user.email,
          limit: 1
        })

        if (existingCustomers.data.length > 0) {
          customer = existingCustomers.data[0]
        } else {
          customer = await stripe.customers.create({
            email: user.email,
            name: user.nickname,
            metadata: {
              user_id: userId
            }
          })
        }

        // 创建PaymentIntent
        const paymentIntent = await stripe.paymentIntents.create({
          amount: Math.round(package_.price * 100), // 转换为分
          currency: package_.currency.toLowerCase(),
          customer: customer.id,
          metadata: {
            user_id: userId,
            package_id: packageId,
            credits: package_.credits.toString(),
            bonus_credits: package_.bonus_credits.toString()
          },
          description: `购买${package_.name} - ${package_.credits + package_.bonus_credits}积分`
        })

        // 记录支付记录
        const { error: paymentError } = await supabaseClient
          .from('hz_payments')
          .insert({
            user_id: userId,
            amount: package_.price,
            currency: package_.currency,
            status: 'pending',
            payment_method: 'stripe',
            stripe_payment_intent_id: paymentIntent.id,
            stripe_customer_id: customer.id,
            credits_purchased: package_.credits + package_.bonus_credits
          })

        if (paymentError) {
          console.error('Failed to record payment:', paymentError)
          // 不阻塞支付流程
        }

        return new Response(JSON.stringify({
          data: {
            clientSecret: paymentIntent.client_secret,
            paymentIntentId: paymentIntent.id,
            amount: package_.price,
            credits: package_.credits + package_.bonus_credits
          }
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
      }

      case 'confirm_payment': {
        if (!paymentIntentId) {
          throw new Error('paymentIntentId is required')
        }

        // 获取PaymentIntent状态
        const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId)
        
        if (paymentIntent.status === 'succeeded') {
          const userId = paymentIntent.metadata.user_id
          const credits = parseInt(paymentIntent.metadata.credits)
          
          // 更新支付状态
          const { error: updatePaymentError } = await supabaseClient
            .from('hz_payments')
            .update({ status: 'completed' })
            .eq('stripe_payment_intent_id', paymentIntentId)

          if (updatePaymentError) {
            console.error('Failed to update payment status:', updatePaymentError)
          }

          // 增加用户积分
          const { data: currentCredits, error: creditsError } = await supabaseClient
            .from('hz_user_credits')
            .select('balance, total_purchased')
            .eq('user_id', userId)
            .single()

          if (creditsError) {
            throw new Error(`Failed to get user credits: ${creditsError.message}`)
          }

          const newBalance = currentCredits.balance + credits
          const newTotalPurchased = currentCredits.total_purchased + credits

          const { error: updateCreditsError } = await supabaseClient
            .from('hz_user_credits')
            .update({ 
              balance: newBalance,
              total_purchased: newTotalPurchased
            })
            .eq('user_id', userId)

          if (updateCreditsError) {
            throw new Error(`Failed to update credits: ${updateCreditsError.message}`)
          }

          // 记录积分交易
          const { error: transactionError } = await supabaseClient
            .from('hz_credit_transactions')
            .insert({
              user_id: userId,
              amount: credits,
              type: 'purchase',
              description: `购买积分套餐 - ${credits}积分`,
              payment_id: paymentIntentId,
              balance_after: newBalance
            })

          if (transactionError) {
            console.error('Failed to record transaction:', transactionError)
          }

          return new Response(JSON.stringify({
            data: {
              success: true,
              message: `🎉 支付成功！您获得了${credits}积分`,
              newBalance: newBalance
            }
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          })
        } else {
          return new Response(JSON.stringify({
            data: {
              success: false,
              message: '支付未完成',
              status: paymentIntent.status
            }
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          })
        }
      }

      default:
        throw new Error('Invalid action')
    }
  } catch (error) {
    console.error('Payment processing error:', error)
    
    return new Response(JSON.stringify({
      error: {
        code: 'PAYMENT_ERROR',
        message: error.message || '支付处理失败'
      }
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
})