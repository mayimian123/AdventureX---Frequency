Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const requestData = await req.json();
        console.log('Coffee Chat管理请求:', requestData);
        
        const { action, ...params } = requestData;

        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        console.log('Supabase配置:', { supabaseUrl: !!supabaseUrl, serviceRoleKey: !!serviceRoleKey });

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        let result;

        console.log('执行操作:', action, '参数:', params);

        switch (action) {
            case 'create_activity':
                result = await createActivity(supabaseUrl, serviceRoleKey, params);
                break;
            case 'join_activity':
                result = await joinActivity(supabaseUrl, serviceRoleKey, params);
                break;
            case 'approve_participant':
                result = await approveParticipant(supabaseUrl, serviceRoleKey, params);
                break;
            case 'reject_participant':
                result = await rejectParticipant(supabaseUrl, serviceRoleKey, params);
                break;
            case 'get_my_activities':
                result = await getMyActivities(supabaseUrl, serviceRoleKey, params);
                break;
            case 'delete_activity':
                result = await deleteActivity(supabaseUrl, serviceRoleKey, params);
                break;
            case 'init_test_data':
                result = await initTestData(supabaseUrl, serviceRoleKey, params);
                break;
            default:
                throw new Error('Invalid action: ' + action);
        }

        console.log('操作结果:', result);

        return new Response(JSON.stringify({ data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Coffee chat management error:', error);
        
        const errorResponse = {
            error: {
                code: 'COFFEE_CHAT_MANAGEMENT_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

// 创建活动
async function createActivity(supabaseUrl, serviceRoleKey, params) {
    const { organizerId, title, description, startDatetime, endDatetime, location, maxParticipants, goal, targetTags } = params;

    console.log('创建活动参数:', {
        organizerId, title, description, startDatetime, endDatetime, location, maxParticipants, goal, targetTags
    });

    const activityData = {
        title,
        organizer_id: organizerId,
        description,
        start_datetime: startDatetime,
        end_datetime: endDatetime,
        location_country: location.country,
        location_province: location.province,
        location_city: location.city,
        location_address: location.address,
        location_detailed_address: location.detailed_address,
        max_participants: maxParticipants,
        current_participants: 1, // 组织者算一个参与者
        goal,
        target_tags: targetTags,
        status: 'recruiting' // 默认状态
    };

    console.log('活动数据载荷:', activityData);

    const createResponse = await fetch(`${supabaseUrl}/rest/v1/hz_coffee_chat_activities`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(activityData)
    });

    console.log('创建活动响应状态:', createResponse.status);
    
    if (!createResponse.ok) {
        const errorText = await createResponse.text();
        console.error('创建活动失败:', errorText);
        throw new Error('Failed to create activity: ' + errorText);
    }

    const activity = await createResponse.json();
    console.log('创建的活动:', activity);
    
    // 组织者自动参与
    const participantData = {
        activity_id: activity[0].id,
        user_id: organizerId,
        status: 'confirmed',
        applied_at: new Date().toISOString(),
        confirmed_at: new Date().toISOString()
    };
    
    console.log('添加组织者参与记录:', participantData);
    
    const participantResponse = await fetch(`${supabaseUrl}/rest/v1/hz_activity_participants`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(participantData)
    });

    if (!participantResponse.ok) {
        const errorText = await participantResponse.text();
        console.error('添加组织者参与记录失败:', errorText);
        // 不抛出错误，因为活动已经创建成功
    } else {
        console.log('组织者参与记录添加成功');
    }

    return activity[0];
}

// 加入活动
async function joinActivity(supabaseUrl, serviceRoleKey, params) {
    const { activityId, userId, whatToBring, whatToGet } = params;

    console.log('加入活动:', { activityId, userId, whatToBring, whatToGet });

    // 检查是否已经参与
    const existingResponse = await fetch(
        `${supabaseUrl}/rest/v1/hz_activity_participants?activity_id=eq.${activityId}&user_id=eq.${userId}`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    if (!existingResponse.ok) {
        const errorText = await existingResponse.text();
        console.error('检查参与状态失败:', errorText);
        throw new Error('Failed to check participation status: ' + errorText);
    }

    const existing = await existingResponse.json();
    console.log('现有参与记录:', existing);
    
    if (existing && existing.length > 0) {
        throw new Error('Already joined this activity');
    }

    // 加入活动（包含申请问卷）
    const participantData = {
        activity_id: activityId,
        user_id: userId,
        status: 'pending',
        applied_at: new Date().toISOString(),
        what_to_bring: whatToBring || null,
        what_to_get: whatToGet || null
    };
    
    console.log('加入活动数据:', participantData);
    
    const joinResponse = await fetch(`${supabaseUrl}/rest/v1/hz_activity_participants`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(participantData)
    });

    console.log('加入活动响应状态:', joinResponse.status);

    if (!joinResponse.ok) {
        const errorText = await joinResponse.text();
        console.error('加入活动失败:', errorText);
        throw new Error('Failed to join activity: ' + errorText);
    }

    const result = await joinResponse.json();
    console.log('加入活动成功:', result);
    
    return result;
}

// 批准参与者 - 简化版本
async function approveParticipant(supabaseUrl, serviceRoleKey, params) {
    const { participantId } = params;

    console.log('批准参与者开始:', participantId);

    try {
        // 第一步：获取参与者基本信息
        console.log('第一步：查询参与者信息...');
        const participantResponse = await fetch(
            `${supabaseUrl}/rest/v1/hz_activity_participants?id=eq.${participantId}`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            }
        );

        console.log('参与者查询响应状态:', participantResponse.status);
        
        if (!participantResponse.ok) {
            const errorText = await participantResponse.text();
            console.error('获取参与者信息失败:', errorText);
            throw new Error('Failed to get participant info: ' + errorText);
        }

        const participantData = await participantResponse.json();
        console.log('参与者查询结果:', participantData);
        
        const participant = participantData[0];
        
        if (!participant) {
            console.error('参与者不存在:', participantId);
            throw new Error('Participant not found');
        }

        console.log('找到参与者:', participant.user_id, '活动:', participant.activity_id);

        // 第二步：更新参与者状态为已确认
        console.log('第二步：更新参与者状态...');
        const approveResponse = await fetch(`${supabaseUrl}/rest/v1/hz_activity_participants?id=eq.${participantId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                status: 'confirmed',
                confirmed_at: new Date().toISOString()
            })
        });

        console.log('状态更新响应状态:', approveResponse.status);

        if (!approveResponse.ok) {
            const errorText = await approveResponse.text();
            console.error('更新参与者状态失败:', errorText);
            throw new Error('Failed to approve participant: ' + errorText);
        }

        const result = await approveResponse.json();
        console.log('状态更新成功:', result);

        // 第三步：暂时跳过通知发送，专注于核心功能
        console.log('第三步：跳过通知发送，确保核心功能正常');
        // TODO: 稍后添加通知功能

        console.log('批准参与者完成');
        return result;

    } catch (error) {
        console.error('批准参与者过程出错:', error);
        throw error;
    }
}

// 拒绝参与者 - 简化版本
async function rejectParticipant(supabaseUrl, serviceRoleKey, params) {
    const { participantId } = params;

    console.log('拒绝参与者开始:', participantId);

    try {
        // 第一步：获取参与者基本信息
        console.log('第一步：查询参与者信息...');
        const participantResponse = await fetch(
            `${supabaseUrl}/rest/v1/hz_activity_participants?id=eq.${participantId}`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            }
        );

        console.log('参与者查询响应状态:', participantResponse.status);
        
        if (!participantResponse.ok) {
            const errorText = await participantResponse.text();
            console.error('获取参与者信息失败:', errorText);
            throw new Error('Failed to get participant info: ' + errorText);
        }

        const participantData = await participantResponse.json();
        console.log('参与者查询结果:', participantData);
        
        const participant = participantData[0];
        
        if (!participant) {
            console.error('参与者不存在:', participantId);
            throw new Error('Participant not found');
        }

        console.log('找到参与者:', participant.user_id, '活动:', participant.activity_id);

        // 第二步：更新参与者状态为已拒绝
        console.log('第二步：更新参与者状态...');
        const rejectResponse = await fetch(`${supabaseUrl}/rest/v1/hz_activity_participants?id=eq.${participantId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                status: 'rejected'
            })
        });

        console.log('状态更新响应状态:', rejectResponse.status);

        if (!rejectResponse.ok) {
            const errorText = await rejectResponse.text();
            console.error('更新参与者状态失败:', errorText);
            throw new Error('Failed to reject participant: ' + errorText);
        }

        const result = await rejectResponse.json();
        console.log('状态更新成功:', result);

        // 第三步：暂时跳过通知发送，专注于核心功能
        console.log('第三步：跳过通知发送，确保核心功能正常');
        // TODO: 稍后添加通知功能

        console.log('拒绝参与者完成');
        return result;

    } catch (error) {
        console.error('拒绝参与者过程出错:', error);
        throw error;
    }
}

// 获取我的活动
async function getMyActivities(supabaseUrl, serviceRoleKey, params) {
    const { userId } = params;

    console.log('获取用户活动, userId:', userId);

    // 获取组织的活动
    const organizedResponse = await fetch(
        `${supabaseUrl}/rest/v1/hz_coffee_chat_activities?organizer_id=eq.${userId}&order=created_at.desc`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    console.log('组织的活动查询响应状态:', organizedResponse.status);
    
    if (!organizedResponse.ok) {
        const errorText = await organizedResponse.text();
        console.error('获取组织活动失败:', errorText);
        throw new Error('Failed to get organized activities: ' + errorText);
    }

    const organized = await organizedResponse.json();
    console.log('组织的活动数量:', organized?.length || 0);
    console.log('组织的活动:', organized);

    // 获取参与的活动（不仅仅是confirmed，还要包括pending）
    const participatedResponse = await fetch(
        `${supabaseUrl}/rest/v1/hz_activity_participants?user_id=eq.${userId}&order=created_at.desc`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    console.log('参与的活动查询响应状态:', participatedResponse.status);
    
    if (!participatedResponse.ok) {
        const errorText = await participatedResponse.text();
        console.error('获取参与活动失败:', errorText);
        throw new Error('Failed to get participated activities: ' + errorText);
    }

    const participated = await participatedResponse.json();
    console.log('参与的活动数量:', participated?.length || 0);
    console.log('参与的活动:', participated);
    
    const result = {
        organized: organized || [],
        participated: participated || []
    };
    
    console.log('最终返回的数据:', result);
    
    return result;
}

// 发送通知消息
async function sendNotificationMessage(supabaseUrl, serviceRoleKey, senderId, receiverId, messageContent, messageType = 'system_notification') {
    console.log('发送通知消息:', { senderId, receiverId, messageContent, messageType });

    try {
        // 检查是否已存在对话
        const conversationResponse = await fetch(
            `${supabaseUrl}/rest/v1/hz_conversations?or=(and(participant1_id.eq.${senderId},participant2_id.eq.${receiverId}),and(participant1_id.eq.${receiverId},participant2_id.eq.${senderId}))`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            }
        );

        if (!conversationResponse.ok) {
            throw new Error('Failed to check existing conversation');
        }

        const existingConversations = await conversationResponse.json();
        let conversationId;

        if (existingConversations && existingConversations.length > 0) {
            // 使用现有对话
            conversationId = existingConversations[0].id;
            console.log('使用现有对话:', conversationId);
        } else {
            // 创建新对话
            const createConversationResponse = await fetch(`${supabaseUrl}/rest/v1/hz_conversations`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=representation'
                },
                body: JSON.stringify({
                    participant1_id: senderId,
                    participant2_id: receiverId,
                    last_message_at: new Date().toISOString()
                })
            });

            if (!createConversationResponse.ok) {
                throw new Error('Failed to create conversation');
            }

            const newConversation = await createConversationResponse.json();
            conversationId = newConversation[0].id;
            console.log('创建新对话:', conversationId);
        }

        // 发送消息
        const messageResponse = await fetch(`${supabaseUrl}/rest/v1/hz_messages`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                conversation_id: conversationId,
                sender_id: senderId,
                content: messageContent,
                message_type: messageType,
                is_read: false
            })
        });

        if (!messageResponse.ok) {
            const errorText = await messageResponse.text();
            throw new Error('Failed to send message: ' + errorText);
        }

        const message = await messageResponse.json();
        console.log('消息发送成功:', message);

        // 更新对话的最后消息时间
        await fetch(`${supabaseUrl}/rest/v1/hz_conversations?id=eq.${conversationId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                last_message_at: new Date().toISOString()
            })
        });

        return message;
    } catch (error) {
        console.error('发送通知消息失败:', error);
        throw error;
    }
}

// 删除活动 - 简化版本
async function deleteActivity(supabaseUrl, serviceRoleKey, params) {
    const { activityId, organizerId } = params;

    console.log('删除活动开始:', { activityId, organizerId });

    try {
        // 第一步：验证活动存在且当前用户是组织者
        console.log('第一步：验证活动权限...');
        const activityResponse = await fetch(
            `${supabaseUrl}/rest/v1/hz_coffee_chat_activities?id=eq.${activityId}&organizer_id=eq.${organizerId}`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            }
        );

        console.log('活动权限验证响应状态:', activityResponse.status);

        if (!activityResponse.ok) {
            const errorText = await activityResponse.text();
            console.error('验证活动权限失败:', errorText);
            throw new Error('Failed to fetch activity: ' + errorText);
        }

        const activities = await activityResponse.json();
        console.log('活动查询结果:', activities);

        if (activities.length === 0) {
            console.error('活动不存在或无权限删除');
            throw new Error('Activity not found or you are not the organizer');
        }

        const activity = activities[0];
        console.log('找到要删除的活动:', activity.title);

        // 第二步：获取参与者信息（简化查询）
        console.log('第二步：获取参与者信息...');
        const participantsResponse = await fetch(
            `${supabaseUrl}/rest/v1/hz_activity_participants?activity_id=eq.${activityId}`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            }
        );

        console.log('参与者查询响应状态:', participantsResponse.status);

        let participants = [];
        if (participantsResponse.ok) {
            participants = await participantsResponse.json();
            console.log('获取到参与者:', participants.length, '人');
        } else {
            console.warn('获取参与者信息失败，继续删除流程');
        }

        // 第三步：删除参与者记录
        console.log('第三步：删除参与者记录...');
        const deleteParticipantsResponse = await fetch(
            `${supabaseUrl}/rest/v1/hz_activity_participants?activity_id=eq.${activityId}`,
            {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                }
            }
        );

        console.log('删除参与者记录响应状态:', deleteParticipantsResponse.status);

        if (!deleteParticipantsResponse.ok) {
            const errorText = await deleteParticipantsResponse.text();
            console.error('删除参与者记录失败:', errorText);
            // 继续执行删除活动，不中断流程
        } else {
            console.log('参与者记录删除成功');
        }

        // 第四步：删除活动记录
        console.log('第四步：删除活动记录...');
        const deleteActivityResponse = await fetch(
            `${supabaseUrl}/rest/v1/hz_coffee_chat_activities?id=eq.${activityId}`,
            {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                }
            }
        );

        console.log('删除活动记录响应状态:', deleteActivityResponse.status);

        if (!deleteActivityResponse.ok) {
            const errorText = await deleteActivityResponse.text();
            console.error('删除活动记录失败:', errorText);
            throw new Error('删除活动失败: ' + errorText);
        }

        console.log('活动删除完全成功');

        // 第五步：发送取消通知给申请者
        console.log('第五步：发送取消通知给申请者...');
        await sendCancellationNotifications(supabaseUrl, serviceRoleKey, participants, activity);

        return {
            success: true,
            message: '活动删除成功，已通知所有申请者',
            participantsCount: participants.length,
            activityTitle: activity.title,
            notificationsSent: participants.filter(p => p.user_id !== activity.organizer_id).length
        };

    } catch (error) {
        console.error('删除活动过程出错:', error);
        throw error;
    }
}

// 发送活动取消通知
async function sendCancellationNotifications(supabaseUrl, serviceRoleKey, participants, activity) {
    console.log('开始发送取消通知...');
    
    try {
        // 过滤出申请者（排除组织者）
        const applicants = participants.filter(p => p.user_id !== activity.organizer_id);
        console.log(`需要通知的申请者数量: ${applicants.length}`);
        
        if (applicants.length === 0) {
            console.log('没有需要通知的申请者');
            return { success: true, notifications: 0 };
        }

        // 为每个申请者创建通知消息
        const notifications = applicants.map(participant => ({
            receiver_id: participant.user_id,
            sender_id: activity.organizer_id,
            content: `很抱歉，您申请的Coffee Chat活动「${activity.title}」已被创建者取消。`,
            type: 'activity_cancelled',
            metadata: {
                activity_id: activity.id,
                activity_title: activity.title,
                activity_date: activity.start_datetime
            },
            created_at: new Date().toISOString()
        }));

        console.log('准备发送的通知:', notifications);

        // 批量插入通知到消息表
        const notificationResponse = await fetch(`${supabaseUrl}/rest/v1/hz_messages`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify(notifications)
        });

        console.log('通知发送响应状态:', notificationResponse.status);

        if (!notificationResponse.ok) {
            const errorText = await notificationResponse.text();
            console.error('发送通知失败:', errorText);
            // 通知发送失败不应该影响删除操作的成功
            return { success: false, error: errorText, notifications: 0 };
        }

        const sentNotifications = await notificationResponse.json();
        console.log(`成功发送 ${sentNotifications.length} 条通知`);

        return { 
            success: true, 
            notifications: sentNotifications.length,
            recipients: applicants.map(p => p.user_id)
        };

    } catch (error) {
        console.error('发送通知过程出错:', error);
        // 通知发送失败不应该影响删除操作的成功
        return { success: false, error: error.message, notifications: 0 };
    }
}

// 初始化测试数据
async function initTestData(supabaseUrl, serviceRoleKey, params) {
    const { userId } = params;
    
    console.log('开始初始化测试数据，用户ID:', userId);

    try {
        // 1. 创建测试用户
        const testUsers = [
            {
                id: 'test-user-1',
                auth_user_id: 'test-auth-1',
                email: 'zhangkaifa@test.com',
                nickname: '张开发',
                role: '前端工程师',
                avatar_url: '/avatars/avatar1.jpg',
                bio: '5年前端开发经验，专注React和Vue技术栈',
                tags: JSON.stringify(['JavaScript', 'React', 'Vue', '前端开发']),
                location_country: '国内',
                location_province: '北京市',
                location_city: '北京',
                location_address: '中关村',
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            },
            {
                id: 'test-user-2',
                auth_user_id: 'test-auth-2',
                email: 'lichanpin@test.com',
                nickname: '李产品',
                role: '产品经理',
                avatar_url: '/avatars/avatar2.jpg',
                bio: '3年产品经验，熟悉B端和C端产品设计',
                tags: JSON.stringify(['产品设计', '用户体验', '项目管理']),
                location_country: '国内',
                location_province: '北京市',
                location_city: '北京',
                location_address: '望京',
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            }
        ];

        // 先检查用户是否已存在，如果不存在则创建
        for (const user of testUsers) {
            const existingUserResponse = await fetch(`${supabaseUrl}/rest/v1/hz_users?id=eq.${user.id}`, {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            });
            
            const existingUsers = await existingUserResponse.json();
            
            if (existingUsers.length === 0) {
                const createUserResponse = await fetch(`${supabaseUrl}/rest/v1/hz_users`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(user)
                });
                
                if (!createUserResponse.ok) {
                    console.error('创建测试用户失败:', user.nickname);
                } else {
                    console.log('创建测试用户成功:', user.nickname);
                }
            } else {
                console.log('测试用户已存在:', user.nickname);
            }
        }

        // 2. 创建测试活动
        const testActivities = [
            {
                id: 'test-activity-1',
                title: '测试删除功能 - Coffee Chat技术分享',
                organizer_id: userId,
                description: '这是一个用于测试删除和审核功能的Coffee Chat活动。可以在这里测试删除按钮和审核申请者功能。',
                start_datetime: '2025-07-26T14:00:00Z',
                end_datetime: '2025-07-26T16:00:00Z',
                location_country: '国内',
                location_province: '北京市',
                location_city: '北京',
                location_address: '中关村创业大街',
                location_detailed_address: 'WeWork 3号楼',
                max_participants: 4,
                current_participants: 3,
                goal: '测试系统功能，验证删除和审核流程',
                target_tags: JSON.stringify(['技术分享', '测试']),
                status: 'recruiting',
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            },
            {
                id: 'test-activity-2',
                title: '创业交流 - 如何找到合适的联合创始人',
                organizer_id: userId,
                description: '和有创业想法的朋友一起讨论如何找到合适的合伙人，分享创业经验和教训。',
                start_datetime: '2025-07-28T19:00:00Z',
                end_datetime: '2025-07-28T21:00:00Z',
                location_country: '国内',
                location_province: '上海市',
                location_city: '上海',
                location_address: '陆家嘴金融中心',
                location_detailed_address: null,
                max_participants: 5,
                current_participants: 1,
                goal: '建立创业者网络，分享创业经验',
                target_tags: JSON.stringify(['创业', '合伙人']),
                status: 'recruiting',
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            }
        ];

        // 先检查活动是否已存在，如果不存在则创建
        for (const activity of testActivities) {
            const existingActivityResponse = await fetch(`${supabaseUrl}/rest/v1/hz_coffee_chat_activities?id=eq.${activity.id}`, {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            });
            
            const existingActivities = await existingActivityResponse.json();
            
            if (existingActivities.length === 0) {
                const createActivityResponse = await fetch(`${supabaseUrl}/rest/v1/hz_coffee_chat_activities`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(activity)
                });
                
                if (!createActivityResponse.ok) {
                    console.error('创建测试活动失败:', activity.title);
                } else {
                    console.log('创建测试活动成功:', activity.title);
                }
            } else {
                console.log('测试活动已存在:', activity.title);
            }
        }

        // 3. 创建参与者记录
        const testParticipants = [
            // 活动1的组织者参与记录
            {
                id: 'test-participant-1',
                activity_id: 'test-activity-1',
                user_id: userId,
                status: 'confirmed',
                applied_at: new Date().toISOString(),
                confirmed_at: new Date().toISOString(),
                what_to_bring: null,
                what_to_get: null,
                created_at: new Date().toISOString()
            },
            // 活动1的待审核申请者1
            {
                id: 'test-participant-2',
                activity_id: 'test-activity-1',
                user_id: 'test-user-1',
                status: 'pending',
                applied_at: new Date().toISOString(),
                confirmed_at: null,
                what_to_bring: '我能带来前端开发经验和项目案例分享，以及团队协作的实践经验',
                what_to_get: '希望学习后端技术和系统架构知识，了解全栈开发的最佳实践',
                created_at: new Date().toISOString()
            },
            // 活动1的待审核申请者2
            {
                id: 'test-participant-3',
                activity_id: 'test-activity-1',
                user_id: 'test-user-2',
                status: 'pending',
                applied_at: new Date().toISOString(),
                confirmed_at: null,
                what_to_bring: '产品设计思维和用户体验研究方法',
                what_to_get: '想了解技术实现的局限性，如何更好地与开发团队合作',
                created_at: new Date().toISOString()
            },
            // 活动2的组织者参与记录
            {
                id: 'test-participant-4',
                activity_id: 'test-activity-2',
                user_id: userId,
                status: 'confirmed',
                applied_at: new Date().toISOString(),
                confirmed_at: new Date().toISOString(),
                what_to_bring: null,
                what_to_get: null,
                created_at: new Date().toISOString()
            }
        ];

        // 先检查参与者是否已存在，如果不存在则创建
        for (const participant of testParticipants) {
            const existingParticipantResponse = await fetch(`${supabaseUrl}/rest/v1/hz_activity_participants?id=eq.${participant.id}`, {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            });
            
            const existingParticipants = await existingParticipantResponse.json();
            
            if (existingParticipants.length === 0) {
                const createParticipantResponse = await fetch(`${supabaseUrl}/rest/v1/hz_activity_participants`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(participant)
                });
                
                if (!createParticipantResponse.ok) {
                    console.error('创建测试参与者失败:', participant.id);
                } else {
                    console.log('创建测试参与者成功:', participant.id);
                }
            } else {
                console.log('测试参与者已存在:', participant.id);
            }
        }

        return {
            success: true,
            message: '测试数据初始化完成',
            data: {
                users: testUsers.length,
                activities: testActivities.length,
                participants: testParticipants.length
            }
        };

    } catch (error) {
        console.error('初始化测试数据失败:', error);
        throw error;
    }
}