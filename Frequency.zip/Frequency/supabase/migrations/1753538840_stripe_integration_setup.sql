-- Stripe集成配置表和函数
-- 支持VIP订阅的Stripe支付处理

-- 1. 为VIP套餐添加Stripe价格ID
UPDATE hz_vip_packages SET stripe_price_id = CASE
    WHEN package_type = 'monthly_vip' THEN 'price_monthly_vip_49_cny'
    WHEN package_type = 'quarterly_vip' THEN 'price_quarterly_vip_129_cny'
    WHEN package_type = 'annual_vip' THEN 'price_annual_vip_399_cny'
END;

-- 2. 创建Stripe客户信息表
CREATE TABLE IF NOT EXISTS hz_stripe_customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES hz_users(id) UNIQUE NOT NULL,
    stripe_customer_id TEXT UNIQUE NOT NULL,
    email TEXT,
    name TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. 扩展支付表，支持订阅支付
ALTER TABLE hz_payments ADD COLUMN IF NOT EXISTS payment_type TEXT CHECK (payment_type IN ('subscription', 'credits', 'one_time'));
ALTER TABLE hz_payments ADD COLUMN IF NOT EXISTS subscription_id UUID REFERENCES hz_user_subscriptions(id);
ALTER TABLE hz_payments ADD COLUMN IF NOT EXISTS stripe_session_id TEXT;
ALTER TABLE hz_payments ADD COLUMN IF NOT EXISTS stripe_payment_intent_id TEXT;
ALTER TABLE hz_payments ADD COLUMN IF NOT EXISTS webhook_processed BOOLEAN DEFAULT false;

-- 4. 创建Stripe Webhook事件记录表
CREATE TABLE IF NOT EXISTS hz_stripe_webhook_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    stripe_event_id TEXT UNIQUE NOT NULL,
    event_type TEXT NOT NULL,
    processed BOOLEAN DEFAULT false,
    error_message TEXT,
    raw_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. 创建VIP订阅激活函数
CREATE OR REPLACE FUNCTION activate_vip_subscription(
    user_uuid UUID,
    subscription_type_param TEXT,
    stripe_subscription_id_param TEXT,
    payment_amount DECIMAL(10,2)
) RETURNS UUID AS $$
DECLARE
    package_info RECORD;
    subscription_id UUID;
    end_date TIMESTAMP WITH TIME ZONE;
BEGIN
    -- 获取套餐信息
    SELECT price, activities_included, duration_days
    INTO package_info
    FROM hz_vip_packages
    WHERE package_type = subscription_type_param AND is_active = true;
    
    IF package_info IS NULL THEN
        RAISE EXCEPTION 'Invalid subscription type: %', subscription_type_param;
    END IF;
    
    -- 计算订阅结束时间
    end_date := NOW() + (package_info.duration_days || ' days')::INTERVAL;
    
    -- 停用用户的其他有效订阅
    UPDATE hz_user_subscriptions 
    SET status = 'cancelled', updated_at = NOW()
    WHERE user_id = user_uuid AND status = 'active';
    
    -- 创建新的VIP订阅
    INSERT INTO hz_user_subscriptions (
        user_id, subscription_type, status, started_at, ends_at, 
        stripe_subscription_id, activities_included, activities_used, 
        price_paid, currency
    ) VALUES (
        user_uuid, subscription_type_param, 'active', NOW(), end_date,
        stripe_subscription_id_param, package_info.activities_included, 0,
        payment_amount, 'CNY'
    ) RETURNING id INTO subscription_id;
    
    -- 更新用户为主理人
    UPDATE hz_users 
    SET is_host = true, host_since = NOW(), host_type = subscription_type_param
    WHERE id = user_uuid;
    
    -- 记录支付交易
    INSERT INTO hz_payments (
        user_id, amount, currency, status, payment_method, 
        stripe_payment_id, payment_type, subscription_id
    ) VALUES (
        user_uuid, payment_amount, 'CNY', 'completed', 'stripe',
        stripe_subscription_id_param, 'subscription', subscription_id
    );
    
    -- 记录积分交易（用于记录但不增加balance）
    INSERT INTO hz_credit_transactions (
        user_id, amount, type, description, balance_after
    ) VALUES (
        user_uuid, package_info.activities_included, 'subscription_grant', 
        'VIP订阅赠送活动次数：' || subscription_type_param, 0
    );
    
    RETURN subscription_id;
END;
$$ LANGUAGE plpgsql;

-- 6. 创建订阅过期检查函数
CREATE OR REPLACE FUNCTION expire_vip_subscriptions() RETURNS INTEGER AS $$
DECLARE
    expired_count INTEGER := 0;
BEGIN
    -- 更新过期的订阅状态
    UPDATE hz_user_subscriptions 
    SET status = 'expired', updated_at = NOW()
    WHERE status = 'active' 
      AND ends_at IS NOT NULL 
      AND ends_at <= NOW();
    
    GET DIAGNOSTICS expired_count = ROW_COUNT;
    
    -- 更新对应用户的主理人状态
    UPDATE hz_users 
    SET is_host = false, host_type = NULL
    WHERE id IN (
        SELECT user_id FROM hz_user_subscriptions 
        WHERE status = 'expired' 
          AND updated_at >= NOW() - INTERVAL '1 minute'
    ) AND is_host = true;
    
    RETURN expired_count;
END;
$$ LANGUAGE plpgsql;

-- 7. 创建Stripe客户管理函数
CREATE OR REPLACE FUNCTION create_or_get_stripe_customer(
    user_uuid UUID,
    stripe_customer_id_param TEXT,
    email_param TEXT DEFAULT NULL,
    name_param TEXT DEFAULT NULL
) RETURNS TEXT AS $$
DECLARE
    existing_customer_id TEXT;
BEGIN
    -- 查找已存在的Stripe客户
    SELECT stripe_customer_id INTO existing_customer_id
    FROM hz_stripe_customers
    WHERE user_id = user_uuid;
    
    IF existing_customer_id IS NOT NULL THEN
        -- 更新客户信息
        UPDATE hz_stripe_customers
        SET email = COALESCE(email_param, email),
            name = COALESCE(name_param, name),
            updated_at = NOW()
        WHERE user_id = user_uuid;
        
        RETURN existing_customer_id;
    ELSE
        -- 创建新的客户记录
        INSERT INTO hz_stripe_customers (user_id, stripe_customer_id, email, name)
        VALUES (user_uuid, stripe_customer_id_param, email_param, name_param);
        
        RETURN stripe_customer_id_param;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- 8. 创建索引
CREATE INDEX IF NOT EXISTS idx_stripe_customers_user_id ON hz_stripe_customers(user_id);
CREATE INDEX IF NOT EXISTS idx_stripe_customers_stripe_id ON hz_stripe_customers(stripe_customer_id);
CREATE INDEX IF NOT EXISTS idx_payments_subscription ON hz_payments(subscription_id) WHERE subscription_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_webhook_events_stripe_id ON hz_stripe_webhook_events(stripe_event_id);
CREATE INDEX IF NOT EXISTS idx_webhook_events_processed ON hz_stripe_webhook_events(processed) WHERE processed = false;

-- 9. 添加注释
COMMENT ON TABLE hz_stripe_customers IS 'Stripe客户信息表';
COMMENT ON TABLE hz_stripe_webhook_events IS 'Stripe Webhook事件记录表';
COMMENT ON FUNCTION activate_vip_subscription(UUID, TEXT, TEXT, DECIMAL) IS '激活用户VIP订阅';
COMMENT ON FUNCTION expire_vip_subscriptions() IS '检查并过期VIP订阅';
COMMENT ON FUNCTION create_or_get_stripe_customer(UUID, TEXT, TEXT, TEXT) IS '创建或获取Stripe客户';

-- 10. 创建定时任务处理过期订阅（需要定时执行）
-- 这将在定时任务中调用：SELECT expire_vip_subscriptions();