-- 为hz_users表添加主理人相关字段
ALTER TABLE hz_users ADD COLUMN IF NOT EXISTS is_host BOOLEAN DEFAULT false;
ALTER TABLE hz_users ADD COLUMN IF NOT EXISTS host_since TIMESTAMP WITH TIME ZONE;
ALTER TABLE hz_users ADD COLUMN IF NOT EXISTS host_type TEXT CHECK (host_type IN ('trial', 'basic', 'pro', 'enterprise'));

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_users_is_host ON hz_users(is_host);
CREATE INDEX IF NOT EXISTS idx_users_host_type ON hz_users(host_type) WHERE host_type IS NOT NULL;

-- 创建函数：自动为新用户创建积分记录
CREATE OR REPLACE FUNCTION create_user_credits_on_signup()
RETURNS TRIGGER AS $$
BEGIN
    -- 为新用户创建积分记录（赠送1积分）
    INSERT INTO hz_user_credits (user_id, balance, free_credits_granted)
    VALUES (NEW.id, 1, 1);
    
    -- 记录注册赠送积分的交易
    INSERT INTO hz_credit_transactions (user_id, amount, type, description, balance_after)
    VALUES (NEW.id, 1, 'signup_bonus', '新用户注册赠送积分', 1);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 创建触发器：用户注册时自动创建积分记录
DROP TRIGGER IF EXISTS trigger_create_user_credits ON hz_users;
CREATE TRIGGER trigger_create_user_credits
    AFTER INSERT ON hz_users
    FOR EACH ROW
    EXECUTE FUNCTION create_user_credits_on_signup();

-- 为现有用户创建积分记录（如果没有的话）
INSERT INTO hz_user_credits (user_id, balance, free_credits_granted)
SELECT u.id, 1, 1
FROM hz_users u
LEFT JOIN hz_user_credits c ON u.id = c.user_id
WHERE c.user_id IS NULL;

-- 为现有用户记录注册赠送积分交易
INSERT INTO hz_credit_transactions (user_id, amount, type, description, balance_after)
SELECT u.id, 1, 'signup_bonus', '新用户注册赠送积分（补录）', 1
FROM hz_users u
LEFT JOIN hz_credit_transactions t ON u.id = t.user_id AND t.type = 'signup_bonus'
WHERE t.id IS NULL;