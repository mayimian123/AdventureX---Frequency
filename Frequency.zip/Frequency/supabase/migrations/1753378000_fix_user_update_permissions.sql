-- 为hz_users表启用RLS并设置正确的策略
-- 这个migration解决用户无法更新个人资料的问题

-- 1. 启用RLS
ALTER TABLE hz_users ENABLE ROW LEVEL SECURITY;

-- 2. 允许用户查看自己的资料
CREATE POLICY "Users can view own profile" 
ON hz_users 
FOR SELECT 
USING (auth.uid() = auth_user_id);

-- 3. 允许用户插入自己的资料（新用户注册）
CREATE POLICY "Users can insert own profile" 
ON hz_users 
FOR INSERT 
WITH CHECK (auth.uid() = auth_user_id);

-- 4. 允许用户更新自己的资料（编辑模式）
CREATE POLICY "Users can update own profile" 
ON hz_users 
FOR UPDATE 
USING (auth.uid() = auth_user_id)
WITH CHECK (auth.uid() = auth_user_id);

-- 5. 不允许用户删除自己的资料
-- CREATE POLICY "Users cannot delete profiles" 
-- ON hz_users 
-- FOR DELETE 
-- USING (false);

-- 6. 创建或更新updated_at触发器
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 7. 如果触发器不存在则创建
DROP TRIGGER IF EXISTS update_hz_users_updated_at ON hz_users;
CREATE TRIGGER update_hz_users_updated_at
    BEFORE UPDATE ON hz_users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 8. 确保auth_user_id字段有正确的外键约束（可选）
-- ALTER TABLE hz_users 
-- ADD CONSTRAINT fk_hz_users_auth_user_id 
-- FOREIGN KEY (auth_user_id) 
-- REFERENCES auth.users(id) 
-- ON DELETE CASCADE;
