-- Migration: vip_membership_model_update
-- Created at: 1753540200

-- Migration: vip_membership_model_update
-- VIP会员制商业模式更新
-- 移除免费试用逻辑，实现纯付费VIP订阅模式

-- 1. 修改hz_user_credits表，移除免费积分逻辑
ALTER TABLE hz_user_credits ALTER COLUMN balance SET DEFAULT 0;
ALTER TABLE hz_user_credits ALTER COLUMN free_credits_granted SET DEFAULT 0;

-- 2. 为hz_user_subscriptions表添加VIP套餐相关字段
ALTER TABLE hz_user_subscriptions ADD COLUMN IF NOT EXISTS activities_included INTEGER DEFAULT 0;
ALTER TABLE hz_user_subscriptions ADD COLUMN IF NOT EXISTS activities_used INTEGER DEFAULT 0;
ALTER TABLE hz_user_subscriptions ADD COLUMN IF NOT EXISTS price_paid DECIMAL(10,2);
ALTER TABLE hz_user_subscriptions ADD COLUMN IF NOT EXISTS currency TEXT DEFAULT 'CNY';

-- 3. 更新订阅类型枚举，支持VIP套餐
ALTER TABLE hz_user_subscriptions DROP CONSTRAINT IF EXISTS hz_user_subscriptions_subscription_type_check;
ALTER TABLE hz_user_subscriptions ADD CONSTRAINT hz_user_subscriptions_subscription_type_check 
    CHECK (subscription_type IN ('monthly_vip', 'quarterly_vip', 'annual_vip'));

-- 4. 更新订阅状态枚举，移除trial
ALTER TABLE hz_user_subscriptions DROP CONSTRAINT IF EXISTS hz_user_subscriptions_status_check;
ALTER TABLE hz_user_subscriptions ADD CONSTRAINT hz_user_subscriptions_status_check 
    CHECK (status IN ('active', 'cancelled', 'expired', 'payment_failed'));

-- 5. 移除trial相关字段的默认值
ALTER TABLE hz_user_subscriptions ALTER COLUMN status DROP DEFAULT;
ALTER TABLE hz_user_subscriptions ALTER COLUMN trial_ends_at DROP DEFAULT;

-- 6. 添加VIP套餐配置表
CREATE TABLE IF NOT EXISTS hz_vip_packages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    package_type TEXT NOT NULL CHECK (package_type IN ('monthly_vip', 'quarterly_vip', 'annual_vip')),
    name TEXT NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    currency TEXT DEFAULT 'CNY',
    activities_included INTEGER NOT NULL,
    duration_days INTEGER NOT NULL,
    stripe_price_id TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. 插入VIP套餐数据
INSERT INTO hz_vip_packages (package_type, name, description, price, activities_included, duration_days) VALUES
('monthly_vip', '月度VIP主理人', '每月2次专属活动创办权限', 49.00, 2, 30),
('quarterly_vip', '季度VIP主理人', '每季度8次专属活动创办权限', 129.00, 8, 90),
('annual_vip', '年度VIP主理人', '每年50次专属活动创办权限', 399.00, 50, 365)
ON CONFLICT DO NOTHING;

-- 8. 删除原有的免费积分触发器
DROP TRIGGER IF EXISTS trigger_create_user_credits ON hz_users;
DROP FUNCTION IF EXISTS create_user_credits_on_signup();

-- 9. 创建新的用户注册处理函数（不赠送积分）
CREATE OR REPLACE FUNCTION create_user_profile_on_signup()
RETURNS TRIGGER AS $$
BEGIN
    -- 为新用户创建积分记录（0积分起始）
    INSERT INTO hz_user_credits (user_id, balance, free_credits_granted, total_purchased, total_used)
    VALUES (NEW.id, 0, 0, 0, 0);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 10. 创建新的用户注册触发器
CREATE TRIGGER trigger_create_user_profile
    AFTER INSERT ON hz_users
    FOR EACH ROW
    EXECUTE FUNCTION create_user_profile_on_signup();

-- 11. 创建VIP订阅管理函数
CREATE OR REPLACE FUNCTION check_vip_subscription_status(user_uuid UUID)
RETURNS TABLE(
    is_vip BOOLEAN,
    subscription_type TEXT,
    activities_remaining INTEGER,
    expires_at TIMESTAMP WITH TIME ZONE
) AS $$
DECLARE
    sub_record RECORD;
BEGIN
    SELECT s.subscription_type, s.status, s.ends_at, s.activities_included, s.activities_used
    INTO sub_record
    FROM hz_user_subscriptions s
    WHERE s.user_id = user_uuid 
      AND s.status = 'active' 
      AND (s.ends_at IS NULL OR s.ends_at > NOW())
    ORDER BY s.created_at DESC
    LIMIT 1;
    
    IF sub_record IS NOT NULL THEN
        RETURN QUERY SELECT 
            true::BOOLEAN,
            sub_record.subscription_type::TEXT,
            (sub_record.activities_included - sub_record.activities_used)::INTEGER,
            sub_record.ends_at;
    ELSE
        RETURN QUERY SELECT 
            false::BOOLEAN,
            NULL::TEXT,
            0::INTEGER,
            NULL::TIMESTAMP WITH TIME ZONE;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- 12. 创建活动创办消费函数
CREATE OR REPLACE FUNCTION consume_activity_quota(user_uuid UUID)
RETURNS BOOLEAN AS $$
DECLARE
    sub_record RECORD;
BEGIN
    -- 获取用户的有效订阅
    SELECT id, activities_included, activities_used
    INTO sub_record
    FROM hz_user_subscriptions
    WHERE user_id = user_uuid 
      AND status = 'active' 
      AND (ends_at IS NULL OR ends_at > NOW())
    ORDER BY created_at DESC
    LIMIT 1;
    
    -- 检查是否有有效订阅且有剩余次数
    IF sub_record IS NOT NULL AND sub_record.activities_used < sub_record.activities_included THEN
        -- 消费一次活动额度
        UPDATE hz_user_subscriptions 
        SET activities_used = activities_used + 1,
            updated_at = NOW()
        WHERE id = sub_record.id;
        
        -- 记录消费交易
        INSERT INTO hz_credit_transactions (user_id, amount, type, description, balance_after)
        VALUES (user_uuid, -1, 'activity_creation', 'VIP活动创办消费', 0);
        
        RETURN true;
    ELSE
        RETURN false;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- 13. 创建索引优化查询性能
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_user_status ON hz_user_subscriptions(user_id, status) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_expires ON hz_user_subscriptions(ends_at) WHERE ends_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_vip_packages_type ON hz_vip_packages(package_type) WHERE is_active = true;

-- 14. 添加注释
COMMENT ON TABLE hz_vip_packages IS 'VIP会员套餐配置表';
COMMENT ON FUNCTION check_vip_subscription_status(UUID) IS '检查用户VIP订阅状态和剩余活动次数';
COMMENT ON FUNCTION consume_activity_quota(UUID) IS '消费用户的活动创办额度';

-- 15. 更新现有用户的积分余额为0（移除免费积分）
UPDATE hz_user_credits SET balance = 0, free_credits_granted = 0 WHERE free_credits_granted > 0;

-- 16. 重置所有用户的主理人状态（需要重新付费获得）
UPDATE hz_users SET is_host = false, host_type = NULL WHERE is_host = true;;