-- Coffee Chat地点定位功能数据库扩展
-- 添加地理位置相关字段和功能

-- 1. 扩展Coffee Chat活动表，添加地理位置字段
ALTER TABLE hz_coffee_chat_activities ADD COLUMN IF NOT EXISTS
  location_name VARCHAR(255),         -- 地点名称（如"星巴克静安店"）
  latitude DECIMAL(10, 8),            -- 地点纬度
  longitude DECIMAL(11, 8),           -- 地点经度
  place_id VARCHAR(255);              -- Google Places ID（可选）

-- 2. 创建用户位置缓存表
CREATE TABLE IF NOT EXISTS hz_user_location_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES hz_users(id) ON DELETE CASCADE,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  address TEXT,                       -- 缓存的地址信息
  city VARCHAR(100),                  -- 城市信息
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(user_id)
);

-- 3. 为位置缓存表创建索引
CREATE INDEX IF NOT EXISTS idx_hz_user_location_cache_user_id ON hz_user_location_cache(user_id);
CREATE INDEX IF NOT EXISTS idx_hz_user_location_cache_updated_at ON hz_user_location_cache(updated_at);

-- 4. 为活动表的地理位置字段创建索引
CREATE INDEX IF NOT EXISTS idx_hz_coffee_chat_activities_location ON hz_coffee_chat_activities(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_hz_coffee_chat_activities_location_city ON hz_coffee_chat_activities(location_city);

-- 5. 创建距离计算函数（使用Haversine公式）
CREATE OR REPLACE FUNCTION calculate_distance(
  lat1 DECIMAL,
  lng1 DECIMAL,
  lat2 DECIMAL,
  lng2 DECIMAL
) RETURNS DECIMAL AS $$
DECLARE
  earth_radius DECIMAL := 6371; -- 地球半径（公里）
  dlat DECIMAL;
  dlng DECIMAL;
  a DECIMAL;
  c DECIMAL;
BEGIN
  -- 检查输入参数
  IF lat1 IS NULL OR lng1 IS NULL OR lat2 IS NULL OR lng2 IS NULL THEN
    RETURN NULL;
  END IF;
  
  -- 转换为弧度
  dlat := radians(lat2 - lat1);
  dlng := radians(lng2 - lng1);
  
  -- Haversine公式计算
  a := sin(dlat/2) * sin(dlat/2) + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlng/2) * sin(dlng/2);
  c := 2 * atan2(sqrt(a), sqrt(1-a));
  
  -- 返回距离（公里）
  RETURN earth_radius * c;
END;
$$ LANGUAGE plpgsql;

-- 6. 创建获取带距离活动列表的函数
CREATE OR REPLACE FUNCTION get_activities_with_distance(
  user_lat DECIMAL,
  user_lng DECIMAL,
  max_distance_km DECIMAL DEFAULT NULL
)
RETURNS TABLE (
  id UUID,
  title VARCHAR,
  description TEXT,
  start_datetime TIMESTAMPTZ,
  end_datetime TIMESTAMPTZ,
  location_name VARCHAR,
  location_city VARCHAR,
  location_address TEXT,
  location_detailed_address TEXT,
  latitude DECIMAL,
  longitude DECIMAL,
  max_participants INTEGER,
  current_participants INTEGER,
  organizer_id UUID,
  status VARCHAR,
  distance_km DECIMAL,
  created_at TIMESTAMPTZ
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    a.id,
    a.title,
    a.description,
    a.start_datetime,
    a.end_datetime,
    a.location_name,
    a.location_city,
    a.location_address,
    a.location_detailed_address,
    a.latitude,
    a.longitude,
    a.max_participants,
    a.current_participants,
    a.organizer_id,
    a.status,
    CASE 
      WHEN a.latitude IS NOT NULL AND a.longitude IS NOT NULL THEN
        calculate_distance(user_lat, user_lng, a.latitude, a.longitude)
      ELSE 
        NULL
    END AS distance_km,
    a.created_at
  FROM hz_coffee_chat_activities a
  WHERE a.status = 'recruiting'
    AND (max_distance_km IS NULL OR 
         (a.latitude IS NOT NULL AND a.longitude IS NOT NULL AND
          calculate_distance(user_lat, user_lng, a.latitude, a.longitude) <= max_distance_km))
  ORDER BY 
    CASE 
      WHEN a.latitude IS NOT NULL AND a.longitude IS NOT NULL THEN
        calculate_distance(user_lat, user_lng, a.latitude, a.longitude)
      ELSE 
        999999  -- 没有位置信息的活动排在最后
    END ASC,
    a.created_at DESC;
END;
$$ LANGUAGE plpgsql;

-- 7. 创建用户位置缓存管理函数
CREATE OR REPLACE FUNCTION upsert_user_location(
  p_user_id UUID,
  p_latitude DECIMAL,
  p_longitude DECIMAL,
  p_address TEXT DEFAULT NULL,
  p_city VARCHAR DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
  INSERT INTO hz_user_location_cache (user_id, latitude, longitude, address, city, updated_at)
  VALUES (p_user_id, p_latitude, p_longitude, p_address, p_city, NOW())
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    latitude = EXCLUDED.latitude,
    longitude = EXCLUDED.longitude,
    address = EXCLUDED.address,
    city = EXCLUDED.city,
    updated_at = NOW();
END;
$$ LANGUAGE plpgsql;

-- 8. 创建清理过期位置缓存的函数（清理2小时前的缓存）
CREATE OR REPLACE FUNCTION cleanup_expired_location_cache() RETURNS INTEGER AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  DELETE FROM hz_user_location_cache 
  WHERE updated_at < NOW() - INTERVAL '2 hours';
  
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- 9. 为位置缓存表启用RLS
ALTER TABLE hz_user_location_cache ENABLE ROW LEVEL SECURITY;

-- 10. 为位置缓存表创建RLS策略
CREATE POLICY "Users can manage own location cache" 
ON hz_user_location_cache 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM hz_users 
    WHERE hz_users.id = hz_user_location_cache.user_id 
    AND hz_users.auth_user_id = auth.uid()
  )
);

-- 11. 创建定期清理位置缓存的计划任务（如果支持pg_cron）
-- 这个在Supabase中可能需要手动设置或通过Edge Function定期调用
-- SELECT cron.schedule('cleanup-location-cache', '0 */2 * * *', 'SELECT cleanup_expired_location_cache();');

-- 12. 更新活动表的updated_at触发器（如果不存在）
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_hz_coffee_chat_activities_updated_at ON hz_coffee_chat_activities;
CREATE TRIGGER update_hz_coffee_chat_activities_updated_at
    BEFORE UPDATE ON hz_coffee_chat_activities
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 13. 添加注释说明
COMMENT ON COLUMN hz_coffee_chat_activities.location_name IS '地点名称，如星巴克静安店';
COMMENT ON COLUMN hz_coffee_chat_activities.latitude IS '地点纬度，用于距离计算';
COMMENT ON COLUMN hz_coffee_chat_activities.longitude IS '地点经度，用于距离计算';
COMMENT ON COLUMN hz_coffee_chat_activities.place_id IS 'Google Places API的地点ID';

COMMENT ON TABLE hz_user_location_cache IS '用户位置缓存表，缓存2小时';
COMMENT ON FUNCTION calculate_distance IS '使用Haversine公式计算两点间距离（公里）';
COMMENT ON FUNCTION get_activities_with_distance IS '获取带距离信息的活动列表，按距离排序';
COMMENT ON FUNCTION upsert_user_location IS '更新或插入用户位置缓存';
COMMENT ON FUNCTION cleanup_expired_location_cache IS '清理过期的位置缓存数据';
