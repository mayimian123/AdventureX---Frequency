-- Migration: add_application_questionnaire_fields
-- Created at: 1753377626

-- 为hz_activity_participants表添加申请问卷字段
ALTER TABLE hz_activity_participants 
ADD COLUMN what_to_bring TEXT,
ADD COLUMN what_to_get TEXT;;