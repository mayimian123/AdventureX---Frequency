-- Migration: add_host_features_to_users
-- Created at: 1753537764

-- 为hz_users表添加主理人相关字段
ALTER TABLE hz_users ADD COLUMN IF NOT EXISTS is_host BOOLEAN DEFAULT false;
ALTER TABLE hz_users ADD COLUMN IF NOT EXISTS host_since TIMESTAMP WITH TIME ZONE;
ALTER TABLE hz_users ADD COLUMN IF NOT EXISTS host_type TEXT CHECK (host_type IN ('trial', 'basic', 'pro', 'enterprise'));

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_users_is_host ON hz_users(is_host);
CREATE INDEX IF NOT EXISTS idx_users_host_type ON hz_users(host_type) WHERE host_type IS NOT NULL;;