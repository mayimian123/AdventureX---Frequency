CREATE TABLE hz_user_credits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES hz_users(id) ON DELETE CASCADE UNIQUE,
    balance INTEGER DEFAULT 1 CHECK (balance >= 0),
    total_purchased INTEGER DEFAULT 0 CHECK (total_purchased >= 0),
    total_used INTEGER DEFAULT 0 CHECK (total_used >= 0),
    free_credits_granted INTEGER DEFAULT 1 CHECK (free_credits_granted >= 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);