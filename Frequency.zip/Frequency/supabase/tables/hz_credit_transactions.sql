CREATE TABLE hz_credit_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES hz_users(id) ON DELETE CASCADE,
    amount INTEGER NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('purchase',
    'activity_create',
    'signup_bonus',
    'refund',
    'admin_adjust')),
    description TEXT,
    activity_id UUID REFERENCES hz_coffee_chat_activities(id) ON DELETE SET NULL,
    payment_id TEXT,
    balance_after INTEGER NOT NULL CHECK (balance_after >= 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);