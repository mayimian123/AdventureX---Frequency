CREATE TABLE hz_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    auth_user_id UUID UNIQUE,
    email VARCHAR(255) UNIQUE NOT NULL,
    nickname VARCHAR(100) NOT NULL,
    age INTEGER,
    avatar_url TEXT,
    location_country VARCHAR(100),
    location_province VARCHAR(100),
    location_city VARCHAR(100),
    role VARCHAR(200),
    current_activity TEXT,
    professional_fields JSONB DEFAULT '[]',
    interest_tags JSONB DEFAULT '[]',
    about_me TEXT,
    is_profile_complete BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);