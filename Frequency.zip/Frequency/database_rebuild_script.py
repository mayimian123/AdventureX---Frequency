#!/usr/bin/env python3
"""
Coffee Chat数据库清理和重建脚本

这个脚本将：
1. 清理现有的Coffee Chat活动数据
2. 创建三个包含完整地点定位信息的新活动
3. 添加组织者参与记录
4. 验证操作结果
"""

import os
import sys
from datetime import datetime, timezone, timedelta
from supabase import create_client, Client

# Supabase配置
SUPABASE_URL = 'https://xyjsbpahmcisxvydbkxr.supabase.co'
SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh5anNicGFobWNpc3h2eWRia3hyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNjcwMDUsImV4cCI6MjA2ODk0MzAwNX0.DWMcfP28qQKCVmhJvrFyU1ROglbtKaPPRlQSPQemwTI'

# 测试用户邮箱
TEST_USER_EMAIL = 'naovcaln@minimax.com'

def get_supabase_client():
    """创建Supabase客户端"""
    return create_client(SUPABASE_URL, SUPABASE_ANON_KEY)

def get_test_user_id(supabase: Client):
    """获取测试用户的ID"""
    print("🔍 查找测试用户ID...")
    
    try:
        response = supabase.table('hz_users').select('id').eq('email', TEST_USER_EMAIL).execute()
        
        if response.data and len(response.data) > 0:
            user_id = response.data[0]['id']
            print(f"✅ 找到测试用户ID: {user_id}")
            return user_id
        else:
            print(f"❌ 未找到邮箱为 {TEST_USER_EMAIL} 的用户")
            return None
            
    except Exception as e:
        print(f"❌ 查找用户时出错: {e}")
        return None

def clear_existing_data(supabase: Client):
    """清理现有数据"""
    print("🗑️ 开始清理现有数据...")
    
    try:
        # 1. 先查看并清除活动参与者数据
        print("  查看现有参与者数据...")
        participants_response = supabase.table('hz_activity_participants').select('id').execute()
        if participants_response.data:
            print(f"  找到 {len(participants_response.data)} 条参与者记录")
            # 逐个删除参与者记录
            for participant in participants_response.data:
                supabase.table('hz_activity_participants').delete().eq('id', participant['id']).execute()
            print(f"  ✅ 清除了所有参与者记录")
        else:
            print("  ✅ 没有参与者记录需要清除")
        
        # 2. 查看并清除Coffee Chat活动
        print("  查看现有活动数据...")
        activities_response = supabase.table('hz_coffee_chat_activities').select('id').execute()
        if activities_response.data:
            print(f"  找到 {len(activities_response.data)} 个活动")
            # 逐个删除活动记录
            for activity in activities_response.data:
                supabase.table('hz_coffee_chat_activities').delete().eq('id', activity['id']).execute()
            print(f"  ✅ 清除了所有活动记录")
        else:
            print("  ✅ 没有活动记录需要清除")
        
        # 3. 清除用户位置缓存（可选）
        print("  查看位置缓存数据...")
        try:
            cache_response = supabase.table('hz_user_location_cache').select('id').execute()
            if cache_response.data:
                print(f"  找到 {len(cache_response.data)} 条位置缓存")
                for cache in cache_response.data:
                    supabase.table('hz_user_location_cache').delete().eq('id', cache['id']).execute()
                print(f"  ✅ 清除了所有位置缓存")
            else:
                print("  ✅ 没有位置缓存需要清除")
        except Exception as e:
            print(f"  ⚠️ 清除位置缓存失败（可能表不存在）: {e}")
        
        print("✅ 数据清理完成！")
        return True
        
    except Exception as e:
        print(f"❌ 清理数据时出错: {e}")
        return False

def create_new_activities(supabase: Client, organizer_id: str):
    """创建三个新活动"""
    print("📝 开始创建新活动...")
    
    # 设置时区为中国时间 (UTC+8)
    china_tz = timezone(timedelta(hours=8))
    
    # 活动数据
    activities = [
        {
            'title': '周末咖啡交流会',
            'description': '在温馨的咖啡厅里，和同频的朋友分享生活中的小美好，交流工作心得，放松周末时光。',
            'start_datetime': datetime(2025, 1, 28, 14, 0, 0, tzinfo=china_tz).isoformat(),
            'end_datetime': datetime(2025, 1, 28, 16, 0, 0, tzinfo=china_tz).isoformat(),
            'location_country': '国内',
            'location_province': '上海市',
            'location_city': '上海',
            'location_address': '上海市静安区南京西路1168号',
            'location_detailed_address': '星巴克静安店',
            'location_name': '星巴克静安店',
            'latitude': 31.2304,
            'longitude': 121.4737,
            'place_id': 'ChIJN1t_tDeuEmsRUsoyG83frY4',
            'max_participants': 6,
            'current_participants': 1,
            'goal': '分享生活中的美好，交流工作心得，建立温暖的社交圈',
            'target_tags': ['生活分享', '工作交流', '咖啡', '周末时光', '社交'],
            'organizer_id': organizer_id,
            'status': 'recruiting'
        },
        {
            'title': '职场新人午餐聚会',
            'description': '刚入职场的小伙伴一起聚餐，分享求职经验，讨论职场生活，互相鼓励成长。',
            'start_datetime': datetime(2025, 1, 30, 12, 0, 0, tzinfo=china_tz).isoformat(),
            'end_datetime': datetime(2025, 1, 30, 14, 0, 0, tzinfo=china_tz).isoformat(),
            'location_country': '国内',
            'location_province': '上海市',
            'location_city': '上海',
            'location_address': '上海市黄浦区南京东路299号',
            'location_detailed_address': 'Costa咖啡人民广场店',
            'location_name': 'Costa咖啡人民广场店',
            'latitude': 31.2395,
            'longitude': 121.4824,
            'place_id': 'ChIJrTLr-GyuEmsRBfy61i59si0',
            'max_participants': 8,
            'current_participants': 1,
            'goal': '职场新人互助，分享经验，建立职场社交网络',
            'target_tags': ['职场新人', '求职经验', '职场成长', '午餐聚会', '互助'],
            'organizer_id': organizer_id,
            'status': 'recruiting'
        },
        {
            'title': '创业者晚间交流',
            'description': '创业路上的朋友们聚在一起，分享创业心得，讨论商业想法，寻找合作机会。',
            'start_datetime': datetime(2025, 2, 1, 19, 0, 0, tzinfo=china_tz).isoformat(),
            'end_datetime': datetime(2025, 2, 1, 21, 0, 0, tzinfo=china_tz).isoformat(),
            'location_country': '国内',
            'location_province': '上海市',
            'location_city': '上海',
            'location_address': '上海市静安区愚园路68号',
            'location_detailed_address': 'WeWork静安寺店',
            'location_name': 'WeWork静安寺店',
            'latitude': 31.2198,
            'longitude': 121.4456,
            'place_id': 'ChIJ5RgK4eKuEmsRLpD8nL7YfGo',
            'max_participants': 10,
            'current_participants': 1,
            'goal': '创业者交流心得，分享商业想法，寻找合作伙伴',
            'target_tags': ['创业', '商业', '合作', '晚间交流', '创新'],
            'organizer_id': organizer_id,
            'status': 'recruiting'
        }
    ]
    
    created_activities = []
    
    for i, activity in enumerate(activities, 1):
        try:
            print(f"  创建活动 {i}: {activity['title']}...")
            
            response = supabase.table('hz_coffee_chat_activities').insert(activity).execute()
            
            if response.data and len(response.data) > 0:
                created_activity = response.data[0]
                created_activities.append(created_activity)
                print(f"    ✅ 成功创建活动: {created_activity['id']}")
                print(f"    📍 地点: {activity['location_name']}")
                print(f"    📅 时间: {activity['start_datetime']}")
                print(f"    📌 坐标: ({activity['latitude']}, {activity['longitude']})")
            else:
                print(f"    ❌ 创建活动失败，无返回数据")
                
        except Exception as e:
            print(f"    ❌ 创建活动 {activity['title']} 时出错: {e}")
    
    print(f"✅ 成功创建 {len(created_activities)} 个活动！")
    return created_activities

def add_organizer_participants(supabase: Client, activities, organizer_id: str):
    """为每个活动添加组织者参与记录"""
    print("👥 添加组织者参与记录...")
    
    for activity in activities:
        try:
            activity_id = activity['id']
            activity_title = activity['title']
            
            participant_data = {
                'activity_id': activity_id,
                'user_id': organizer_id,
                'status': 'confirmed',
                'confirmed_at': datetime.now(timezone.utc).isoformat()
            }
            
            response = supabase.table('hz_activity_participants').insert(participant_data).execute()
            
            if response.data and len(response.data) > 0:
                print(f"  ✅ 为活动 '{activity_title}' 添加组织者参与记录")
            else:
                print(f"  ❌ 为活动 '{activity_title}' 添加参与记录失败")
                
        except Exception as e:
            print(f"  ❌ 为活动 '{activity['title']}' 添加参与记录时出错: {e}")

def verify_results(supabase: Client):
    """验证操作结果"""
    print("🔍 验证操作结果...")
    
    try:
        # 检查活动数量
        activities_response = supabase.table('hz_coffee_chat_activities').select('*').execute()
        activities_count = len(activities_response.data) if activities_response.data else 0
        print(f"  📊 活动总数: {activities_count}")
        
        # 检查参与者数量
        participants_response = supabase.table('hz_activity_participants').select('*').execute()
        participants_count = len(participants_response.data) if participants_response.data else 0
        print(f"  👥 参与者记录总数: {participants_count}")
        
        # 检查每个活动的详细信息
        if activities_response.data:
            print("  📋 活动详情:")
            for activity in activities_response.data:
                print(f"    - {activity['title']}")
                print(f"      地点: {activity.get('location_name', 'N/A')}")
                print(f"      坐标: ({activity.get('latitude', 'N/A')}, {activity.get('longitude', 'N/A')})")
                print(f"      时间: {activity['start_datetime']}")
                print(f"      状态: {activity['status']}")
        
        if activities_count == 3 and participants_count == 3:
            print("✅ 验证成功！所有数据已正确创建。")
            return True
        else:
            print(f"⚠️ 验证警告：预期3个活动和3个参与记录，实际得到 {activities_count} 个活动和 {participants_count} 个参与记录")
            return False
            
    except Exception as e:
        print(f"❌ 验证过程中出错: {e}")
        return False

def main():
    """主函数"""
    print("🚀 开始Coffee Chat数据库清理和重建操作")
    print("=" * 60)
    
    # 创建Supabase客户端
    supabase = get_supabase_client()
    
    # 获取测试用户ID
    organizer_id = get_test_user_id(supabase)
    if not organizer_id:
        print("❌ 无法获取测试用户ID，操作中止")
        sys.exit(1)
    
    # 清理现有数据
    if not clear_existing_data(supabase):
        print("❌ 数据清理失败，操作中止")
        sys.exit(1)
    
    # 创建新活动
    created_activities = create_new_activities(supabase, organizer_id)
    if not created_activities:
        print("❌ 创建活动失败，操作中止")
        sys.exit(1)
    
    # 添加组织者参与记录
    add_organizer_participants(supabase, created_activities, organizer_id)
    
    # 验证结果
    if verify_results(supabase):
        print("\n🎉 数据库重建操作完成！")
        print("=" * 60)
        print("📋 操作总结:")
        print("  ✅ 清除了所有旧的Coffee Chat数据")
        print("  ✅ 创建了3个包含完整地点信息的新活动")
        print("  ✅ 添加了组织者参与记录")
        print("  ✅ 所有活动都包含准确的地理坐标")
        print("\n🔗 现在可以测试网站功能:")
        print("  🌐 网站地址: https://jtd3iy3dwr9g.space.minimax.io")
        print("  👤 测试账户: naovcaln@minimax.com / Jn3OLmh0xd")
        print("  📍 期望结果: 地点定位和距离筛选功能正常工作")
    else:
        print("\n⚠️ 操作完成但验证存在问题，请检查数据")

if __name__ == "__main__":
    main()
