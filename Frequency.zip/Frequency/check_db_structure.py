#!/usr/bin/env python3
"""
检查数据库表结构
"""

from supabase import create_client, Client

# Supabase配置
SUPABASE_URL = 'https://xyjsbpahmcisxvydbkxr.supabase.co'
SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh5anNicGFobWNpc3h2eWRia3hyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNjcwMDUsImV4cCI6MjA2ODk0MzAwNX0.DWMcfP28qQKCVmhJvrFyU1ROglbtKaPPRlQSPQemwTI'

def check_table_structure():
    """检查数据库表结构"""
    supabase = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)
    
    print("🔍 检查数据库表结构...")
    
    try:
        # 尝试查询活动表的一条记录来了解字段结构
        print("检查 hz_coffee_chat_activities 表结构...")
        response = supabase.table('hz_coffee_chat_activities').select('*').limit(1).execute()
        
        if response.data and len(response.data) > 0:
            activity = response.data[0]
            print("✅ 表存在，字段包括:")
            for key in sorted(activity.keys()):
                print(f"  - {key}: {type(activity[key]).__name__}")
        else:
            print("⚠️ 表为空，尝试获取表结构...")
            # 创建一个测试记录来查看字段
            test_activity = {
                'title': 'TEST',
                'organizer_id': 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
                'description': 'TEST',
                'start_datetime': '2025-01-28T14:00:00+08:00',
                'end_datetime': '2025-01-28T16:00:00+08:00',
                'status': 'recruiting'
            }
            
            try:
                response = supabase.table('hz_coffee_chat_activities').insert(test_activity).execute()
                if response.data:
                    print("✅ 基础字段测试成功")
                    # 删除测试记录
                    supabase.table('hz_coffee_chat_activities').delete().eq('title', 'TEST').execute()
            except Exception as e:
                print(f"❌ 基础字段测试失败: {e}")
                
        # 测试地点字段是否存在
        print("\n测试地点定位字段...")
        test_activity_with_location = {
            'title': 'TEST_LOCATION',
            'organizer_id': 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
            'description': 'TEST',
            'start_datetime': '2025-01-28T14:00:00+08:00',
            'end_datetime': '2025-01-28T16:00:00+08:00',
            'location_name': '测试地点',
            'latitude': 31.2304,
            'longitude': 121.4737,
            'status': 'recruiting'
        }
        
        try:
            response = supabase.table('hz_coffee_chat_activities').insert(test_activity_with_location).execute()
            if response.data:
                print("✅ 地点定位字段存在且可用")
                # 删除测试记录
                supabase.table('hz_coffee_chat_activities').delete().eq('title', 'TEST_LOCATION').execute()
                return True
        except Exception as e:
            print(f"❌ 地点定位字段不存在或不可用: {e}")
            return False
            
    except Exception as e:
        print(f"❌ 检查表结构时出错: {e}")
        return False

if __name__ == "__main__":
    check_table_structure()
