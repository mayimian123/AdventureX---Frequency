# Coffee Chat Location test

The test could not be completed because the website was inaccessible.

## Key Files

