# coffee_chat_delete_test_local

由于无法在本地服务器上注册或登录账户，无法测试 Coffee Chat 活动的删除功能。建议检查本地服务器的注册和登录功能。

## Key Files

