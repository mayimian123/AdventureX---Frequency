# Coffee_Chat功能测试

测试失败：无法从Landing页面进入登录页面，测试被阻塞。

## Key Files

