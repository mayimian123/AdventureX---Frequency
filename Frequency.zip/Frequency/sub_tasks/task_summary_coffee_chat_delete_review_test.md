# coffee_chat_delete_review_test

无法成功创建新的 Coffee Chat 活动，导致无法测试删除和审核功能。建议检查创建活动的功能。

## Key Files

