# coffee_chat_delete_test

由于无法登录或注册账户，无法测试 Coffee Chat 活动的删除功能。建议检查网站的登录和注册功能。

## Key Files

