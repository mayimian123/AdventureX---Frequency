# coffee_chat_creation_and_deletion_test

无法在 `https://7kcb7nkxqghk.space.minimax.io` 上成功创建活动，导致无法测试删除功能。建议检查并修复活动创建功能。

## Key Files

