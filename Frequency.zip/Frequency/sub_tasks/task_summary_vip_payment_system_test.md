# vip_payment_system_test

由于无法访问目标网站，测试已中止。

## Key Files

