# coffee_chat_deletion_test

无法在 `https://93fin2xfuza8.space.minimax.io` 上通过“创建测试数据”功能创建测试活动，导致无法测试删除功能。建议检查并修复“创建测试数据”功能。

## Key Files

