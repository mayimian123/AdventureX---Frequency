# Hz 赫兹 - 社交网站

*[English](#english-version) | [中文](#中文版本)*

---

## 中文版本

### 🎯 项目简介

**Hz 赫兹** 是一款专为16-26岁年轻人设计的社交网站，通过"同频匹配"算法帮助用户连接频率相近的陌生人，解决新环境融入难、找不到同频伙伴、社交圈子固化等痛点。

### ✨ 核心特性

#### 🔄 智能匹配系统
- **同频算法**：基于兴趣标签、地理位置、专业领域等多维度匹配
- **Hz匹配度**：1-100Hz的精准匹配评分系统
- **个性化推荐**：智能推荐高匹配度用户

#### ☕ Coffee Chat功能
- **线下活动创建**：用户可创建和参与线下Coffee Chat活动
- **地理位置整合**：基于GPS的距离计算和筛选
- **活动管理**：完整的申请、审核、通知流程

#### 💬 实时聊天系统
- **即时通讯**：流畅的聊天体验
- **用户搜索**：支持按用户名和标签搜索
- **消息管理**：完整的聊天历史记录

#### 🎨 现代化UI设计
- **温暖社交风格**：橙色主题(#F97316)配暖白背景(#FEF7F0)
- **响应式设计**：完美适配桌面端和移动端
- **动画效果**：Hz波纹扩散、频率共振等品牌动画

#### 👑 VIP主理人系统
- **可选升级**：用户可选择成为VIP主理人获得额外特权
- **活动推广**：VIP用户可获得活动推广等特殊功能

### 🛠️ 技术栈

#### 前端技术
- **React 18** + **TypeScript** - 现代化前端框架
- **Vite** - 快速构建工具
- **Tailwind CSS** - 原子化CSS框架
- **Lucide React** - 现代图标库
- **React Router** - 客户端路由

#### 后端技术
- **Supabase** - 全栈后端服务
  - PostgreSQL数据库
  - 实时订阅功能
  - 用户认证系统
  - Edge Functions
  - 文件存储

#### 地图服务
- **Google Maps API** - 地理位置和地图功能

#### 部署平台
- **MiniMax Space** - 生产环境部署

### 🚀 快速开始

#### 环境要求
- Node.js 18+
- pnpm 或 npm
- 现代浏览器支持

#### 本地开发

1. **克隆项目**
```bash
git clone <repository-url>
cd hz-social
```

2. **安装依赖**
```bash
pnpm install
# 或
npm install
```

3. **环境配置**
创建 `.env.local` 文件：
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_GOOGLE_MAPS_API_KEY=your_google_maps_api_key
```

4. **启动开发服务器**
```bash
pnpm dev
# 或
npm run dev
```

5. **访问应用**
打开浏览器访问 `http://localhost:5173`

#### 构建生产版本

```bash
pnpm build
# 或
npm run build
```

### 📱 设备支持

- **桌面端**：Chrome、Firefox、Safari、Edge
- **移动端**：iOS Safari、Android Chrome
- **响应式断点**：768px（移动端/桌面端切换）

### 🎨 设计系统

#### 颜色主题
- **主色调**：#F97316 (温暖橙色)
- **背景色**：#FEF7F0 (暖白色)
- **文字色**：#1F2937 (深灰色)
- **边框色**：#FED7AA (浅橙色)

#### 字体系统
- **主字体**：Nunito, PingFang SC
- **强调字体**：Poppins
- **圆角系统**：16px标准圆角

### 📊 数据库架构

- **hz_users** - 用户信息表
- **hz_coffee_chat_activities** - Coffee Chat活动表
- **hz_messages** - 聊天消息表
- **hz_matches** - 用户匹配表
- **hz_user_subscriptions** - VIP订阅表
- **hz_user_location_cache** - 用户位置缓存表

### 🔧 开发指南

#### 项目结构
```
hz-social/
├── src/
│   ├── components/          # 可复用组件
│   │   ├── ui/             # UI基础组件
│   │   └── Sidebar.tsx     # 桌面端侧边栏
│   ├── pages/              # 页面组件
│   │   ├── app/            # 应用内页面
│   │   └── LandingPage.tsx # 着陆页
│   ├── lib/                # 工具库
│   ├── hooks/              # 自定义Hooks
│   ├── contexts/           # React Context
│   └── types/              # TypeScript类型定义
├── supabase/               # 后端配置
│   ├── functions/          # Edge Functions
│   ├── migrations/         # 数据库迁移
│   └── tables/             # 表结构定义
└── public/                 # 静态资源
```

#### 移动端适配
- 使用`useIsMobile` Hook检测设备类型
- 桌面端：左侧边栏导航
- 移动端：底部Tab导航 + 顶部标题栏 + 抽屉式菜单

### 📝 测试账户

**普通用户账户：**
- 邮箱：naovcaln@minimax.com
- 密码：123456

**VIP测试账户：**
- 邮箱：vip@hz-social.test
- 密码：123456

### 🌐 在线演示

**生产环境：** [https://z5jjfd52lycb.space.minimax.io](https://z5jjfd52lycb.space.minimax.io)

### 🤝 贡献指南

1. Fork 项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

### 📄 许可证

此项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

### 👨‍💻 开发团队

由 **MiniMax Agent** 开发和维护

---

## English Version

### 🎯 Project Overview

**Hz 赫兹** is a social networking website designed for young people aged 16-26, using a "frequency matching" algorithm to help users connect with like-minded strangers, solving problems like difficulty integrating into new environments, finding compatible companions, and social circle stagnation.

### ✨ Core Features

#### 🔄 Intelligent Matching System
- **Frequency Algorithm**: Multi-dimensional matching based on interests, location, professional fields
- **Hz Matching Score**: Precise 1-100Hz scoring system
- **Personalized Recommendations**: Smart recommendations for high-compatibility users

#### ☕ Coffee Chat Functionality
- **Offline Event Creation**: Users can create and participate in offline Coffee Chat activities
- **Geographic Integration**: GPS-based distance calculation and filtering
- **Event Management**: Complete application, review, and notification workflow

#### 💬 Real-time Chat System
- **Instant Messaging**: Smooth chat experience
- **User Search**: Search by username and tags
- **Message Management**: Complete chat history

#### 🎨 Modern UI Design
- **Warm Social Style**: Orange theme (#F97316) with warm white background (#FEF7F0)
- **Responsive Design**: Perfect adaptation for desktop and mobile
- **Animation Effects**: Hz ripple diffusion, frequency resonance brand animations

#### 👑 VIP Host System
- **Optional Upgrade**: Users can choose to become VIP hosts for additional privileges
- **Event Promotion**: VIP users get special features like event promotion

### 🛠️ Technology Stack

#### Frontend Technologies
- **React 18** + **TypeScript** - Modern frontend framework
- **Vite** - Fast build tool
- **Tailwind CSS** - Atomic CSS framework
- **Lucide React** - Modern icon library
- **React Router** - Client-side routing

#### Backend Technologies
- **Supabase** - Full-stack backend service
  - PostgreSQL database
  - Real-time subscriptions
  - User authentication
  - Edge Functions
  - File storage

#### Map Services
- **Google Maps API** - Geolocation and mapping functionality

#### Deployment Platform
- **MiniMax Space** - Production deployment

### 🚀 Quick Start

#### Requirements
- Node.js 18+
- pnpm or npm
- Modern browser support

#### Local Development

1. **Clone Repository**
```bash
git clone <repository-url>
cd hz-social
```

2. **Install Dependencies**
```bash
pnpm install
# or
npm install
```

3. **Environment Setup**
Create `.env.local` file:
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_GOOGLE_MAPS_API_KEY=your_google_maps_api_key
```

4. **Start Development Server**
```bash
pnpm dev
# or
npm run dev
```

5. **Access Application**
Open browser and visit `http://localhost:5173`

#### Build for Production

```bash
pnpm build
# or
npm run build
```

### 📱 Device Support

- **Desktop**: Chrome, Firefox, Safari, Edge
- **Mobile**: iOS Safari, Android Chrome
- **Responsive Breakpoint**: 768px (mobile/desktop switch)

### 🎨 Design System

#### Color Theme
- **Primary**: #F97316 (Warm Orange)
- **Background**: #FEF7F0 (Warm White)
- **Text**: #1F2937 (Dark Gray)
- **Border**: #FED7AA (Light Orange)

#### Typography
- **Primary Font**: Nunito, PingFang SC
- **Accent Font**: Poppins
- **Border Radius**: 16px standard radius

### 📊 Database Architecture

- **hz_users** - User information
- **hz_coffee_chat_activities** - Coffee Chat activities
- **hz_messages** - Chat messages
- **hz_matches** - User matches
- **hz_user_subscriptions** - VIP subscriptions
- **hz_user_location_cache** - User location cache

### 🔧 Development Guide

#### Project Structure
```
hz-social/
├── src/
│   ├── components/          # Reusable components
│   │   ├── ui/             # UI base components
│   │   └── Sidebar.tsx     # Desktop sidebar
│   ├── pages/              # Page components
│   │   ├── app/            # App pages
│   │   └── LandingPage.tsx # Landing page
│   ├── lib/                # Utility libraries
│   ├── hooks/              # Custom Hooks
│   ├── contexts/           # React Context
│   └── types/              # TypeScript type definitions
├── supabase/               # Backend configuration
│   ├── functions/          # Edge Functions
│   ├── migrations/         # Database migrations
│   └── tables/             # Table definitions
└── public/                 # Static assets
```

#### Mobile Adaptation
- Use `useIsMobile` Hook for device detection
- Desktop: Left sidebar navigation
- Mobile: Bottom tab navigation + top title bar + drawer menu

### 📝 Test Accounts

**Regular User Account:**
- Email: naovcaln@minimax.com
- Password: 123456

**VIP Test Account:**
- Email: vip@hz-social.test
- Password: 123456

### 🌐 Live Demo

**Production Environment:** [https://z5jjfd52lycb.space.minimax.io](https://z5jjfd52lycb.space.minimax.io)

### 🤝 Contributing

1. Fork the project
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

### 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details

### 👨‍💻 Development Team

Developed and maintained by **MiniMax Agent**

---

*🎉 欢迎体验Hz赫兹社交网站！ / Welcome to experience Hz Social Network!*
