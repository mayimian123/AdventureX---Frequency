import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { VibrateButton } from '@/components/ui/wave-animation'
import { HzLogo } from '@/components/ui/hz-logo'
import { Home, MessageCircle, Users, Coffee, Calendar, LogOut } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'

interface SidebarProps {
  className?: string
}

export function Sidebar({ className = '' }: SidebarProps) {
  const navigate = useNavigate()
  const location = useLocation()
  const { signOut } = useAuth()

  const menuItems = [
    {
      id: 'home',
      label: '首页',
      icon: Home,
      path: '/app'
    },
    {
      id: 'chat',
      label: '聊天',
      icon: MessageCircle,
      path: '/app/chat'
    },
    {
      id: 'match',
      label: '匹配',
      icon: Users,
      path: '/app/match'
    },
    {
      id: 'coffee-join',
      label: '加入Coffee Chat',
      icon: Coffee,
      path: '/app/coffee-join'
    },
    {
      id: 'coffee-my',
      label: '我的Coffee Chat',
      icon: Calendar,
      path: '/app/coffee-my'
    }
  ]

  const handleSignOut = async () => {
    await signOut()
    navigate('/')
  }

  return (
    <div className={`bg-hz-warm-surface border-r border-hz-warm-border h-full flex flex-col ${className}`}>
      {/* Logo */}
      <div className="p-6 border-b border-hz-warm-border">
        <div className="flex items-center justify-center">
          <HzLogo size="small" animated={true} showText={true} />
        </div>
      </div>

      {/* 菜单项 */}
      <div className="flex-1 py-4">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = location.pathname === item.path
          
          return (
            <VibrateButton
              key={item.id}
              onClick={() => navigate(item.path)}
              className={`w-full flex items-center px-6 py-3 text-left transition-colors font-warm ${
                isActive 
                  ? 'bg-hz-warm-social-warm text-hz-orange-600 border-r-2 border-hz-orange-500'
                  : 'text-hz-warm-text-secondary hover:bg-hz-warm-social-warm hover:text-hz-orange-500'
              }`}
            >
              <Icon size={20} className="mr-3" />
              <span className="text-sm font-medium">{item.label}</span>
            </VibrateButton>
          )
        })}
      </div>

      {/* 退出按钮 */}
      <div className="p-4 border-t border-hz-warm-border">
        <VibrateButton
          onClick={handleSignOut}
          className="w-full flex items-center px-4 py-2 text-left text-hz-warm-text-muted hover:text-hz-error hover:bg-red-50 rounded-full transition-colors font-warm"
        >
          <LogOut size={18} className="mr-3" />
          <span className="text-sm">退出登录</span>
        </VibrateButton>
      </div>
    </div>
  )
}