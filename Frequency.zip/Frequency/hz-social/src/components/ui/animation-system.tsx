import React, { useEffect, useRef, useState } from 'react'

// 动画入场容器
interface AnimatedContainerProps {
  children: React.ReactNode
  delay?: number
  duration?: number
  className?: string
  type?: 'slideUp' | 'fadeIn' | 'scaleIn' | 'slideLeft' | 'slideRight'
}

export function AnimatedContainer({ 
  children, 
  delay = 0, 
  duration = 600, 
  className = '', 
  type = 'slideUp' 
}: AnimatedContainerProps) {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), delay)
        }
      },
      { threshold: 0.1 }
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [delay])

  const getAnimationClass = () => {
    const baseClass = `transition-all duration-${duration}`
    
    if (!isVisible) {
      switch (type) {
        case 'slideUp':
          return `${baseClass} opacity-0 translate-y-8`
        case 'fadeIn':
          return `${baseClass} opacity-0`
        case 'scaleIn':
          return `${baseClass} opacity-0 scale-95`
        case 'slideLeft':
          return `${baseClass} opacity-0 -translate-x-8`
        case 'slideRight':
          return `${baseClass} opacity-0 translate-x-8`
        default:
          return `${baseClass} opacity-0 translate-y-8`
      }
    }
    
    return `${baseClass} opacity-100 translate-y-0 translate-x-0 scale-100`
  }

  return (
    <div ref={ref} className={`${getAnimationClass()} ${className}`}>
      {children}
    </div>
  )
}

// 数字滚动动画
interface CountUpProps {
  end: number
  duration?: number
  delay?: number
  className?: string
}

export function CountUp({ end, duration = 2000, delay = 0, className = '' }: CountUpProps) {
  const [count, setCount] = useState(0)
  const [started, setStarted] = useState(false)

  useEffect(() => {
    if (!started) return

    const startTime = Date.now()
    const timer = setInterval(() => {
      const elapsed = Date.now() - startTime
      const progress = Math.min(elapsed / duration, 1)
      
      // 使用缓动函数
      const easeOut = 1 - Math.pow(1 - progress, 3)
      setCount(Math.floor(end * easeOut))

      if (progress >= 1) {
        clearInterval(timer)
        setCount(end)
      }
    }, 16)

    return () => clearInterval(timer)
  }, [end, duration, started])

  useEffect(() => {
    const timer = setTimeout(() => setStarted(true), delay)
    return () => clearTimeout(timer)
  }, [delay])

  return <span className={className}>{count}</span>
}

// 悬浮卡片效果
interface HoverCardProps {
  children: React.ReactNode
  className?: string
  scale?: number
  shadow?: 'sm' | 'md' | 'lg' | 'xl'
}

export function HoverCard({ 
  children, 
  className = '', 
  scale = 1.02, 
  shadow = 'lg' 
}: HoverCardProps) {
  const shadowClasses = {
    sm: 'hover:shadow-md',
    md: 'hover:shadow-lg',
    lg: 'hover:shadow-xl',
    xl: 'hover:shadow-2xl'
  }

  return (
    <div 
      className={`
        transition-all duration-300 ease-out
        hover:scale-[${scale}] hover:-translate-y-1
        ${shadowClasses[shadow]}
        cursor-pointer
        ${className}
      `}
      style={{ 
        transform: 'translateZ(0)', // 启用硬件加速
        backfaceVisibility: 'hidden'
      }}
    >
      {children}
    </div>
  )
}

// 背景装饰波纹
export function BackgroundWaves() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* 大波纹 */}
      <div className="absolute top-10 left-10 w-96 h-96 rounded-full border border-hz-orange-100 opacity-30 animate-pulse"></div>
      <div 
        className="absolute top-20 left-20 w-80 h-80 rounded-full border border-hz-orange-200 opacity-40 animate-pulse"
        style={{ animationDelay: '1s', animationDuration: '3s' }}
      ></div>
      <div 
        className="absolute top-32 left-32 w-64 h-64 rounded-full border border-hz-orange-300 opacity-50 animate-pulse"
        style={{ animationDelay: '2s', animationDuration: '4s' }}
      ></div>
      
      {/* 右侧波纹 */}
      <div className="absolute top-32 right-10 w-72 h-72 rounded-full border border-hz-orange-100 opacity-25 animate-pulse"></div>
      <div 
        className="absolute top-40 right-20 w-56 h-56 rounded-full border border-hz-orange-200 opacity-35 animate-pulse"
        style={{ animationDelay: '1.5s', animationDuration: '3.5s' }}
      ></div>
      
      {/* 底部波纹 */}
      <div className="absolute bottom-20 left-1/3 w-64 h-64 rounded-full border border-hz-orange-100 opacity-20 animate-pulse"></div>
      <div 
        className="absolute bottom-10 right-1/4 w-48 h-48 rounded-full border border-hz-orange-200 opacity-30 animate-pulse"
        style={{ animationDelay: '0.5s', animationDuration: '2.5s' }}
      ></div>
    </div>
  )
}

// 浮动粒子系统
export function FloatingParticles() {
  const particles = Array.from({ length: 12 }, (_, i) => i)

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((i) => (
        <div
          key={i}
          className="absolute w-2 h-2 bg-hz-orange-300 rounded-full opacity-20"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationName: `float-${i % 3}`,
            animationDuration: `${4 + Math.random() * 4}s`,
            animationIterationCount: 'infinite',
            animationTimingFunction: 'linear',
            animationDelay: `${Math.random() * 2}s`
          }}
        />
      ))}
      

    </div>
  )
}

// 渐变背景装饰
export function GradientDecoration() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* 左上角渐变 */}
      <div className="absolute -top-40 -left-40 w-80 h-80 bg-gradient-to-br from-hz-orange-100 to-transparent rounded-full opacity-30 blur-3xl"></div>
      
      {/* 右下角渐变 */}
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-gradient-to-tl from-hz-orange-200 to-transparent rounded-full opacity-25 blur-3xl"></div>
      
      {/* 中心装饰 */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-gradient-to-r from-transparent via-hz-orange-50 to-transparent rounded-full opacity-20 blur-2xl"></div>
    </div>
  )
}

// 进度环组件
interface ProgressRingProps {
  percentage: number
  size?: number
  strokeWidth?: number
  className?: string
  children?: React.ReactNode
}

export function ProgressRing({ 
  percentage, 
  size = 120, 
  strokeWidth = 8, 
  className = '',
  children 
}: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2
  const circumference = radius * 2 * Math.PI
  const offset = circumference - (percentage / 100) * circumference

  return (
    <div className={`relative ${className}`} style={{ width: size, height: size }}>
      <svg
        className="transform -rotate-90 w-full h-full"
        width={size}
        height={size}
      >
        <defs>
          <linearGradient id="progress-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#FB923C" />
            <stop offset="50%" stopColor="#F97316" />
            <stop offset="100%" stopColor="#EA580C" />
          </linearGradient>
        </defs>
        
        {/* 背景圆环 */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="transparent"
          className="text-gray-200"
        />
        
        {/* 进度圆环 */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="url(#progress-gradient)"
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
        />
      </svg>
      
      {/* 中心内容 */}
      <div className="absolute inset-0 flex items-center justify-center">
        {children}
      </div>
    </div>
  )
}
