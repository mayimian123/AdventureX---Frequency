import React from 'react'
import { Button } from '@/components/ui/button'
import { CoffeeChatActivity, ActivityParticipant, HzUser } from '@/types'
import { formatDateTime } from '@/lib/utils'
import { X, Calendar, MapPin, Users, Target, Clock } from 'lucide-react'

interface ActivityWithParticipants extends CoffeeChatActivity {
  participants: (ActivityParticipant & { user: HzUser })[]
}

interface ActivityDetailModalProps {
  activity: ActivityWithParticipants | null
  isOpen: boolean
  onClose: () => void
  isOrganizer?: boolean
}

export function ActivityDetailModal({ activity, isOpen, onClose, isOrganizer = false }: ActivityDetailModalProps) {
  if (!isOpen || !activity) return null

  const confirmedParticipants = activity.participants.filter(p => p.status === 'confirmed')
  const pendingParticipants = activity.participants.filter(p => p.status === 'pending')
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* 头部 */}
        <div className="flex items-start justify-between p-6 border-b border-gray-200">
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">{activity.title}</h2>
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <div className="flex items-center space-x-1">
                <Calendar size={14} />
                <span>{formatDateTime(activity.start_datetime)}</span>
              </div>
              
              <div className="flex items-center space-x-1">
                <MapPin size={14} />
                <span>{activity.location_city}</span>
              </div>
              
              <div className="flex items-center space-x-1">
                <Users size={14} />
                <span>{confirmedParticipants.length}/{activity.max_participants}人</span>
              </div>
            </div>
          </div>
          
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={20} />
          </Button>
        </div>
        
        {/* 内容 */}
        <div className="p-6 space-y-6">
          {/* 活动描述 */}
          {activity.description && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">活动描述</h3>
              <p className="text-gray-700 leading-relaxed">{activity.description}</p>
            </div>
          )}
          
          {/* 活动目标 */}
          {activity.goal && (
            <div className="flex items-start space-x-3">
              <Target className="text-gray-400 mt-1" size={18} />
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">活动目标</h3>
                <p className="text-gray-700">{activity.goal}</p>
              </div>
            </div>
          )}
          
          {/* 目标标签 */}
          {activity.target_tags && activity.target_tags.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">目标群体</h3>
              <div className="flex flex-wrap gap-2">
                {activity.target_tags.map((tag, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-hz-orange-100 text-hz-orange-600 rounded-full text-sm font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {/* 地址信息 */}
          <div className="flex items-start space-x-3">
            <MapPin className="text-gray-400 mt-1" size={18} />
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">活动地址</h3>
              <div className="text-gray-700 space-y-1">
                <p>{activity.location_country} {activity.location_province} {activity.location_city}</p>
                {activity.location_address && <p>{activity.location_address}</p>}
                {activity.location_detailed_address && <p className="text-sm text-gray-600">{activity.location_detailed_address}</p>}
              </div>
            </div>
          </div>
          
          {/* 时间信息 */}
          <div className="flex items-start space-x-3">
            <Clock className="text-gray-400 mt-1" size={18} />
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">时间安排</h3>
              <div className="text-gray-700 space-y-1">
                <p>开始: {formatDateTime(activity.start_datetime)}</p>
                <p>结束: {formatDateTime(activity.end_datetime)}</p>
              </div>
            </div>
          </div>
          
          {/* 参与者信息 */}
          {confirmedParticipants.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">参与者 ({confirmedParticipants.length}人)</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {confirmedParticipants.map((participant) => (
                  <div key={participant.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <img
                      src={participant.user.avatar_url || '/avatars/default.jpg'}
                      alt={participant.user.nickname}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{participant.user.nickname}</p>
                      <p className="text-sm text-gray-600">{participant.user.role}</p>
                    </div>
                    {isOrganizer && (
                      <span className="text-xs text-green-600 bg-green-100 px-2 py-1 rounded-full">
                        组织者
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* 等待审核的申请者（仅组织者可见）*/}
          {isOrganizer && pendingParticipants.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">待审核申请 ({pendingParticipants.length}人)</h3>
              <div className="space-y-2">
                {pendingParticipants.map((participant) => (
                  <div key={participant.id} className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
                    <img
                      src={participant.user.avatar_url || '/avatars/default.jpg'}
                      alt={participant.user.nickname}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{participant.user.nickname}</p>
                      <p className="text-sm text-gray-600">{participant.user.role}</p>
                      <p className="text-xs text-gray-500">申请时间: {formatDateTime(participant.applied_at)}</p>
                    </div>
                    <span className="text-xs text-yellow-600 bg-yellow-100 px-2 py-1 rounded-full">
                      待审核
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* 活动状态 */}
          <div className="pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  activity.status === 'recruiting' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'
                }`}>
                  {activity.status === 'recruiting' ? '招募中' : '已结束'}
                </span>
              </div>
              
              <div className="text-sm text-gray-600">
                创建时间: {formatDateTime(activity.created_at)}
              </div>
            </div>
          </div>
        </div>
        
        {/* 底部按钮 */}
        <div className="flex justify-end p-6 border-t border-gray-200">
          <Button onClick={onClose} variant="outline">
            关闭
          </Button>
        </div>
      </div>
    </div>
  )
}