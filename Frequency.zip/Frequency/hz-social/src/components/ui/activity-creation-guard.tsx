import React, { useState } from 'react';
import { AlertTriangle, Sparkles } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Card } from './card';
import { VipStatusDisplay } from './vip-status-display';

interface ActivityCreationGuardProps {
  onPermissionGranted: () => void;
  children: React.ReactNode;
  className?: string;
  showVipPromotion?: boolean;
}

export const ActivityCreationGuard: React.FC<ActivityCreationGuardProps> = ({
  onPermissionGranted,
  children,
  className = '',
  showVipPromotion = true
}) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className={`flex items-center justify-center p-8 ${className}`}>
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">正在加载...</p>
        </div>
      </div>
    );
  }

  // 如果用户未登录，显示登录提示
  if (!user) {
    return (
      <Card className={`p-6 text-center ${className}`}>
        <AlertTriangle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          需要登录
        </h3>
        <p className="text-gray-600 mb-4">
          请先登录后再创建活动
        </p>
      </Card>
    );
  }

  // 已登录用户可以直接创建活动
  return (
    <div className={className}>
      {/* VIP状态展示和推广（可选） */}
      {showVipPromotion && (
        <div className="mb-6">
          <VipStatusDisplay 
            className=""
            showUpgradeButton={true}
          />
        </div>
      )}
      
      {/* 免费用户友好提示 */}
      <div className="mb-4 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-100 rounded-full">
            <Sparkles className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h4 className="font-medium text-gray-900">
              🎉 免费创建Coffee Chat活动
            </h4>
            <p className="text-sm text-gray-600">
              所有用户都可以免费创办活动，连接志同道合的朋友！
            </p>
          </div>
        </div>
      </div>
      
      {/* 直接显示创建活动的子组件 */}
      {children}
    </div>
  );
};