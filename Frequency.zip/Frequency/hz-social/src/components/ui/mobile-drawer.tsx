import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { X, User, Settings, HelpCircle, LogOut, Crown, Heart, LucideIcon } from 'lucide-react'
import { HzLogo } from '@/components/ui/hz-logo'
import { useAuth } from '@/contexts/AuthContext'
import { cn } from '@/lib/utils'

interface MobileDrawerProps {
  isOpen: boolean
  onClose: () => void
}

interface DrawerMenuItem {
  id: string
  label: string
  icon: LucideIcon
  onClick: () => void
  className?: string
}

export function MobileDrawer({ isOpen, onClose }: MobileDrawerProps) {
  const navigate = useNavigate()
  const { user, signOut } = useAuth()
  
  // 防止背景滚动
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
    
    return () => {
      document.body.style.overflow = 'unset'
    }
  }, [isOpen])
  
  const handleSignOut = async () => {
    await signOut()
    onClose()
    navigate('/')
  }
  
  const menuItems: DrawerMenuItem[] = [
    {
      id: 'profile',
      label: '个人资料',
      icon: User,
      onClick: () => {
        // TODO: 导航到个人资料页面
        onClose()
      }
    },
    {
      id: 'vip',
      label: 'VIP会员',
      icon: Crown,
      onClick: () => {
        // TODO: 导航到VIP页面
        onClose()
      },
      className: 'text-hz-orange-500'
    },
    {
      id: 'favorites',
      label: '我的收藏',
      icon: Heart,
      onClick: () => {
        // TODO: 导航到收藏页面
        onClose()
      }
    },
    {
      id: 'settings',
      label: '设置',
      icon: Settings,
      onClick: () => {
        // TODO: 导航到设置页面
        onClose()
      }
    },
    {
      id: 'help',
      label: '帮助与反馈',
      icon: HelpCircle,
      onClick: () => {
        // TODO: 导航到帮助页面
        onClose()
      }
    }
  ]
  
  if (!isOpen) return null

  return (
    <>
      {/* 背景遮罩 */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 md:hidden"
        onClick={onClose}
      />
      
      {/* 抽屉内容 */}
      <div className={cn(
        "fixed left-0 top-0 bottom-0 w-80 max-w-[85vw] bg-white z-50 md:hidden",
        "transform transition-transform duration-300 ease-in-out",
        "shadow-2xl border-r border-hz-warm-border",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* 顶部状态栏占位 */}
        <div className="h-safe-area-inset-top bg-hz-warm-bg" />
        
        {/* 头部区域 */}
        <div className="bg-hz-warm-bg px-6 py-6 border-b border-hz-warm-border">
          <div className="flex items-center justify-between mb-6">
            <HzLogo size="small" animated={true} showText={true} />
            <button
              onClick={onClose}
              className="flex items-center justify-center w-8 h-8 rounded-full text-hz-warm-text-secondary hover:bg-hz-warm-social-warm hover:text-hz-orange-500 transition-all"
            >
              <X size={18} />
            </button>
          </div>
          
          {/* 用户信息 */}
          {user && (
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-hz-orange-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                {user.email?.[0]?.toUpperCase() || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold font-warm truncate">
                  {user.email}
                </p>
                <p className="text-xs text-hz-warm-text-muted">
                  Hz 社交用户
                </p>
              </div>
            </div>
          )}
        </div>
        
        {/* 菜单列表 */}
        <div className="flex-1 py-4">
          {menuItems.map((item) => {
            const Icon = item.icon
            
            return (
              <button
                key={item.id}
                onClick={item.onClick}
                className={cn(
                  "w-full flex items-center px-6 py-3.5 text-left transition-colors font-warm",
                  "hover:bg-hz-warm-social-warm active:bg-hz-warm-social-warm/70",
                  item.className || "text-hz-warm-text-secondary hover:text-hz-orange-500"
                )}
              >
                <Icon size={18} className="mr-3.5 flex-shrink-0" />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            )
          })}
        </div>
        
        {/* 底部退出按钮 */}
        <div className="border-t border-hz-warm-border p-4">
          <button
            onClick={handleSignOut}
            className="w-full flex items-center px-4 py-3 text-left text-hz-error hover:bg-red-50 active:bg-red-100 rounded-xl transition-all font-warm"
          >
            <LogOut size={18} className="mr-3.5" />
            <span className="text-sm font-medium">退出登录</span>
          </button>
        </div>
        
        {/* 安全区域底部填充 */}
        <div className="h-safe-area-inset-bottom bg-white" />
      </div>
    </>
  )
}
