import React from 'react'

interface WaveAnimationProps {
  className?: string
  color?: string
}

export function WaveAnimation({ className = '', color = '#64B5F6' }: WaveAnimationProps) {
  return (
    <div className={`relative ${className}`}>
      <svg
        className="absolute inset-0 w-full h-full"
        viewBox="0 0 400 400"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="waveGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={color} stopOpacity="0.1" />
            <stop offset="50%" stopColor={color} stopOpacity="0.3" />
            <stop offset="100%" stopColor={color} stopOpacity="0.1" />
          </linearGradient>
        </defs>
        
        {/* 波浪1 */}
        <path
          d="M0,200 Q100,150 200,200 T400,200 L400,400 L0,400 Z"
          fill="url(#waveGradient)"
          className="animate-pulse"
        >
          <animate
            attributeName="d"
            dur="3s"
            repeatCount="indefinite"
            values="M0,200 Q100,150 200,200 T400,200 L400,400 L0,400 Z;
                    M0,200 Q100,250 200,200 T400,200 L400,400 L0,400 Z;
                    M0,200 Q100,150 200,200 T400,200 L400,400 L0,400 Z"
          />
        </path>
        
        {/* 波浪2 */}
        <path
          d="M0,250 Q100,200 200,250 T400,250 L400,400 L0,400 Z"
          fill={color}
          fillOpacity="0.1"
        >
          <animate
            attributeName="d"
            dur="4s"
            repeatCount="indefinite"
            values="M0,250 Q100,200 200,250 T400,250 L400,400 L0,400 Z;
                    M0,250 Q100,300 200,250 T400,250 L400,400 L0,400 Z;
                    M0,250 Q100,200 200,250 T400,250 L400,400 L0,400 Z"
          />
        </path>
        
        {/* 波浪3 */}
        <path
          d="M0,300 Q100,250 200,300 T400,300 L400,400 L0,400 Z"
          fill={color}
          fillOpacity="0.05"
        >
          <animate
            attributeName="d"
            dur="5s"
            repeatCount="indefinite"
            values="M0,300 Q100,250 200,300 T400,300 L400,400 L0,400 Z;
                    M0,300 Q100,350 200,300 T400,300 L400,400 L0,400 Z;
                    M0,300 Q100,250 200,300 T400,300 L400,400 L0,400 Z"
          />
        </path>
        
        {/* 频率线条 */}
        <g stroke={color} strokeWidth="2" fill="none" opacity="0.3">
          <line x1="50" y1="100" x2="350" y2="100" className="animate-pulse" />
          <line x1="50" y1="120" x2="350" y2="120" className="animate-pulse" style={{ animationDelay: '0.5s' }} />
          <line x1="50" y1="140" x2="350" y2="140" className="animate-pulse" style={{ animationDelay: '1s' }} />
        </g>
      </svg>
    </div>
  )
}

// Hz 符号组件
export function HzSymbol({ className = '', size = 24 }: { className?: string, size?: number }) {
  return (
    <div className={`inline-flex items-center ${className}`} style={{ fontSize: `${size}px` }}>
      <span className="font-bold text-hz-orange-500">Hz</span>
    </div>
  )
}

// 振动反馈组件
export function VibrateButton({ 
  children, 
  onClick, 
  className = '',
  ...props 
}: {
  children: React.ReactNode
  onClick?: () => void
  className?: string
  [key: string]: any
}) {
  const handleClick = () => {
    // 添加振动反馈动画
    const button = document.activeElement as HTMLElement
    if (button) {
      button.style.transform = 'scale(0.95)'
      setTimeout(() => {
        button.style.transform = 'scale(1)'
      }, 100)
    }
    
    // 触发震动反馈（如果设备支持）
    if ('vibrate' in navigator) {
      navigator.vibrate(50)
    }
    
    onClick && onClick()
  }

  return (
    <button
      onClick={handleClick}
      className={`transition-all duration-100 ease-in-out hover:scale-105 active:scale-95 ${className}`}
      {...props}
    >
      {children}
    </button>
  )
}