import React from 'react'

interface HzLogoProps {
  size?: 'small' | 'medium' | 'large' | 'xlarge'
  animated?: boolean
  showText?: boolean
  className?: string
}

const sizeConfig = {
  small: { 
    container: 'w-12 h-12', 
    text: 'text-lg', 
    textSpacing: 'ml-2' 
  },
  medium: { 
    container: 'w-16 h-16', 
    text: 'text-xl', 
    textSpacing: 'ml-3' 
  },
  large: { 
    container: 'w-24 h-24', 
    text: 'text-3xl', 
    textSpacing: 'ml-4' 
  },
  xlarge: { 
    container: 'w-32 h-32', 
    text: 'text-4xl md:text-6xl', 
    textSpacing: 'ml-6' 
  }
}

export function HzLogo({ 
  size = 'medium', 
  animated = true, 
  showText = true, 
  className = '' 
}: HzLogoProps) {
  const config = sizeConfig[size]
  
  return (
    <div className={`flex items-center ${className}`}>
      {/* Logo 图标 */}
      <div className={`relative ${config.container}`}>
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* 橙色渐变 */}
            <linearGradient id="hz-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FB923C" />
              <stop offset="50%" stopColor="#F97316" />
              <stop offset="100%" stopColor="#EA580C" />
            </linearGradient>
            
            {/* 发光效果 */}
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge> 
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          
          {/* 简约共振环 */}
          <circle
            cx="50"
            cy="50"
            r="40"
            fill="none"
            stroke="url(#hz-gradient)"
            strokeWidth="0.8"
            opacity="0.4"
            className={animated ? "animate-pulse" : ""}
          />
          
          {/* Hz 字母核心 - 简约设计 */}
          <g filter="url(#glow)" className={animated ? "animate-pulse" : ""} style={{ animationDelay: '0.1s' }}>
            {/* H - 更粗的线条，更简洁 */}
            <rect x="35" y="32" width="4" height="36" fill="url(#hz-gradient)" rx="1" />
            <rect x="35" y="47" width="16" height="4" fill="url(#hz-gradient)" rx="1" />
            <rect x="47" y="32" width="4" height="36" fill="url(#hz-gradient)" rx="1" />
            
            {/* z - 简化设计 */}
            <rect x="57" y="47" width="12" height="4" fill="url(#hz-gradient)" rx="1" />
            <rect x="61" y="51" width="3" height="10" fill="url(#hz-gradient)" rx="1" />
            <rect x="57" y="61" width="12" height="4" fill="url(#hz-gradient)" rx="1" />
          </g>
          
          {/* 简约呼吸效果 */}
          {animated && (
            <circle cx="50" cy="50" r="20" fill="none" stroke="url(#hz-gradient)" strokeWidth="0.5" opacity="0.3">
              <animate
                attributeName="r"
                values="20;30;20"
                dur="3s"
                repeatCount="indefinite"
              />
              <animate
                attributeName="opacity"
                values="0.3;0.1;0.3"
                dur="3s"
                repeatCount="indefinite"
              />
            </circle>
          )}
        </svg>
      </div>
      
      {/* 文字部分 */}
      {showText && (
        <span className={`font-accent font-bold text-hz-warm-text-primary ${config.text} ${config.textSpacing}`}>
          赫兹
        </span>
      )}
    </div>
  )
}

// 简化版Logo图标（只有图标部分）
export function HzIcon({ 
  size = 24, 
  animated = true, 
  className = '' 
}: { 
  size?: number
  animated?: boolean 
  className?: string 
}) {
  return (
    <div className={`inline-block ${className}`} style={{ width: size, height: size }}>
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id={`hz-gradient-${size}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FB923C" />
            <stop offset="50%" stopColor="#F97316" />
            <stop offset="100%" stopColor="#EA580C" />
          </linearGradient>
          
          <filter id={`glow-${size}`}>
            <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
            <feMerge> 
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        
        {/* 简约共振环 */}
        <circle
          cx="50"
          cy="50"
          r="40"
          fill="none"
          stroke={`url(#hz-gradient-${size})`}
          strokeWidth="0.8"
          opacity="0.4"
          className={animated ? "animate-pulse" : ""}
        />
        
        {/* Hz 字母核心 - 简约设计 */}
        <g filter={`url(#glow-${size})`} className={animated ? "animate-pulse" : ""} style={{ animationDelay: '0.1s' }}>
          {/* H - 更粗的线条，更简洁 */}
          <rect x="35" y="32" width="4" height="36" fill={`url(#hz-gradient-${size})`} rx="1" />
          <rect x="35" y="47" width="16" height="4" fill={`url(#hz-gradient-${size})`} rx="1" />
          <rect x="47" y="32" width="4" height="36" fill={`url(#hz-gradient-${size})`} rx="1" />
          
          {/* z - 简化设计 */}
          <rect x="57" y="47" width="12" height="4" fill={`url(#hz-gradient-${size})`} rx="1" />
          <rect x="61" y="51" width="3" height="10" fill={`url(#hz-gradient-${size})`} rx="1" />
          <rect x="57" y="61" width="12" height="4" fill={`url(#hz-gradient-${size})`} rx="1" />
        </g>
        
        {/* 简约呼吸效果 */}
        {animated && (
          <circle cx="50" cy="50" r="20" fill="none" stroke={`url(#hz-gradient-${size})`} strokeWidth="0.5" opacity="0.3">
            <animate
              attributeName="r"
              values="20;30;20"
              dur="3s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="0.3;0.1;0.3"
              dur="3s"
              repeatCount="indefinite"
            />
          </circle>
        )}
      </svg>
    </div>
  )
}
