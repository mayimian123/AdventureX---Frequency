import React from 'react'
import { Button } from '@/components/ui/button'
import { HzUser, ActivityParticipant } from '@/types'
import { X, MapPin, Briefcase, Calendar, Heart, Check } from 'lucide-react'

interface ApplicantWithUser extends ActivityParticipant {
  user: HzUser
}

interface ApplicantDetailModalProps {
  applicant: ApplicantWithUser | null
  isOpen: boolean
  onClose: () => void
  onApprove?: () => void
  onReject?: () => void
  actionLoading?: boolean
}

export function ApplicantDetailModal({ 
  applicant, 
  isOpen, 
  onClose, 
  onApprove, 
  onReject, 
  actionLoading = false 
}: ApplicantDetailModalProps) {
  if (!isOpen || !applicant) return null

  const user = applicant.user
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* 头部 */}
        <div className="flex items-start justify-between p-6 border-b border-gray-200">
          <div className="flex items-start space-x-4">
            <img
              src={user.avatar_url || '/avatars/default.jpg'}
              alt={user.nickname}
              className="w-16 h-16 rounded-full object-cover"
            />
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{user.nickname}</h2>
              <div className="flex items-center space-x-2 text-gray-600 mt-1">
                <span>{user.age}岁</span>
                <span>•</span>
                <div className="flex items-center space-x-1">
                  <MapPin size={14} />
                  <span>{user.location_city}</span>
                </div>
              </div>
              <div className="flex items-center space-x-1 text-gray-600 mt-1">
                <Briefcase size={14} />
                <span>{user.role}</span>
              </div>
            </div>
          </div>
          
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={20} />
          </Button>
        </div>
        
        {/* 内容 */}
        <div className="p-6 space-y-6">
          {/* 申请信息 */}
          <div className="bg-hz-orange-50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
              <Calendar className="mr-2" size={18} />
              申请信息
            </h3>
            <div className="space-y-3">
              <div>
                <p className="text-sm font-medium text-gray-700 mb-1">你能带来什么？</p>
                <p className="text-gray-700 bg-white p-3 rounded border">
                  {applicant.what_to_bring || '未填写'}
                </p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-700 mb-1">你希望获得什么？</p>
                <p className="text-gray-700 bg-white p-3 rounded border">
                  {applicant.what_to_get || '未填写'}
                </p>
              </div>
              
              <div className="text-sm text-gray-600">
                申请时间: {new Date(applicant.applied_at).toLocaleString('zh-CN')}
              </div>
            </div>
          </div>
          
          {/* 关于我 */}
          {user.about_me && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">关于我</h3>
              <p className="text-gray-700 leading-relaxed">{user.about_me}</p>
            </div>
          )}
          
          {/* 当前在做什么 */}
          {user.current_activity && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">目前在做什么</h3>
              <p className="text-gray-700">{user.current_activity}</p>
            </div>
          )}
          
          {/* 专业领域 */}
          {user.professional_fields && user.professional_fields.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">专业领域</h3>
              <div className="flex flex-wrap gap-2">
                {user.professional_fields.map((field, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-purple-100 text-purple-600 rounded-full text-sm font-medium"
                  >
                    {field}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {/* 兴趣标签 */}
          {user.interest_tags && user.interest_tags.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2 flex items-center">
                <Heart className="mr-1" size={16} />
                兴趣标签
              </h3>
              <div className="flex flex-wrap gap-2">
                {user.interest_tags.map((tag, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-hz-orange-100 text-hz-orange-600 rounded-full text-sm font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {/* 申请状态 */}
          <div className="pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  applicant.status === 'pending' ? 'bg-yellow-100 text-yellow-600' :
                  applicant.status === 'confirmed' ? 'bg-green-100 text-green-600' :
                  'bg-red-100 text-red-600'
                }`}>
                  {applicant.status === 'pending' ? '待审核' :
                   applicant.status === 'confirmed' ? '已通过' : '已拒绝'}
                </span>
              </div>
              
              <div className="text-sm text-gray-600">
                注册时间: {new Date(user.created_at).toLocaleDateString('zh-CN')}
              </div>
            </div>
          </div>
        </div>
        
        {/* 底部操作按钮 */}
        <div className="flex justify-between p-6 border-t border-gray-200">
          <Button onClick={onClose} variant="outline">
            关闭
          </Button>
          
          {applicant.status === 'pending' && onApprove && onReject && (
            <div className="flex space-x-3">
              <Button
                onClick={onReject}
                disabled={actionLoading}
                variant="destructive"
                className="flex items-center space-x-2"
              >
                <X size={16} />
                <span>拒绝</span>
              </Button>
              
              <Button
                onClick={onApprove}
                disabled={actionLoading}
                variant="warm"
                className="flex items-center space-x-2"
              >
                <Check size={16} />
                <span>通过</span>
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}