import React, { useState, useEffect, useCallback, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { MapPin, Navigation, Filter, Loader2 } from 'lucide-react'

// 距离筛选选项
const DISTANCE_OPTIONS = [
  { label: '全部', value: null, key: 'all' },
  { label: '附近2公里', value: 2, key: '2km' },
  { label: '10公里内', value: 10, key: '10km' },
  { label: '50公里内', value: 50, key: '50km' }
]

interface UserLocation {
  latitude: number
  longitude: number
  address?: string
  city?: string
}

interface DistanceFilterProps {
  onDistanceFilterChange: (maxDistance: number | null) => void
  onUserLocationChange: (location: UserLocation | null) => void
  className?: string
}

export function DistanceFilter({ 
  onDistanceFilterChange, 
  onUserLocationChange, 
  className = "" 
}: DistanceFilterProps) {
  const [selectedDistance, setSelectedDistance] = useState<number | null>(null)
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null)
  const [isGettingLocation, setIsGettingLocation] = useState(false)
  const [locationError, setLocationError] = useState<string | null>(null)
  const [locationPermissionDenied, setLocationPermissionDenied] = useState(false)
  
  // 🚨 **紧急开关：可以快速禁用位置功能**
  const LOCATION_FEATURE_ENABLED = true // 如果有问题，改为false
  
  // 🔧 **组件安全检查**
  const isMountedRef = useRef(true)
  const locationTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const hasLocationAttempted = useRef(false)
  
  useEffect(() => {
    return () => {
      isMountedRef.current = false
      // 清理定时器
      if (locationTimeoutRef.current) {
        clearTimeout(locationTimeoutRef.current)
        locationTimeoutRef.current = null
      }
      console.log('🧹 DistanceFilter组件卸载，已清理资源')
    }
  }, [])

  // 🔧 **增强安全的状态更新函数**
  const safeSetState = useCallback((setterFunction: () => void, operationName: string) => {
    try {
      if (isMountedRef.current) {
        setterFunction()
        console.log(`✅ 安全状态更新: ${operationName}`)
      } else {
        console.log(`⚠️ 组件已卸载，跳过状态更新: ${operationName}`)
      }
    } catch (error) {
      console.error(`❌ 状态更新失败: ${operationName}`, error)
    }
  }, [])

  // 📍 **强化的位置获取函数**
  const getCurrentLocation = useCallback(async () => {
    // 防止重复调用
    if (hasLocationAttempted.current) {
      console.log('⚠️ 位置获取已在进行中，跳过重复调用')
      return
    }

    try {
      hasLocationAttempted.current = true

      if (!navigator.geolocation) {
        throw new Error('您的浏览器不支持定位功能')
      }

      console.log('🚀 开始获取用户位置...')
      safeSetState(() => {
        setIsGettingLocation(true)
        setLocationError(null)
        setLocationPermissionDenied(false)
      }, '初始化位置获取状态')

      console.log('📍 调用浏览器定位API...')
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          resolve,
          reject,
          { 
            timeout: 10000, 
            enableHighAccuracy: true,
            maximumAge: 300000 // 5分钟缓存
          }
        )
      })

      console.log('✅ 位置获取成功:', position.coords)

      // 验证坐标有效性
      const latitude = position.coords.latitude
      const longitude = position.coords.longitude
      
      if (isNaN(latitude) || isNaN(longitude) || 
          latitude < -90 || latitude > 90 || 
          longitude < -180 || longitude > 180) {
        console.error('❌ 无效的坐标数据:', { latitude, longitude })
        throw new Error('Invalid coordinates received')
      }

      const location = {
        latitude,
        longitude
      }

      console.log('📍 处理位置数据:', location)

      // 安全地设置基础位置信息
      safeSetState(() => {
        setUserLocation(location)
        onUserLocationChange(location)
      }, '设置用户位置')
      
      console.log('✅ 位置状态已更新')

      // 异步尝试反向地理编码，但不阻塞主流程
      setTimeout(() => {
        tryReverseGeocode(location.latitude, location.longitude)
      }, 100)
      
    } catch (error: any) {
      console.error('❌ 获取位置失败:', error)
      
      safeSetState(() => {
        if (error.code === error.PERMISSION_DENIED) {
          setLocationPermissionDenied(true)
          setLocationError('位置权限被拒绝，请在浏览器设置中允许位置访问')
        } else if (error.code === error.TIMEOUT) {
          setLocationError('定位超时，请检查网络连接')
        } else {
          setLocationError('无法获取您的位置信息')
        }
        
        // 🔧 位置获取失败时，不设置任何位置，让页面使用普通模式
        setUserLocation(null)
        onUserLocationChange(null)
      }, '处理位置获取错误')
    } finally {
      // 重置尝试状态，允许下次重试
      setTimeout(() => {
        hasLocationAttempted.current = false
      }, 2000) // 2秒后可以重试
      
      safeSetState(() => {
        setIsGettingLocation(false)
      }, '完成位置获取')
      console.log('🏁 位置获取流程完成')
    }
  }, [onUserLocationChange, safeSetState])

  // 安全的反向地理编码尝试
  const tryReverseGeocode = async (lat: number, lng: number) => {
    try {
      console.log('🌍 尝试反向地理编码...', { lat, lng })
      
      // 检查Google Maps API是否可用
      if (!window.google || !window.google.maps || !window.google.maps.Geocoder) {
        console.log('⚠️ Google Maps API不可用，跳过反向地理编码')
        return
      }

      const geocoder = new window.google.maps.Geocoder()
      
      const result = await new Promise<any>((resolve, reject) => {
        geocoder.geocode({ location: { lat, lng } }, (results, status) => {
          if (status === 'OK' && results && results[0]) {
            resolve(results[0])
          } else {
            reject(new Error('Geocoding failed: ' + status))
          }
        })
      })

      console.log('🌍 反向地理编码成功:', result.formatted_address)
      
      // 安全地更新位置信息
      safeSetState(() => {
        setUserLocation(prev => {
          if (!prev) {
            console.log('⚠️ 用户位置已被清除，跳过地址更新')
            return null
          }
          
          try {
            const city = extractCityFromAddress(result.formatted_address)
            console.log('🏙️ 提取城市信息:', city)
            
            return {
              ...prev,
              address: result.formatted_address,
              city
            }
          } catch (error) {
            console.error('❌ 处理地址信息时出错:', error)
            return prev // 保持原有位置信息
          }
        })
      }, '更新地址信息')
      
    } catch (error) {
      console.warn('⚠️ 反向地理编码失败，继续使用坐标信息:', error)
      // 反向地理编码失败不影响主要功能
    }
  }

  // 原有的反向地理编码函数（保持兼容性）
  const reverseGeocode = async (lat: number, lng: number) => {
    return tryReverseGeocode(lat, lng)
  }

  // 从地址中提取城市
  const extractCityFromAddress = (address: string): string => {
    try {
      if (!address || typeof address !== 'string') {
        console.warn('⚠️ 无效的地址字符串:', address)
        return '未知城市'
      }

      console.log('🏙️ 分析地址:', address)
      
      const cityPatterns = [
        /([^省]+省)([^市]+市)/,
        /([^市]+市)/,
        /北京|上海|天津|重庆/
      ]
      
      for (const pattern of cityPatterns) {
        try {
          const match = address.match(pattern)
          if (match) {
            const city = match[2] || match[1]
            console.log('🏙️ 提取到城市:', city)
            return city
          }
        } catch (error) {
          console.warn('⚠️ 城市模式匹配出错:', error)
          continue
        }
      }
      
      // 备选方案：按区县分割
      try {
        const parts = address.split(/[区县]/)
        if (parts.length > 0 && parts[0]) {
          const city = parts[0].trim()
          console.log('🏙️ 按区县分割提取城市:', city)
          return city
        }
      } catch (error) {
        console.warn('⚠️ 地址分割出错:', error)
      }
      
      console.log('🏙️ 无法提取城市，使用默认值')
      return '未知城市'
      
    } catch (error) {
      console.error('❌ 提取城市信息时出错:', error)
      return '未知城市'
    }
  }

  // 处理距离筛选变化
  const handleDistanceFilterChange = (distance: number | null) => {
    // 只有在有用户位置时才允许距离筛选
    if (!userLocation && distance !== null) {
      console.warn('没有用户位置，无法进行距离筛选')
      return
    }
    
    setSelectedDistance(distance)
    onDistanceFilterChange(distance)
  }

  // 🔄 **组件初始化时的安全处理**
  useEffect(() => {
    try {
      if (LOCATION_FEATURE_ENABLED) {
        console.log('🎯 位置功能已启用，开始获取位置')
        
        // 延迟初始化，确保组件完全挂载
        locationTimeoutRef.current = setTimeout(() => {
          if (isMountedRef.current) {
            getCurrentLocation()
          }
        }, 100)
      } else {
        console.log('⚠️ 位置功能已禁用，跳过位置获取')
        safeSetState(() => {
          setLocationError('位置功能暂时不可用')
        }, '设置功能禁用状态')
      }
    } catch (error) {
      console.error('❌ 初始化位置功能时出错:', error)
      safeSetState(() => {
        setLocationError('位置功能初始化失败')
      }, '设置初始化错误')
    }
  }, []) // 移除所有依赖，避免循环

  // 🔧 **错误边界保护渲染**
  try {
    return (
      <div className={className}>
      {/* 位置状态卡片 */}
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="flex-shrink-0">
                {isGettingLocation ? (
                  <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                    <Loader2 className="w-4 h-4 text-gray-500 animate-spin" />
                  </div>
                ) : userLocation ? (
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <MapPin className="w-4 h-4 text-green-600" />
                  </div>
                ) : (
                  <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                    <MapPin className="w-4 h-4 text-red-600" />
                  </div>
                )}
              </div>
              
              <div className="flex-1">
                {isGettingLocation ? (
                  <div>
                    <p className="text-sm font-medium text-gray-900">正在获取位置...</p>
                    <p className="text-xs text-gray-500">为您推荐附近的活动</p>
                  </div>
                ) : userLocation ? (
                  <div>
                    <p className="text-sm font-medium text-green-700">位置已获取</p>
                    <p className="text-xs text-gray-500">
                      {userLocation.city || '当前位置'} • 显示距离信息
                    </p>
                  </div>
                ) : (
                  <div>
                    <p className="text-sm font-medium text-red-700">位置获取失败</p>
                    <p className="text-xs text-gray-500">
                      {locationError || '无法显示距离信息'}
                    </p>
                  </div>
                )}
              </div>
            </div>
            
            {!isGettingLocation && (
              <Button
                variant="outline"
                size="sm"
                onClick={getCurrentLocation}
                className="text-xs"
              >
                {userLocation ? '刷新位置' : '重新定位'}
              </Button>
            )}
          </div>
          
          {locationPermissionDenied && (
            <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm text-amber-800">
                💡 <strong>提示：</strong>要查看活动距离信息，请允许浏览器访问您的位置。
                您可以在地址栏左侧的位置图标中重新允许位置访问权限。
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 距离筛选器 */}
      {userLocation && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 mb-3">
              <Filter className="w-4 h-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-900">距离筛选</span>
            </div>
            
            <div className="flex flex-wrap gap-2">
              {DISTANCE_OPTIONS.map((option) => (
                <Button
                  key={option.key}
                  variant={selectedDistance === option.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleDistanceFilterChange(option.value)}
                  className={`text-xs ${
                    selectedDistance === option.value 
                      ? 'bg-hz-orange-500 hover:bg-hz-orange-600 text-white' 
                      : 'text-gray-600 hover:text-hz-orange-600 hover:border-hz-orange-300'
                  }`}
                >
                  {option.label}
                </Button>
              ))}
            </div>
            
            {selectedDistance && (
              <div className="mt-2 text-xs text-gray-500 flex items-center">
                <Navigation className="w-3 h-3 mr-1" />
                显示 {selectedDistance}公里内的活动
              </div>
            )}
          </CardContent>
        </Card>
      )}
      </div>
    )
  } catch (error) {
    // 🚨 **错误边界：如果组件渲染失败，显示降级界面**
    console.error('❌ DistanceFilter组件渲染错误:', error)
    
    return (
      <div className={className}>
        <Card className="mb-4">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                <MapPin className="w-4 h-4 text-red-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-red-700">位置功能暂时不可用</p>
                <p className="text-xs text-gray-500">系统出现问题，显示所有活动</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.location.reload()}
                className="text-xs"
              >
                刷新重试
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }
}

// 扩展Window接口以支持Google Maps
declare global {
  interface Window {
    google: any
  }
}
