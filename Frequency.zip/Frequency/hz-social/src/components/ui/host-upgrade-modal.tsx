import React, { useState, useEffect } from 'react';
import { X, Crown, Zap, Users, TrendingUp, CheckCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from './button';
import { Card } from './card';
import toast from 'react-hot-toast';

interface VipPackage {
  id: string;
  package_type: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  activities_included: number;
  duration_days: number;
}

interface HostUpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgradeSuccess?: () => void;
}

export const HostUpgradeModal: React.FC<HostUpgradeModalProps> = ({
  isOpen,
  onClose,
  onUpgradeSuccess
}) => {
  const { user } = useAuth();
  const [packages, setPackages] = useState<VipPackage[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);
  const [currentVipStatus, setCurrentVipStatus] = useState<any>(null);

  // 获取VIP套餐列表
  const fetchVipPackages = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('hz-host-upgrade', {
        body: { action: 'get_vip_packages' }
      });

      if (error) throw error;
      setPackages(data.packages || []);
    } catch (error) {
      console.error('获取VIP套餐失败:', error);
      toast.error('获取套餐信息失败');
    }
  };

  // 检查当前VIP状态
  const checkVipStatus = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('hz-host-upgrade', {
        body: { action: 'check_vip_status' }
      });

      if (error) throw error;
      setCurrentVipStatus(data);
    } catch (error) {
      console.error('检查VIP状态失败:', error);
    }
  };

  // 创建订阅支付
  const handleUpgrade = async (packageType: string) => {
    if (!user) {
      toast.error('请先登录');
      return;
    }

    setLoading(true);
    setSelectedPackage(packageType);

    try {
      const { data, error } = await supabase.functions.invoke('hz-host-upgrade', {
        body: { 
          action: 'create_subscription_checkout',
          packageType 
        }
      });

      if (error) throw error;

      if (data.checkoutUrl) {
        // 跳转到Stripe支付页面
        window.location.href = data.checkoutUrl;
      }
    } catch (error: any) {
      console.error('创建支付失败:', error);
      toast.error(error.message || '创建支付失败，请稍后重试');
    } finally {
      setLoading(false);
      setSelectedPackage(null);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchVipPackages();
      checkVipStatus();
    }
  }, [isOpen]);

  // 处理支付成功回调
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const subscriptionStatus = urlParams.get('vip_subscription');
    const sessionId = urlParams.get('session_id');

    if (subscriptionStatus === 'success' && sessionId) {
      // 处理支付成功
      handleSubscriptionSuccess(sessionId);
      // 清理URL参数
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (subscriptionStatus === 'cancelled') {
      toast.error('支付已取消，您可以随时重新尝试');
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  const handleSubscriptionSuccess = async (sessionId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('hz-host-upgrade', {
        body: { 
          action: 'handle_subscription_success',
          sessionId 
        }
      });

      if (error) throw error;

      toast.success(data.message || '🎉 恭喜成为赫兹VIP主理人！');
      onUpgradeSuccess?.();
      onClose();
    } catch (error: any) {
      console.error('处理支付成功失败:', error);
      toast.error('激活VIP会员失败，请联系客服');
    }
  };

  const getPackageIcon = (packageType: string) => {
    switch (packageType) {
      case 'monthly_vip': return <Zap className="w-6 h-6" />;
      case 'quarterly_vip': return <Users className="w-6 h-6" />;
      case 'annual_vip': return <Crown className="w-6 h-6" />;
      default: return <Crown className="w-6 h-6" />;
    }
  };

  const getPackageColor = (packageType: string) => {
    switch (packageType) {
      case 'monthly_vip': return 'from-blue-500 to-cyan-500';
      case 'quarterly_vip': return 'from-purple-500 to-pink-500';
      case 'annual_vip': return 'from-yellow-500 to-orange-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getPackageBadge = (packageType: string) => {
    switch (packageType) {
      case 'monthly_vip': return null;
      case 'quarterly_vip': return <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded-full">推荐</span>;
      case 'annual_vip': return <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">最优惠</span>;
      default: return null;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="relative p-6 border-b border-gray-100">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              <div className="p-3 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full text-white">
                <Crown className="w-8 h-8" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              成为赫兹VIP主理人
            </h2>
            <p className="text-gray-600">
              解锁专属权益，创建精彩的Coffee Chat活动，连接志同道合的朋友
            </p>
          </div>
        </div>

        {/* VIP权益展示 */}
        <div className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 text-center">
            🎯 VIP专属权益
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <p className="text-sm font-medium text-gray-800">创办专属活动</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
              <p className="text-sm font-medium text-gray-800">平台推广支持</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <CheckCircle className="w-6 h-6 text-purple-600" />
              </div>
              <p className="text-sm font-medium text-gray-800">深度数据洞察</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Crown className="w-6 h-6 text-yellow-600" />
              </div>
              <p className="text-sm font-medium text-gray-800">专属身份标识</p>
            </div>
          </div>
        </div>

        {/* 套餐选择 */}
        <div className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 text-center">
            💎 选择您的VIP增值套餐
          </h3>
          
          <div className="mb-6 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800 text-center">
              🎉 <strong>全平台用户均可免费创建活动</strong>，VIP为您提供更多增值服务和优先权益
            </p>
          </div>
          
          {currentVipStatus?.isVip && (
            <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl">
              <div className="flex items-center space-x-2 text-green-800">
                <CheckCircle className="w-5 h-5" />
                <span className="font-medium">您已经是VIP主理人</span>
              </div>
              <p className="text-green-700 text-sm mt-1">
                当前套餐：{currentVipStatus.subscriptionType} | 正在享受VIP增值服务
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {packages.map((pkg) => (
              <Card key={pkg.id} className="relative overflow-hidden transition-all duration-300 hover:shadow-lg hover:scale-105">
                <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${getPackageColor(pkg.package_type)}`} />
                
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-2 rounded-full bg-gradient-to-br ${getPackageColor(pkg.package_type)} text-white`}>
                      {getPackageIcon(pkg.package_type)}
                    </div>
                    {getPackageBadge(pkg.package_type)}
                  </div>
                  
                  <h4 className="text-xl font-bold text-gray-900 mb-2">
                    {pkg.name}
                  </h4>
                  
                  <p className="text-gray-600 text-sm mb-4">
                    {pkg.description}
                  </p>
                  
                  <div className="mb-6">
                    <div className="flex items-baseline">
                      <span className="text-3xl font-bold text-gray-900">¥{pkg.price}</span>
                      <span className="text-gray-600 ml-1">/{pkg.duration_days === 30 ? '月' : pkg.duration_days === 90 ? '季' : '年'}</span>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">
                      包含 {pkg.activities_included} 次活动创办
                    </p>
                  </div>
                  
                  <Button
                    onClick={() => handleUpgrade(pkg.package_type)}
                    disabled={loading}
                    className={`w-full bg-gradient-to-r ${getPackageColor(pkg.package_type)} hover:opacity-90 transition-opacity`}
                  >
                    {loading && selectedPackage === pkg.package_type ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>处理中...</span>
                      </div>
                    ) : (
                      currentVipStatus?.isVip ? '升级到此套餐' : '立即购买'
                    )}
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 bg-gray-50 text-center text-sm text-gray-600">
          <p>
            💡 选择VIP套餐后，您将获得专属的活动创办权限和平台支持
          </p>
          <p className="mt-1">
            如有疑问，请联系客服：support@hz-social.com
          </p>
        </div>
      </div>
    </div>
  );
};