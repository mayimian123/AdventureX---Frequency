import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { Home, MessageCircle, Users, Coffee, Calendar, LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

interface NavItem {
  id: string
  label: string
  icon: LucideIcon
  path: string
}

const navItems: NavItem[] = [
  {
    id: 'home',
    label: '首页',
    icon: Home,
    path: '/app'
  },
  {
    id: 'chat',
    label: '聊天',
    icon: MessageCircle,
    path: '/app/chat'
  },
  {
    id: 'match',
    label: '匹配',
    icon: Users,
    path: '/app/match'
  },
  {
    id: 'coffee-join',
    label: '加入',
    icon: Coffee,
    path: '/app/coffee-join'
  },
  {
    id: 'coffee-my',
    label: '我的',
    icon: Calendar,
    path: '/app/coffee-my'
  }
]

export function MobileBottomNav() {
  const navigate = useNavigate()
  const location = useLocation()

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden">
      {/* 导航栏背景 */}
      <div className="bg-white/95 backdrop-blur-md border-t border-hz-warm-border">
        {/* 导航项容器 */}
        <div className="flex items-center justify-around px-2 py-2 safe-area-inset-bottom">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = location.pathname === item.path
            
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.path)}
                className={cn(
                  "flex flex-col items-center justify-center min-w-[44px] min-h-[44px] px-2 py-1 rounded-xl transition-all duration-200 font-warm",
                  "active:scale-95 hover:bg-hz-warm-social-warm",
                  isActive 
                    ? "bg-hz-orange-500 text-white shadow-lg shadow-hz-orange-500/25" 
                    : "text-hz-warm-text-secondary hover:text-hz-orange-500"
                )}
              >
                {/* 图标 */}
                <Icon 
                  size={18} 
                  className={cn(
                    "mb-0.5 transition-colors",
                    isActive ? "text-white" : "text-current"
                  )} 
                />
                
                {/* 标签 */}
                <span className={cn(
                  "text-[10px] font-medium leading-tight",
                  isActive ? "text-white" : "text-current"
                )}>
                  {item.label}
                </span>
                
                {/* 活跃指示器 */}
                {isActive && (
                  <div className="absolute -top-1 w-1 h-1 bg-white rounded-full opacity-80" />
                )}
              </button>
            )
          })}
        </div>
      </div>
      
      {/* 安全区域底部填充 */}
      <div className="bg-white h-safe-area-inset-bottom" />
    </div>
  )
}
