import React from 'react'

interface HzLoadingProps {
  size?: 'small' | 'medium' | 'large'
  className?: string
  text?: string
  showText?: boolean
}

const sizeConfig = {
  small: { 
    container: 'w-12 h-12', 
    text: 'text-sm mt-2' 
  },
  medium: { 
    container: 'w-16 h-16', 
    text: 'text-base mt-3' 
  },
  large: { 
    container: 'w-24 h-24', 
    text: 'text-lg mt-4' 
  }
}

export function HzLoading({ 
  size = 'medium', 
  className = '', 
  text = '加载中...', 
  showText = true 
}: HzLoadingProps) {
  const config = sizeConfig[size]
  
  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <div className={`relative ${config.container}`}>
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* 橙色渐变 */}
            <linearGradient id="hz-loading-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FB923C" />
              <stop offset="50%" stopColor="#F97316" />
              <stop offset="100%" stopColor="#EA580C" />
            </linearGradient>
            
            {/* 径向渐变 */}
            <radialGradient id="hz-loading-radial" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#F97316" stopOpacity="0.8" />
              <stop offset="70%" stopColor="#FB923C" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#EA580C" stopOpacity="0.1" />
            </radialGradient>
            
            {/* 发光效果 */}
            <filter id="hz-loading-glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge> 
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          
          {/* 脉冲能量核心 */}
          <circle
            cx="50"
            cy="50"
            r="8"
            fill="url(#hz-loading-radial)"
            filter="url(#hz-loading-glow)"
          >
            <animate
              attributeName="r"
              values="8;12;8"
              dur="1.5s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="opacity"
              values="1;0.6;1"
              dur="1.5s"
              repeatCount="indefinite"
            />
          </circle>
          
          {/* 多层能量波扩散 */}
          <g opacity="0.7">
            {/* 第一层波 */}
            <circle cx="50" cy="50" r="10" fill="none" stroke="url(#hz-loading-gradient)" strokeWidth="1.5">
              <animate
                attributeName="r"
                values="10;30;45"
                dur="2.5s"
                repeatCount="indefinite"
              />
              <animate
                attributeName="opacity"
                values="0.8;0.3;0"
                dur="2.5s"
                repeatCount="indefinite"
              />
              <animate
                attributeName="stroke-width"
                values="1.5;0.8;0.3"
                dur="2.5s"
                repeatCount="indefinite"
              />
            </circle>
            
            {/* 第二层波 */}
            <circle cx="50" cy="50" r="10" fill="none" stroke="url(#hz-loading-gradient)" strokeWidth="1.5">
              <animate
                attributeName="r"
                values="10;30;45"
                dur="2.5s"
                repeatCount="indefinite"
                begin="0.8s"
              />
              <animate
                attributeName="opacity"
                values="0.8;0.3;0"
                dur="2.5s"
                repeatCount="indefinite"
                begin="0.8s"
              />
              <animate
                attributeName="stroke-width"
                values="1.5;0.8;0.3"
                dur="2.5s"
                repeatCount="indefinite"
                begin="0.8s"
              />
            </circle>
            
            {/* 第三层波 */}
            <circle cx="50" cy="50" r="10" fill="none" stroke="url(#hz-loading-gradient)" strokeWidth="1.5">
              <animate
                attributeName="r"
                values="10;30;45"
                dur="2.5s"
                repeatCount="indefinite"
                begin="1.6s"
              />
              <animate
                attributeName="opacity"
                values="0.8;0.3;0"
                dur="2.5s"
                repeatCount="indefinite"
                begin="1.6s"
              />
              <animate
                attributeName="stroke-width"
                values="1.5;0.8;0.3"
                dur="2.5s"
                repeatCount="indefinite"
                begin="1.6s"
              />
            </circle>
          </g>
          
          {/* 能量粒子旋转 */}
          <g>
            {/* 粒子1 */}
            <circle cx="70" cy="50" r="2" fill="url(#hz-loading-gradient)" opacity="0.8">
              <animateTransform
                attributeName="transform"
                type="rotate"
                values="0 50 50;360 50 50"
                dur="3s"
                repeatCount="indefinite"
              />
              <animate
                attributeName="opacity"
                values="0.8;0.3;0.8"
                dur="1.5s"
                repeatCount="indefinite"
              />
            </circle>
            
            {/* 粒子2 */}
            <circle cx="30" cy="50" r="2" fill="url(#hz-loading-gradient)" opacity="0.6">
              <animateTransform
                attributeName="transform"
                type="rotate"
                values="120 50 50;480 50 50"
                dur="3s"
                repeatCount="indefinite"
              />
              <animate
                attributeName="opacity"
                values="0.6;0.2;0.6"
                dur="1.5s"
                repeatCount="indefinite"
                begin="0.5s"
              />
            </circle>
            
            {/* 粒子3 */}
            <circle cx="50" cy="30" r="2" fill="url(#hz-loading-gradient)" opacity="0.7">
              <animateTransform
                attributeName="transform"
                type="rotate"
                values="240 50 50;600 50 50"
                dur="3s"
                repeatCount="indefinite"
              />
              <animate
                attributeName="opacity"
                values="0.7;0.2;0.7"
                dur="1.5s"
                repeatCount="indefinite"
                begin="1s"
              />
            </circle>
          </g>
          
          {/* 数据流效果 */}
          <g opacity="0.5">
            {/* 流线1 */}
            <path
              d="M20,50 Q35,30 50,50 T80,50"
              fill="none"
              stroke="url(#hz-loading-gradient)"
              strokeWidth="1"
              strokeDasharray="5,5"
            >
              <animate
                attributeName="stroke-dashoffset"
                values="0;-20"
                dur="2s"
                repeatCount="indefinite"
              />
              <animate
                attributeName="opacity"
                values="0.5;0.1;0.5"
                dur="2s"
                repeatCount="indefinite"
              />
            </path>
            
            {/* 流线2 */}
            <path
              d="M50,20 Q30,35 50,50 T50,80"
              fill="none"
              stroke="url(#hz-loading-gradient)"
              strokeWidth="1"
              strokeDasharray="5,5"
            >
              <animate
                attributeName="stroke-dashoffset"
                values="0;-20"
                dur="2s"
                repeatCount="indefinite"
                begin="1s"
              />
              <animate
                attributeName="opacity"
                values="0.5;0.1;0.5"
                dur="2s"
                repeatCount="indefinite"
                begin="1s"
              />
            </path>
          </g>
        </svg>
      </div>
      
      {showText && (
        <div className={`text-hz-warm-text-secondary font-warm ${config.text} animate-pulse`}>
          {text}
        </div>
      )}
    </div>
  )
}

// 简化版加载图标
export function HzSpinner({ 
  size = 24, 
  className = '' 
}: { 
  size?: number
  className?: string 
}) {
  return (
    <div className={`inline-block ${className}`} style={{ width: size, height: size }}>
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id={`hz-spinner-gradient-${size}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FB923C" />
            <stop offset="50%" stopColor="#F97316" />
            <stop offset="100%" stopColor="#EA580C" />
          </linearGradient>
          
          <radialGradient id={`hz-spinner-radial-${size}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#F97316" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#EA580C" stopOpacity="0.3" />
          </radialGradient>
        </defs>
        
        {/* 脉冲核心 */}
        <circle
          cx="50"
          cy="50"
          r="12"
          fill={`url(#hz-spinner-radial-${size})`}
        >
          <animate
            attributeName="r"
            values="12;18;12"
            dur="1.5s"
            repeatCount="indefinite"
          />
          <animate
            attributeName="opacity"
            values="0.8;0.4;0.8"
            dur="1.5s"
            repeatCount="indefinite"
          />
        </circle>
        
        {/* 能量环 */}
        <circle
          cx="50"
          cy="50"
          r="25"
          fill="none"
          stroke={`url(#hz-spinner-gradient-${size})`}
          strokeWidth="2"
          opacity="0.6"
        >
          <animate
            attributeName="r"
            values="25;35;25"
            dur="2s"
            repeatCount="indefinite"
          />
          <animate
            attributeName="opacity"
            values="0.6;0.2;0.6"
            dur="2s"
            repeatCount="indefinite"
          />
        </circle>
      </svg>
    </div>
  )
}

// 全屏加载页面
export function HzFullScreenLoading({ 
  text = '正在加载...', 
  subText = '与同频的朋友连接中' 
}: { 
  text?: string
  subText?: string 
}) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-hz-warm-background to-hz-warm-surface flex items-center justify-center relative overflow-hidden">
      {/* 背景装饰波纹 */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-96 h-96 rounded-full border border-hz-orange-200 opacity-20 animate-pulse"></div>
        <div className="absolute w-72 h-72 rounded-full border border-hz-orange-300 opacity-30 animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute w-48 h-48 rounded-full border border-hz-orange-400 opacity-40 animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>
      
      <div className="text-center relative z-10">
        <HzLoading size="large" showText={false} className="mb-8" />
        <h2 className="text-2xl font-accent font-bold text-hz-warm-text-primary mb-3">
          {text}
        </h2>
        <p className="text-hz-warm-text-secondary font-warm text-lg">
          {subText}
        </p>
      </div>
    </div>
  )
}
