import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { AnimatedContainer, CountUp, HoverCard, ProgressRing } from '@/components/ui/animation-system'
import { HzIcon } from '@/components/ui/hz-logo'
import { 
  Sparkles, 
  TrendingUp, 
  Clock, 
  MapPin, 
  Coffee, 
  MessageCircle, 
  Users, 
  Calendar,
  Star,
  Zap,
  Heart,
  Target
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'

// 欢迎横幅组件
interface WelcomeBannerProps {
  userName: string
  userAvatar?: string
}

export function WelcomeBanner({ userName, userAvatar }: WelcomeBannerProps) {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const getGreeting = () => {
    const hour = currentTime.getHours()
    if (hour < 6) return '夜深了'
    if (hour < 12) return '早安'
    if (hour < 18) return '下午好'
    return '晚上好'
  }

  const getDailyQuote = () => {
    const quotes = [
      '今天也要和同频的朋友们快乐相遇！',
      '每一次交流都是心灵的共振',
      '在Hz赫兹，发现志趣相投的伙伴',
      '用温暖连接每一颗真诚的心',
      '让我们一起创造美好的社交时光'
    ]
    return quotes[Math.floor(Math.random() * quotes.length)]
  }

  return (
    <AnimatedContainer type="fadeIn" className="mb-8">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-hz-orange-50 via-orange-100 to-amber-50 p-8 border border-hz-orange-200">
        {/* 背景装饰 */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-hz-orange-200 to-transparent rounded-full opacity-30 blur-2xl"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-amber-200 to-transparent rounded-full opacity-40 blur-xl"></div>
        
        <div className="relative z-10">
          {/* 移动端布局 */}
          <div className="md:hidden flex flex-col space-y-4">
            {/* 用户头像居中 */}
            <div className="flex justify-center">
              <div className="relative">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-hz-orange-200 to-hz-orange-400 p-0.5">
                  <img
                    src={userAvatar || '/avatars/default.jpg'}
                    alt={userName}
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                <div className="absolute -bottom-1 -right-1">
                  <HzIcon size={20} animated={true} />
                </div>
              </div>
            </div>
            
            {/* 移动端：时间信息（1/3）和问候语（2/3）的横向布局 */}
            <div className="flex space-x-4">
              {/* 时间显示 - 1/3 宽度 */}
              <div className="w-1/3 text-center">
                <div className="text-2xl font-bold text-hz-orange-600 mb-1">
                  {currentTime.toLocaleTimeString('zh-CN', { 
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </div>
                <div className="flex items-center justify-center text-xs text-gray-600">
                  <Clock size={12} className="mr-1" />
                  现在时间
                </div>
              </div>
              
              {/* 欢迎信息 - 2/3 宽度 */}
              <div className="w-2/3">
                <h1 className="text-xl font-bold text-gray-900 mb-1">
                  {getGreeting()}，{userName}！
                </h1>
                <p className="text-hz-orange-700 text-base font-medium mb-2">
                  {getDailyQuote()}
                </p>
                <p className="text-gray-600 text-xs">
                  {currentTime.toLocaleDateString('zh-CN', { 
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    weekday: 'long'
                  })}
                </p>
              </div>
            </div>
          </div>
          
          {/* 桌面端布局 - 保持原有设计 */}
          <div className="hidden md:flex items-center space-x-6">
            {/* 用户头像 */}
            <div className="relative">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-hz-orange-200 to-hz-orange-400 p-0.5">
                <img
                  src={userAvatar || '/avatars/default.jpg'}
                  alt={userName}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div className="absolute -bottom-1 -right-1">
                <HzIcon size={20} animated={true} />
              </div>
            </div>
            
            {/* 欢迎信息 */}
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900 mb-1">
                {getGreeting()}，{userName}！
              </h1>
              <p className="text-hz-orange-700 text-lg font-medium mb-2">
                {getDailyQuote()}
              </p>
              <p className="text-gray-600 text-sm">
                {currentTime.toLocaleDateString('zh-CN', { 
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  weekday: 'long'
                })}
              </p>
            </div>
            
            {/* 时间显示 */}
            <div className="text-center">
              <div className="text-3xl font-bold text-hz-orange-600 mb-1">
                {currentTime.toLocaleTimeString('zh-CN', { 
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Clock size={14} className="mr-1" />
                现在时间
              </div>
            </div>
          </div>
        </div>
      </div>
    </AnimatedContainer>
  )
}

// 活动推荐组件
export function ActivityRecommendations() {
  const navigate = useNavigate()
  
  const [activities] = useState([
    {
      id: 1,
      title: '技术分享 Coffee Chat',
      time: '今天 14:00',
      location: '中关村',
      participants: 3,
      maxParticipants: 5,
      tags: ['技术', '前端', '经验分享']
    },
    {
      id: 2,
      title: '产品思维交流会',
      time: '明天 15:30',
      location: '望京',
      participants: 2,
      maxParticipants: 4,
      tags: ['产品', '设计', '用户体验']
    },
    {
      id: 3,
      title: '创业者聚会',
      time: '周六 10:00',
      location: '三里屯',
      participants: 4,
      maxParticipants: 6,
      tags: ['创业', '投资', '商业']
    }
  ])

  return (
    <AnimatedContainer delay={200} className="mb-8">
      <HoverCard scale={1.01}>
        <Card className="border-hz-orange-200 bg-gradient-to-br from-white to-hz-orange-50/30">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Coffee className="text-hz-orange-500" size={20} />
              <span>推荐活动</span>
              <Sparkles className="text-amber-500 animate-pulse" size={16} />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activities.map((activity, index) => (
                <div
                  key={activity.id}
                  className="p-4 rounded-lg bg-white/60 backdrop-blur-sm border border-hz-orange-100 hover:border-hz-orange-300 transition-all duration-200"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">{activity.title}</h4>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <div className="flex items-center">
                          <Clock size={14} className="mr-1" />
                          {activity.time}
                        </div>
                        <div className="flex items-center">
                          <MapPin size={14} className="mr-1" />
                          {activity.location}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-600 mb-1">
                        {activity.participants}/{activity.maxParticipants} 人
                      </div>
                      <ProgressRing 
                        percentage={(activity.participants / activity.maxParticipants) * 100}
                        size={40}
                        strokeWidth={4}
                      >
                        <Users size={12} className="text-hz-orange-500" />
                      </ProgressRing>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex space-x-2">
                      {activity.tags.map((tag, tagIndex) => (
                        <span
                          key={tagIndex}
                          className="px-2 py-1 bg-hz-orange-100 text-hz-orange-700 rounded text-xs"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    <Button
                      size="sm"
                      className="bg-hz-orange-500 hover:bg-hz-orange-600 text-white"
                      onClick={() => navigate('/app/coffee-join')}
                    >
                      加入
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 text-center">
              <Button
                variant="outline"
                className="border-hz-orange-300 text-hz-orange-600 hover:bg-hz-orange-50"
                onClick={() => navigate('/app/coffee-join')}
              >
                查看更多活动
              </Button>
            </div>
          </CardContent>
        </Card>
      </HoverCard>
    </AnimatedContainer>
  )
}

// 社交动态组件
export function SocialStats() {
  const [stats] = useState({
    totalUsers: 1248,
    todayMatches: 23,
    activeChats: 167,
    coffeeMeetings: 89
  })

  return (
    <AnimatedContainer delay={400} className="mb-8">
      <HoverCard scale={1.01}>
        <Card className="border-hz-orange-200 bg-gradient-to-br from-white to-amber-50/30">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="text-hz-orange-500" size={20} />
              <span>平台动态</span>
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 rounded-lg bg-white/60 backdrop-blur-sm">
                <div className="flex items-center justify-center mb-2">
                  <Users className="text-blue-500" size={24} />
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">
                  <CountUp end={stats.totalUsers} delay={500} />
                </div>
                <div className="text-xs text-gray-600">社交用户</div>
              </div>
              
              <div className="text-center p-4 rounded-lg bg-white/60 backdrop-blur-sm">
                <div className="flex items-center justify-center mb-2">
                  <Heart className="text-red-500" size={24} />
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">
                  <CountUp end={stats.todayMatches} delay={700} />
                </div>
                <div className="text-xs text-gray-600">今日匹配</div>
              </div>
              
              <div className="text-center p-4 rounded-lg bg-white/60 backdrop-blur-sm">
                <div className="flex items-center justify-center mb-2">
                  <MessageCircle className="text-green-500" size={24} />
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">
                  <CountUp end={stats.activeChats} delay={900} />
                </div>
                <div className="text-xs text-gray-600">活跃聊天</div>
              </div>
              
              <div className="text-center p-4 rounded-lg bg-white/60 backdrop-blur-sm">
                <div className="flex items-center justify-center mb-2">
                  <Coffee className="text-amber-600" size={24} />
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">
                  <CountUp end={stats.coffeeMeetings} delay={1100} />
                </div>
                <div className="text-xs text-gray-600">Coffee聚会</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </HoverCard>
    </AnimatedContainer>
  )
}

// 个性化推荐组件
export function PersonalizedRecommendations() {
  const navigate = useNavigate()
  
  const [recommendations] = useState([
    {
      id: 1,
      name: '张小明',
      avatar: '/avatars/avatar1.jpg',
      role: '产品经理',
      matchScore: 92,
      commonTags: ['产品设计', '用户体验', '敏捷开发'],
      location: '北京'
    },
    {
      id: 2,
      name: '李小红',
      avatar: '/avatars/avatar2.jpg',
      role: '前端工程师',
      matchScore: 88,
      commonTags: ['React', 'TypeScript', '前端架构'],
      location: '上海'
    },
    {
      id: 3,
      name: '王小华',
      avatar: '/avatars/avatar3.jpg',
      role: '创业者',
      matchScore: 85,
      commonTags: ['创业', '投资', 'SaaS'],
      location: '深圳'
    }
  ])

  return (
    <AnimatedContainer delay={600} className="mb-8">
      <HoverCard scale={1.01}>
        <Card className="border-hz-orange-200 bg-gradient-to-br from-white to-orange-50/30">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="text-hz-orange-500" size={20} />
              <span>为你推荐</span>
              <Star className="text-yellow-500 animate-pulse" size={16} />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recommendations.map((user, index) => (
                <div
                  key={user.id}
                  className="flex items-center space-x-4 p-4 rounded-lg bg-white/60 backdrop-blur-sm border border-hz-orange-100 hover:border-hz-orange-300 transition-all duration-200"
                >
                  <div className="relative">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="absolute -top-1 -right-1">
                      <ProgressRing 
                        percentage={user.matchScore}
                        size={24}
                        strokeWidth={3}
                      >
                        <div className="text-xs font-bold text-hz-orange-600">
                          {user.matchScore}
                        </div>
                      </ProgressRing>
                    </div>
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="font-semibold text-gray-900">{user.name}</h4>
                      <span className="text-sm text-gray-600">{user.role}</span>
                      <span className="text-xs text-gray-500">{user.location}</span>
                    </div>
                    <div className="flex space-x-1">
                      {user.commonTags.slice(0, 2).map((tag, tagIndex) => (
                        <span
                          key={tagIndex}
                          className="px-2 py-1 bg-hz-orange-100 text-hz-orange-700 rounded text-xs"
                        >
                          {tag}
                        </span>
                      ))}
                      {user.commonTags.length > 2 && (
                        <span className="text-xs text-gray-500 px-1">
                          +{user.commonTags.length - 2}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-hz-orange-300 text-hz-orange-600 hover:bg-hz-orange-50"
                    onClick={() => navigate('/app/match')}
                  >
                    查看
                  </Button>
                </div>
              ))}
            </div>
            
            <div className="mt-6 text-center">
              <Button
                variant="outline"
                className="border-hz-orange-300 text-hz-orange-600 hover:bg-hz-orange-50"
                onClick={() => navigate('/app/match')}
              >
                发现更多同频伙伴
              </Button>
            </div>
          </CardContent>
        </Card>
      </HoverCard>
    </AnimatedContainer>
  )
}
