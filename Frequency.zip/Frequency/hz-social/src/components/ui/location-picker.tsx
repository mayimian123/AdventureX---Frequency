import React, { useState, useEffect, useRef, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Search, MapPin, Navigation, Clock, Star, Check } from 'lucide-react'

// 地点信息接口
interface PlaceInfo {
  place_id?: string
  name: string
  address: string
  formatted_address?: string
  location: {
    lat: number
    lng: number
  }
  types?: string[]
  rating?: number
  price_level?: number
  distance_km?: number
  distance_display?: string
  opening_hours?: {
    open_now?: boolean
    weekday_text?: string[]
  }
}

// 选中的地点信息
export interface SelectedLocation {
  name: string
  address: string
  latitude: number
  longitude: number
  place_id?: string
}

interface LocationPickerProps {
  onLocationSelect: (location: SelectedLocation) => void
  initialLocation?: SelectedLocation
  placeholder?: string
  className?: string
}

// Google Maps API Key
const GOOGLE_MAPS_API_KEY = 'AIzaSyCO0kKndUNlmQi3B5mxy4dblg_8WYcuKuk'

export function LocationPicker({ 
  onLocationSelect, 
  initialLocation, 
  placeholder = "搜索咖啡厅、餐厅、会议室...",
  className = ""
}: LocationPickerProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<PlaceInfo[]>([])
  const [selectedLocation, setSelectedLocation] = useState<SelectedLocation | null>(initialLocation || null)
  const [isSearching, setIsSearching] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const [userLocation, setUserLocation] = useState<{ lat: number, lng: number } | null>(null)
  const [mapMode, setMapMode] = useState(false)
  const [isMapLoaded, setIsMapLoaded] = useState(false)
  
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any | null>(null)
  const searchInputRef = useRef<HTMLInputElement>(null)
  const autocompleteRef = useRef<any | null>(null)

  // 获取用户当前位置
  const getCurrentLocation = useCallback(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          }
          setUserLocation(location)
          console.log('Got user location:', location)
        },
        (error) => {
          console.warn('Failed to get user location:', error)
          // 默认位置（上海）
          setUserLocation({ lat: 31.2304, lng: 121.4737 })
        },
        { timeout: 10000, enableHighAccuracy: true }
      )
    } else {
      console.warn('Geolocation not supported')
      setUserLocation({ lat: 31.2304, lng: 121.4737 })
    }
  }, [])

  // 加载Google Maps API
  const loadGoogleMapsAPI = useCallback(() => {
    return new Promise<void>((resolve, reject) => {
      if (window.google && window.google.maps) {
        resolve()
        return
      }

      const script = document.createElement('script')
      script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places&language=zh-CN`
      script.async = true
      script.defer = true
      
      script.onload = () => {
        console.log('Google Maps API loaded successfully')
        resolve()
      }
      
      script.onerror = () => {
        console.error('Failed to load Google Maps API')
        reject(new Error('Failed to load Google Maps API'))
      }
      
      document.head.appendChild(script)
    })
  }, [])

  // 初始化地图
  const initializeMap = useCallback(() => {
    if (!mapRef.current || !window.google || !userLocation) return

    const map = new window.google.maps.Map(mapRef.current, {
      center: selectedLocation ? 
        { lat: selectedLocation.latitude, lng: selectedLocation.longitude } : 
        userLocation,
      zoom: 15,
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: false
    })

    mapInstanceRef.current = map

    // 如果有选中的位置，添加标记
    if (selectedLocation) {
      new window.google.maps.Marker({
        position: { lat: selectedLocation.latitude, lng: selectedLocation.longitude },
        map: map,
        title: selectedLocation.name,
        icon: {
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="16" cy="16" r="12" fill="#F97316" stroke="#FFFFFF" stroke-width="3"/>
              <circle cx="16" cy="16" r="4" fill="#FFFFFF"/>
            </svg>
          `),
          scaledSize: new window.google.maps.Size(32, 32),
          anchor: new window.google.maps.Point(16, 16)
        }
      })
    }

    // 地图点击事件
    map.addListener('click', (event: any) => {
      if (event.latLng) {
        const lat = event.latLng.lat()
        const lng = event.latLng.lng()
        
        // 反向地理编码获取地址
        const geocoder = new window.google.maps.Geocoder()
        geocoder.geocode({ location: { lat, lng } }, (results, status) => {
          if (status === 'OK' && results && results[0]) {
            const result = results[0]
            const location: SelectedLocation = {
              name: result.formatted_address || '选中的位置',
              address: result.formatted_address || '',
              latitude: lat,
              longitude: lng
            }
            
            setSelectedLocation(location)
            onLocationSelect(location)
            
            // 添加新标记
            new window.google.maps.Marker({
              position: { lat, lng },
              map: map,
              title: location.name,
              icon: {
                url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="16" cy="16" r="12" fill="#F97316" stroke="#FFFFFF" stroke-width="3"/>
                    <circle cx="16" cy="16" r="4" fill="#FFFFFF"/>
                  </svg>
                `),
                scaledSize: new window.google.maps.Size(32, 32),
                anchor: new window.google.maps.Point(16, 16)
              }
            })
          }
        })
      }
    })

    // 初始化Places服务
    autocompleteRef.current = new window.google.maps.places.PlacesService(map)
    
    setIsMapLoaded(true)
  }, [userLocation, selectedLocation, onLocationSelect])

  // 搜索地点
  const searchPlaces = useCallback(async (query: string) => {
    if (!query.trim() || !autocompleteRef.current || !userLocation) return

    setIsSearching(true)
    setShowResults(true)

    try {
      const request: any = {
        query: query,
        location: new window.google.maps.LatLng(userLocation.lat, userLocation.lng),
        radius: 5000, // 5公里范围
        type: 'establishment'
      }

      autocompleteRef.current.textSearch(request, (results, status) => {
        console.log('Places search results:', { results, status })
        
        if (status === 'OK' && results) {
          const places: PlaceInfo[] = results.slice(0, 8).map(place => {
            const location = place.geometry?.location
            const lat = location?.lat() || 0
            const lng = location?.lng() || 0
            
            // 计算距离
            const distance = calculateDistance(userLocation.lat, userLocation.lng, lat, lng)
            
            return {
              place_id: place.place_id,
              name: place.name || '未知地点',
              address: place.formatted_address || '',
              location: { lat, lng },
              types: place.types,
              rating: place.rating,
              price_level: place.price_level,
              distance_km: distance,
              distance_display: formatDistance(distance),
              opening_hours: place.opening_hours ? {
                open_now: place.opening_hours.open_now
              } : undefined
            }
          })
          
          // 按距离排序
          places.sort((a, b) => (a.distance_km || 999) - (b.distance_km || 999))
          setSearchResults(places)
        } else {
          console.warn('Places search failed:', status)
          setSearchResults([])
        }
        
        setIsSearching(false)
      })
    } catch (error) {
      console.error('Search error:', error)
      setIsSearching(false)
    }
  }, [userLocation])

  // 选择地点
  const selectPlace = useCallback((place: PlaceInfo) => {
    const location: SelectedLocation = {
      name: place.name,
      address: place.address,
      latitude: place.location.lat,
      longitude: place.location.lng,
      place_id: place.place_id
    }
    
    setSelectedLocation(location)
    onLocationSelect(location)
    setShowResults(false)
    setSearchQuery('')
    
    // 如果地图已加载，移动到选中位置
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setCenter(place.location)
      
      // 清除旧标记，添加新标记
      new window.google.maps.Marker({
        position: place.location,
        map: mapInstanceRef.current,
        title: place.name,
        icon: {
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="16" cy="16" r="12" fill="#F97316" stroke="#FFFFFF" stroke-width="3"/>
              <circle cx="16" cy="16" r="4" fill="#FFFFFF"/>
            </svg>
          `),
          scaledSize: new window.google.maps.Size(32, 32),
          anchor: new window.google.maps.Point(16, 16)
        }
      })
    }
  }, [onLocationSelect])

  // 计算距离（Haversine公式）
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371 // 地球半径（公里）
    const dLat = (lat2 - lat1) * Math.PI / 180
    const dLng = (lng2 - lng1) * Math.PI / 180
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
    return R * c
  }

  // 格式化距离显示
  const formatDistance = (distanceKm: number): string => {
    if (distanceKm < 1) {
      return `${Math.round(distanceKm * 1000)}米`
    } else if (distanceKm < 10) {
      return `${distanceKm.toFixed(1)}公里`
    } else {
      return `${Math.round(distanceKm)}公里`
    }
  }

  // 组件初始化
  useEffect(() => {
    getCurrentLocation()
    loadGoogleMapsAPI().catch(console.error)
  }, [getCurrentLocation, loadGoogleMapsAPI])

  // 用户位置获取后初始化地图
  useEffect(() => {
    if (userLocation && window.google && mapMode) {
      initializeMap()
    }
  }, [userLocation, mapMode, initializeMap])

  // 搜索防抖
  useEffect(() => {
    if (!searchQuery.trim()) {
      setShowResults(false)
      return
    }

    const timer = setTimeout(() => {
      searchPlaces(searchQuery)
    }, 500)

    return () => clearTimeout(timer)
  }, [searchQuery, searchPlaces])

  return (
    <div className={`space-y-4 ${className}`}>
      {/* 当前选中的地点 */}
      {selectedLocation && (
        <Card className="border-hz-orange-200 bg-gradient-to-r from-hz-orange-50 to-orange-50">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-1">
                <div className="w-8 h-8 bg-hz-orange-500 rounded-full flex items-center justify-center">
                  <Check className="w-4 h-4 text-white" />
                </div>
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-gray-900 mb-1">已选择地点</h4>
                <p className="font-medium text-hz-orange-700">{selectedLocation.name}</p>
                <p className="text-sm text-gray-600">{selectedLocation.address}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setSelectedLocation(null)
                  setSearchQuery('')
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                更换
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 搜索和选择 */}
      {!selectedLocation && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-hz-orange-500" />
              <span>选择活动地点</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* 搜索框 */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <Input
                ref={searchInputRef}
                type="text"
                placeholder={placeholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
              {isSearching && (
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <div className="w-5 h-5 border-2 border-hz-orange-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>

            {/* 搜索结果 */}
            {showResults && searchResults.length > 0 && (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                <p className="text-sm text-gray-600 font-medium">搜索结果：</p>
                {searchResults.map((place, index) => (
                  <div
                    key={place.place_id || index}
                    className="p-3 border border-gray-200 rounded-lg hover:border-hz-orange-300 hover:bg-hz-orange-50 cursor-pointer transition-colors"
                    onClick={() => selectPlace(place)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-medium text-gray-900">{place.name}</h4>
                          {place.rating && (
                            <div className="flex items-center space-x-1">
                              <Star className="w-4 h-4 text-yellow-500 fill-current" />
                              <span className="text-sm text-gray-600">{place.rating}</span>
                            </div>
                          )}
                          {place.opening_hours?.open_now && (
                            <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">营业中</span>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mb-1">{place.address}</p>
                        {place.distance_display && (
                          <div className="flex items-center space-x-1 text-xs text-gray-500">
                            <Navigation className="w-3 h-3" />
                            <span>距您 {place.distance_display}</span>
                          </div>
                        )}
                      </div>
                      <Button size="sm" variant="outline">选择</Button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 地图模式切换 */}
            <div className="flex space-x-2">
              <Button
                variant={mapMode ? "default" : "outline"}
                onClick={() => setMapMode(!mapMode)}
                className="flex items-center space-x-2"
              >
                <MapPin className="w-4 h-4" />
                <span>{mapMode ? '隐藏地图' : '在地图上选择'}</span>
              </Button>
            </div>

            {/* 地图 */}
            {mapMode && (
              <div className="space-y-2">
                <p className="text-sm text-gray-600">在地图上点击选择位置：</p>
                <div 
                  ref={mapRef} 
                  className="w-full h-64 rounded-lg border border-gray-300"
                  style={{ minHeight: '256px' }}
                />
                {!isMapLoaded && userLocation && (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-100 rounded-lg">
                    <div className="text-center">
                      <div className="w-8 h-8 border-2 border-hz-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                      <p className="text-sm text-gray-600">地图加载中...</p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// 扩展Window接口以支持Google Maps API
declare global {
  interface Window {
    google: any
  }
}
