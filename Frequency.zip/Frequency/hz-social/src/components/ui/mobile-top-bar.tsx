import React from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { Menu, ArrowLeft, Settings, Bell } from 'lucide-react'
import { HzLogo } from '@/components/ui/hz-logo'
import { cn } from '@/lib/utils'

interface MobileTopBarProps {
  onMenuClick?: () => void
  showBackButton?: boolean
  title?: string
  rightActions?: React.ReactNode
}

// 页面标题映射
const pageTitles: Record<string, string> = {
  '/app': 'Hz 赫兹社交',
  '/app/chat': '聊天消息',
  '/app/match': '智能匹配',
  '/app/coffee-join': '加入Coffee Chat',
  '/app/coffee-my': '我的Coffee Chat'
}

export function MobileTopBar({ 
  onMenuClick, 
  showBackButton = false, 
  title,
  rightActions 
}: MobileTopBarProps) {
  const location = useLocation()
  const navigate = useNavigate()
  
  // 获取当前页面标题
  const currentTitle = title || pageTitles[location.pathname] || 'Hz 赫兹'
  
  // 是否为首页
  const isHomePage = location.pathname === '/app'
  
  const handleBackClick = () => {
    navigate(-1)
  }

  return (
    <div className="fixed top-0 left-0 right-0 z-40 md:hidden">
      {/* 顶部状态栏占位 */}
      <div className="h-safe-area-inset-top bg-hz-warm-bg" />
      
      {/* 标题栏 */}
      <div className="bg-white/95 backdrop-blur-md border-b border-hz-warm-border">
        <div className="flex items-center justify-between h-14 px-4">
          {/* 左侧按钮 */}
          <div className="flex items-center">
            {showBackButton ? (
              <button
                onClick={handleBackClick}
                className="flex items-center justify-center w-10 h-10 rounded-full text-hz-warm-text-primary hover:bg-hz-warm-social-warm active:scale-95 transition-all"
              >
                <ArrowLeft size={18} />
              </button>
            ) : (
              <button
                onClick={onMenuClick}
                className="flex items-center justify-center w-10 h-10 rounded-full text-hz-warm-text-primary hover:bg-hz-warm-social-warm active:scale-95 transition-all"
              >
                <Menu size={18} />
              </button>
            )}
          </div>
          
          {/* 中间标题区域 */}
          <div className="flex-1 flex items-center justify-center mx-4">
            {isHomePage ? (
              <HzLogo size="small" animated={true} showText={true} />
            ) : (
              <h1 className="text-base font-bold text-hz-warm-text-primary font-warm truncate">
                {currentTitle}
              </h1>
            )}
          </div>
          
          {/* 右侧操作区域 - 移除设置和通知图标，保持空间平衡 */}
          <div className="flex items-center space-x-2">
            {rightActions || (
              <div className="w-10" />
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
