import React from 'react'
import { X, MapPin, Briefcase, Heart, User } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { HzUser } from '@/types'
import { getMatchScoreColor } from '@/lib/utils'

interface UserDetailModalProps {
  user: HzUser
  matchScore: number
  isOpen: boolean
  onClose: () => void
  onSayHello: () => void
}

export function UserDetailModal({ user, matchScore, isOpen, onClose, onSayHello }: UserDetailModalProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* 背景遮罩 */}
      <div 
        className="absolute inset-0 bg-black bg-opacity-50 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* 悬浮窗内容 */}
      <Card className="relative w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto bg-white shadow-2xl">
        {/* 关闭按钮 */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
        >
          <X size={16} className="text-gray-600" />
        </button>

        <CardHeader className="pb-4">
          {/* 头像和基本信息 */}
          <div className="flex items-start space-x-4">
            <img
              src={user.avatar_url || '/avatars/default.jpg'}
              alt={user.nickname}
              className="w-20 h-20 rounded-full object-cover"
            />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">{user.nickname}</h2>
                  <p className="text-gray-600">{user.age}岁</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-sm font-bold ${getMatchScoreColor(matchScore)}`}>
                  {matchScore}Hz
                </div>
              </div>
              
              {/* 位置和职业 */}
              <div className="mt-3 space-y-2">
                <div className="flex items-center space-x-2 text-gray-600">
                  <MapPin size={16} />
                  <span>{user.location_province} {user.location_city}</span>
                </div>
                {user.role && (
                  <div className="flex items-center space-x-2 text-gray-600">
                    <Briefcase size={16} />
                    <span>{user.role}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* 当前活动 */}
          {user.current_activity && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2 flex items-center">
                <User size={16} className="mr-2" />
                目前在做什么
              </h3>
              <p className="text-gray-600 leading-relaxed">{user.current_activity}</p>
            </div>
          )}

          {/* 专业领域 */}
          {user.professional_fields && user.professional_fields.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">专业领域</h3>
              <div className="flex flex-wrap gap-2">
                {user.professional_fields.map((field, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
                  >
                    {field}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* 兴趣标签 */}
          {user.interest_tags && user.interest_tags.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2 flex items-center">
                <Heart size={16} className="mr-2 text-hz-orange-500" />
                兴趣爱好
              </h3>
              <div className="flex flex-wrap gap-2">
                {user.interest_tags.map((tag, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-hz-orange-50 text-hz-orange-600 rounded-full text-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* 关于我 */}
          {user.about_me && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">关于我</h3>
              <p className="text-gray-600 leading-relaxed">{user.about_me}</p>
            </div>
          )}

          {/* 操作按钮 */}
          <div className="flex space-x-3 pt-4 border-t">
            <Button
              onClick={onSayHello}
              variant="warm"
              className="flex-1"
            >
              打招呼
            </Button>
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1"
            >
              关闭
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
