import React, { useState, useEffect } from 'react';
import { Crown, Calendar, Activity, AlertCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from './button';
import { Card } from './card';
import { HostUpgradeModal } from './host-upgrade-modal';

interface VipStatusData {
  isVip: boolean;
  subscriptionType: string | null;
  activitiesRemaining: number;
  expiresAt: string | null;
  totalActivitiesCreated: number;
}

interface VipStatusDisplayProps {
  className?: string;
  showUpgradeButton?: boolean;
}

export const VipStatusDisplay: React.FC<VipStatusDisplayProps> = ({
  className = '',
  showUpgradeButton = true
}) => {
  const { user } = useAuth();
  const [vipStatus, setVipStatus] = useState<VipStatusData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const fetchVipStatus = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase.functions.invoke('hz-activity-permission', {
        body: { action: 'get_activity_stats' }
      });

      if (error) throw error;
      setVipStatus(data);
    } catch (error) {
      console.error('获取VIP状态失败:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVipStatus();
  }, [user]);

  const formatExpiryDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getSubscriptionDisplayName = (type: string) => {
    switch (type) {
      case 'monthly_vip': return '月度VIP主理人';
      case 'quarterly_vip': return '季度VIP主理人';
      case 'annual_vip': return '年度VIP主理人';
      default: return 'VIP主理人';
    }
  };

  const isExpiringSoon = (expiresAt: string) => {
    const expiry = new Date(expiresAt);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 7;
  };

  if (loading) {
    return (
      <Card className={`p-4 ${className}`}>
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gray-200 rounded-full animate-pulse" />
          <div className="flex-1">
            <div className="h-4 bg-gray-200 rounded animate-pulse mb-2" />
            <div className="h-3 bg-gray-200 rounded animate-pulse w-2/3" />
          </div>
        </div>
      </Card>
    );
  }

  if (!user) {
    return (
      <Card className={`p-4 ${className}`}>
        <div className="text-center">
          <p className="text-gray-600">请先登录查看VIP状态</p>
        </div>
      </Card>
    );
  }

  if (!vipStatus?.isVip) {
    return (
      <>
        <Card className={`p-4 border-2 border-dashed border-yellow-300 bg-yellow-50 ${className}`}>
          <div className="text-center">
            <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Crown className="w-6 h-6 text-yellow-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">
              成为VIP主理人
            </h3>
            <p className="text-gray-600 text-sm mb-4">
              享受活动优先推荐、数据洞察、专属客服等增值服务
            </p>
            {showUpgradeButton && (
              <Button
                onClick={() => setShowUpgradeModal(true)}
                className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
              >
                了解VIP特权
              </Button>
            )}
          </div>
        </Card>
        
        <HostUpgradeModal
          isOpen={showUpgradeModal}
          onClose={() => setShowUpgradeModal(false)}
          onUpgradeSuccess={fetchVipStatus}
        />
      </>
    );
  }

  return (
    <>
      <Card className={`p-4 bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200 ${className}`}>
        <div className="flex items-start space-x-3">
          <div className="p-2 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full text-white">
            <Crown className="w-6 h-6" />
          </div>
          
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-1">
              <h3 className="font-semibold text-gray-900">
                {getSubscriptionDisplayName(vipStatus.subscriptionType || '')}
              </h3>
              {vipStatus.expiresAt && isExpiringSoon(vipStatus.expiresAt) && (
                <div className="flex items-center space-x-1 text-orange-600">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-xs font-medium">即将到期</span>
                </div>
              )}
            </div>
            
            <div className="grid grid-cols-1 gap-2 text-sm">
              {vipStatus.expiresAt && (
                <div className="flex items-center space-x-2 text-gray-600 justify-center">
                  <Calendar className="w-4 h-4" />
                  <span>有效期至: {formatExpiryDate(vipStatus.expiresAt)}</span>
                </div>
              )}
            </div>
            
            <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
              <div className="text-center p-2 bg-blue-50 rounded">
                <div className="font-medium text-blue-800">优先推荐</div>
                <div className="text-blue-600">活动曝光加成</div>
              </div>
              <div className="text-center p-2 bg-green-50 rounded">
                <div className="font-medium text-green-800">数据洞察</div>
                <div className="text-green-600">详细报告分析</div>
              </div>
            </div>
            
            <div className="mt-2 text-xs text-gray-500 text-center">
              已创建 {vipStatus.totalActivitiesCreated} 个活动
            </div>
            
            {showUpgradeButton && (
              <div className="mt-3">
                <Button
                  size="sm"
                  onClick={() => setShowUpgradeModal(true)}
                  className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                >
                  管理VIP订阅
                </Button>
              </div>
            )}
          </div>
        </div>
      </Card>
      
      <HostUpgradeModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        onUpgradeSuccess={fetchVipStatus}
      />
    </>
  );
};