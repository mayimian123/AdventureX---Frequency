import React, { useState } from 'react'
import { Outlet } from 'react-router-dom'
import { Sidebar } from '@/components/Sidebar'
import { MobileTopBar } from '@/components/ui/mobile-top-bar'
import { MobileBottomNav } from '@/components/ui/mobile-bottom-nav'
import { MobileDrawer } from '@/components/ui/mobile-drawer'
import { useIsMobile } from '@/hooks/use-mobile'

export function AppLayout() {
  const isMobile = useIsMobile()
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)
  
  const handleMenuClick = () => {
    setIsDrawerOpen(true)
  }
  
  const handleDrawerClose = () => {
    setIsDrawerOpen(false)
  }

  if (isMobile) {
    // 移动端布局
    return (
      <div className="min-h-screen bg-hz-warm-bg">
        {/* 移动端顶部标题栏 */}
        <MobileTopBar onMenuClick={handleMenuClick} />
        
        {/* 移动端抽屉菜单 */}
        <MobileDrawer isOpen={isDrawerOpen} onClose={handleDrawerClose} />
        
        {/* 主内容区域 - 为顶部栏和底部导航留出空间 */}
        <div className="pt-[calc(56px+env(safe-area-inset-top))] pb-[calc(64px+env(safe-area-inset-bottom))] min-h-screen">
          <Outlet />
        </div>
        
        {/* 移动端底部导航 */}
        <MobileBottomNav />
      </div>
    )
  }
  
  // 桌面端布局（原有布局保持不变）
  return (
    <div className="min-h-screen bg-hz-warm-bg flex">
      {/* 左侧菜单栏 */}
      <div className="w-64 flex-shrink-0">
        <Sidebar className="h-screen sticky top-0" />
      </div>
      
      {/* 主内容区域 */}
      <div className="flex-1 overflow-hidden">
        <Outlet />
      </div>
    </div>
  )
}