import React, { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { HzLogo } from '@/components/ui/hz-logo'
import { useAuth } from '@/contexts/AuthContext'
import { useNavigate, Link } from 'react-router-dom'
import { useIsMobile } from '@/hooks/use-mobile'
import { Eye, EyeOff } from 'lucide-react'

export function RegisterPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  
  const { signUp } = useAuth()
  const navigate = useNavigate()
  const isMobile = useIsMobile()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!email || !password || !confirmPassword) {
      setError('请填写所有字段')
      return
    }

    if (password !== confirmPassword) {
      setError('两次输入的密码不一致')
      return
    }

    if (password.length < 6) {
      setError('密码长度不能少于6位')
      return
    }

    setLoading(true)
    setError('')

    try {
      const { error } = await signUp(email, password)
      if (error) {
        if (error.message.includes('already registered')) {
          setError('该邮箱已被注册')
        } else {
          setError('注册失败，请重试')
        }
      } else {
        setSuccess(true)
        setTimeout(() => {
          navigate('/profile-setup')
        }, 2000)
      }
    } catch (err) {
      setError('注册失败，请重试')
    } finally {
      setLoading(false)
    }
  }

  const isFormValid = email && password && confirmPassword && password === confirmPassword

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-hz-warm-bg px-4 sm:px-6">
        <Card className={`w-full text-center shadow-lg border-hz-warm-border ${
          isMobile ? 'max-w-sm mx-2' : 'max-w-md'
        }`}>
          <CardContent className={isMobile ? 'p-5' : 'p-8'}>
            <div className={`text-hz-success animate-pulse-hz mb-4 ${
              isMobile ? 'text-5xl' : 'text-6xl'
            }`}>✓</div>
            <h2 className={`font-bold text-hz-warm-text-primary mb-2 font-warm ${
              isMobile ? 'text-lg' : 'text-2xl'
            }`}>注册成功！</h2>
            <p className={`text-hz-warm-text-secondary ${
              isMobile ? 'text-sm' : 'text-sm'
            }`}>正在跳转到个人资料完善页面...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-hz-warm-bg px-4 sm:px-6">
      <Card className={`w-full shadow-lg border-hz-warm-border ${
        isMobile ? 'max-w-sm mx-2' : 'max-w-md'
      }`}>
        <CardHeader className={`text-center space-y-4 ${
          isMobile ? 'pb-4' : 'pb-6'
        }`}>
          <div className="flex items-center justify-center">
            <HzLogo size={isMobile ? "small" : "medium"} animated={true} showText={true} />
          </div>
          <CardTitle className={`font-warm ${
            isMobile ? 'text-lg' : 'text-2xl'
          }`}>创建你的账户</CardTitle>
        </CardHeader>
        <CardContent className={isMobile ? 'px-4 pb-6' : 'p-6'}>
          <form onSubmit={handleSubmit} className={`space-y-${isMobile ? '4' : '4'}`}>
            <div>
              <Input
                type="email"
                placeholder="请输入邮箱"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`w-full transition-colors border-hz-warm-border focus:border-hz-orange-500 focus:ring-hz-orange-500/20 ${
                  isMobile ? 'h-12 text-base rounded-lg' : 'h-10'
                }`}
              />
            </div>
            
            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="请设置密码（至少6位）"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`w-full pr-12 transition-colors border-hz-warm-border focus:border-hz-orange-500 focus:ring-hz-orange-500/20 ${
                  isMobile ? 'h-12 text-base rounded-lg' : 'h-10'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className={`absolute right-3 top-1/2 transform -translate-y-1/2 text-hz-warm-text-muted hover:text-hz-orange-500 transition-colors ${
                  isMobile ? 'p-2' : 'p-1'
                }`}
              >
                {showPassword ? <EyeOff size={isMobile ? 22 : 20} /> : <Eye size={isMobile ? 22 : 20} />}
              </button>
            </div>

            <div>
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="请再次输入密码"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className={`w-full transition-colors border-hz-warm-border focus:border-hz-orange-500 focus:ring-hz-orange-500/20 ${
                  isMobile ? 'h-12 text-base rounded-lg' : 'h-10'
                }`}
              />
            </div>

            {error && (
              <div className="text-red-500 text-sm">{error}</div>
            )}

            <Button
              type="submit"
              variant={isFormValid ? "warm" : "secondary"}
              className={`w-full font-medium transition-all active:scale-95 ${
                isMobile ? 'h-12 text-base rounded-lg' : 'h-10'
              }`}
              disabled={!isFormValid || loading}
            >
              {loading ? '注册中...' : '注册'}
            </Button>
            
            <div className={`text-center text-hz-warm-text-secondary ${
              isMobile ? 'text-sm pt-3' : 'text-sm'
            }`}>
              已有账户？{' '}
              <Link 
                to="/login" 
                className="text-hz-orange-500 hover:text-hz-orange-600 transition-colors font-medium"
              >
                立即登录
              </Link>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}