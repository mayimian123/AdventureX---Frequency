import React, { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { HzSymbol } from '@/components/ui/wave-animation'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/lib/supabase'
import { useNavigate } from 'react-router-dom'
import { useIsMobile } from '@/hooks/use-mobile'
import { Camera, X } from 'lucide-react'
import { HzUser } from '@/types'

// 预设数据
const COUNTRIES = ['国内', '国外']
const PROVINCES_DOMESTIC = ['北京市', '上海市', '天津市', '重庆市', '河北省', '山西省', '辽宁省', '吉林省', '黑龙江省', '江苏省', '浙江省', '安徽省', '福建省', '江西省', '山东省', '河南省', '湖北省', '湖南省', '广东省', '海南省', '四川省', '贵州省', '云南省', '陕西省', '甘肃省', '青海省', '内蒙古自治区', '广西壮族自治区', '西藏自治区', '宁夏回族自治区', '新疆维吾尔自治区', '香港特别行政区', '澳门特别行政区', '台湾省']
const ROLES = ['学生', '刚毕业', '刚入职', '初级工作者', '中级工作者', '创业者', '自由职业者', '其他']
const PROFESSIONAL_FIELDS = ['计算机科学', '市场营销', '艺术设计', '心理学', '教育学', '音乐', '体育运动', '营养学', '金融', '经济学', '新媒体运营', '历史学', '考古学', '商业管理', '环境科学', '其他']
const INTEREST_TAGS = ['咖啡探店', '独立电影', '创业', '心理学', '跑步', '哲学', '冥想', '书店', '古典音乐', '心理咨询', '编程', '开源', '极简主义', '电子音乐', '桌游', '插画', '手作', '摄影', '艺术展览', '健身', '营养搭配', '户外运动', '瑜伽', '登山', '投资理财', '读书', '跨境电商', '经济学', '旅行', '音乐制作', '吉他', '现场演出', '声音设计', 'vinyl收集', '美食探店', '烘焙', '历史', '博物馆', '古建筑', '茶文化', '书法', '可持续发展', '商业模式', '环保', '团队管理']

export function ProfileSetupPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const isMobile = useIsMobile()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isEditMode, setIsEditMode] = useState(false)
  
  const [formData, setFormData] = useState({
    nickname: '',
    age: '',
    avatar: null as File | null,
    avatarPreview: '',
    country: '',
    province: '',
    city: '',
    role: '',
    currentActivity: '',
    professionalFields: [] as string[],
    interestTags: [] as string[],
    aboutMe: '',
    customField: '',
    customTag: ''
  })
  
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // 加载现有资料（编辑模式）
  useEffect(() => {
    loadExistingProfile()
  }, [user])

  const loadExistingProfile = async () => {
    if (!user) return

    try {
      console.log('检查用户是否已有资料...')
      const { data: existingProfile, error } = await supabase
        .from('hz_users')
        .select('*')
        .eq('auth_user_id', user.id)
        .maybeSingle()
      
      if (error) {
        console.error('Error loading existing profile:', error)
        return
      }
      
      if (existingProfile && existingProfile.is_profile_complete) {
        console.log('编辑模式：预填充现有数据')
        setIsEditMode(true)
        setFormData({
          nickname: existingProfile.nickname || '',
          age: existingProfile.age?.toString() || '',
          avatar: null,
          avatarPreview: existingProfile.avatar_url || '',
          country: existingProfile.location_country || '',
          province: existingProfile.location_province || '',
          city: existingProfile.location_city || '',
          role: existingProfile.role || '',
          currentActivity: existingProfile.current_activity || '',
          professionalFields: existingProfile.professional_fields || [],
          interestTags: existingProfile.interest_tags || [],
          aboutMe: existingProfile.about_me || '',
          customField: '',
          customTag: ''
        })
      } else {
        console.log('新用户模式：首次完善资料')
        setIsEditMode(false)
      }
    } catch (error) {
      console.error('Error loading existing profile:', error)
    }
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setFormData(prev => ({ ...prev, avatar: file }))
      
      const reader = new FileReader()
      reader.onload = (e) => {
        setFormData(prev => ({ ...prev, avatarPreview: e.target?.result as string }))
      }
      reader.readAsDataURL(file)
    }
  }

  const toggleProfessionalField = (field: string) => {
    setFormData(prev => ({
      ...prev,
      professionalFields: prev.professionalFields.includes(field)
        ? prev.professionalFields.filter(f => f !== field)
        : [...prev.professionalFields, field]
    }))
  }

  const addCustomField = () => {
    if (formData.customField.trim()) {
      setFormData(prev => ({
        ...prev,
        professionalFields: [...prev.professionalFields, prev.customField.trim()],
        customField: ''
      }))
    }
  }

  const toggleInterestTag = (tag: string) => {
    setFormData(prev => ({
      ...prev,
      interestTags: prev.interestTags.includes(tag)
        ? prev.interestTags.filter(t => t !== tag)
        : [...prev.interestTags, tag]
    }))
  }

  const addCustomTag = () => {
    if (formData.customTag.trim()) {
      setFormData(prev => ({
        ...prev,
        interestTags: [...prev.interestTags, prev.customTag.trim()],
        customTag: ''
      }))
    }
  }

  const isFormValid = () => {
    // 编辑模式下，头像可以为空（保持原有头像）
    const avatarValid = isEditMode ? (formData.avatar || formData.avatarPreview) : formData.avatar
    
    return formData.nickname && 
           formData.age && 
           avatarValid && 
           formData.country && 
           formData.city && 
           formData.interestTags.length > 0 && 
           formData.aboutMe.trim()
  }

  const getProgress = () => {
    let filled = 0
    const total = 7 // 总项目数
    
    if (formData.nickname) filled++
    if (formData.age) filled++
    if (formData.avatar) filled++
    if (formData.country && formData.city) filled++
    if (formData.role) filled++
    if (formData.professionalFields.length > 0) filled++
    if (formData.interestTags.length > 0) filled++
    if (formData.aboutMe.trim()) filled++
    
    return Math.round((filled / total) * 100)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    console.log('🚀 开始处理表单提交...')
    console.log('📝 当前表单数据:', { 
      nickname: formData.nickname,
      age: formData.age,
      hasAvatar: !!formData.avatar,
      hasAvatarPreview: !!formData.avatarPreview,
      country: formData.country,
      city: formData.city,
      interestTagsCount: formData.interestTags.length,
      aboutMeLength: formData.aboutMe.trim().length,
      isEditMode
    })
    
    const formValid = isFormValid()
    console.log('✅ 表单验证结果:', formValid)
    
    if (!formValid) {
      const errorMsg = '请完成必填项目：头像、昵称、年龄、地址、兴趣标签、关于我'
      console.error('❌ 表单验证失败:', errorMsg)
      setError(errorMsg)
      return
    }

    if (!user) {
      const errorMsg = '用户未登录，请重新登录'
      console.error('❌ 用户未登录:', errorMsg)
      setError(errorMsg)
      return
    }

    console.log('💾 开始保存流程...')
    setLoading(true)
    setError('')

    try {
      console.log('📤 开始保存用户资料...', { userId: user.id, email: user.email })
      
      // 上传头像
      let avatarUrl = ''
      if (formData.avatar) {
        console.log('开始上传头像...')
        try {
          const reader = new FileReader()
          const base64Data = await new Promise<string>((resolve, reject) => {
            reader.onload = (e) => resolve(e.target?.result as string)
            reader.onerror = reject
            reader.readAsDataURL(formData.avatar!)
          })
          
          const { data: uploadResponse, error: uploadError } = await supabase.functions.invoke('hz-upload-avatar', {
            body: {
              imageData: base64Data,
              fileName: `avatar_${Date.now()}.jpg`,
              userId: user.id
            }
          })
          
          if (uploadError) {
            console.error('头像上传失败:', uploadError)
            throw new Error(`头像上传失败: ${uploadError.message || uploadError}`)
          }
          
          console.log('头像上传原始响应:', uploadResponse)
          
          // 检查多种可能的返回结构
          let finalAvatarUrl = null
          
          // 情况1: 直接返回 avatar_url
          if (uploadResponse && uploadResponse.avatar_url) {
            finalAvatarUrl = uploadResponse.avatar_url
          }
          // 情况2: 嵌套在 data 中
          else if (uploadResponse && uploadResponse.data && uploadResponse.data.avatar_url) {
            finalAvatarUrl = uploadResponse.data.avatar_url
          }
          // 情况3: 双层嵌套
          else if (uploadResponse && uploadResponse.data && uploadResponse.data.data && uploadResponse.data.data.avatar_url) {
            finalAvatarUrl = uploadResponse.data.data.avatar_url
          }
          
          if (!finalAvatarUrl) {
            console.error('未找到头像 URL，响应结构:', JSON.stringify(uploadResponse, null, 2))
            throw new Error('头像上传成功但未返回正确的URL地址')
          }
          
          avatarUrl = finalAvatarUrl
          console.log('头像上传成功:', avatarUrl)
        } catch (avatarError) {
          console.error('头像上传错误:', avatarError)
          throw new Error(`头像上传失败: ${avatarError.message || avatarError}`)
        }
      }

      // 创建用户资料
      const userData: Partial<HzUser> = {
        auth_user_id: user.id,
        email: user.email!,
        nickname: formData.nickname.trim(),
        age: parseInt(formData.age),
        location_country: formData.country,
        location_province: formData.province || null,
        location_city: formData.city.trim(),
        role: formData.role || null,
        current_activity: formData.currentActivity.trim() || null,
        professional_fields: formData.professionalFields,
        interest_tags: formData.interestTags,
        about_me: formData.aboutMe.trim(),
        is_profile_complete: true
      }

      // 处理头像URL：只有在有新上传的头像时才更新
      if (avatarUrl) {
        userData.avatar_url = avatarUrl
      } else if (!isEditMode) {
        // 新用户模式下，没有头像就设为null
        userData.avatar_url = null
      }
      // 编辑模式下如果没有新头像，就不更新这个字段，保持现有值

      console.log('💾 开始保存到数据库:', userData)

      let result
      if (isEditMode) {
        // 编辑模式：更新现有记录
        console.log('🔄 执行数据库更新操作...')
        const { data: updateData, error: updateError } = await supabase
          .from('hz_users')
          .update(userData)
          .eq('auth_user_id', user.id)
          .select()

        console.log('📊 数据库更新响应:', { 
          data: updateData, 
          error: updateError,
          affectedRows: updateData?.length || 0
        })

        if (updateError) {
          console.error('❌ 数据库更新错误:', updateError)
          throw new Error(`资料更新失败: ${updateError.message || updateError.details || updateError}`)
        }
        
        if (!updateData || updateData.length === 0) {
          console.error('❌ 更新操作未影响任何记录')
          throw new Error('更新失败：未找到对应的用户记录')
        }
        
        result = updateData
        console.log('✅ 用户资料更新成功:', updateData)
      } else {
        // 新用户模式：插入新记录
        console.log('➕ 执行数据库插入操作...')
        const { data: insertData, error: insertError } = await supabase
          .from('hz_users')
          .insert([userData])
          .select()

        console.log('📊 数据库插入响应:', { 
          data: insertData, 
          error: insertError,
          insertedRows: insertData?.length || 0
        })

        if (insertError) {
          console.error('❌ 数据库插入错误:', insertError)
          if (insertError.code === '23505') {
            throw new Error('该邮箱已被注册，请使用其他邮箱')
          }
          throw new Error(`数据保存失败: ${insertError.message || insertError.details || insertError}`)
        }
        
        if (!insertData || insertData.length === 0) {
          console.error('❌ 插入操作未创建任何记录')
          throw new Error('保存失败：数据插入未成功')
        }
        
        result = insertData
        console.log('✅ 用户资料保存成功:', insertData)
      }
      const successMessage = isEditMode ? '✅ 资料更新成功！' : '✅ 资料保存成功！正在跳转到主页...'
      console.log('🎉 操作成功完成:', successMessage)
      alert(successMessage)
      
      // 稍微延迟跳转
      setTimeout(() => {
        console.log('🚀 正在跳转到主页...')
        navigate('/app')
      }, isEditMode ? 500 : 1000)
      
    } catch (err: any) {
      console.error('❌ Profile setup error:', err)
      const errorMessage = err.message || '保存失败，请检查网络连接后重试'
      console.error('💥 最终错误信息:', errorMessage)
      setError(errorMessage)
    } finally {
      console.log('🏁 保存流程结束，设置loading为false')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-hz-warm-bg px-4 py-6 sm:py-8">
      <div className={`mx-auto ${
        isMobile ? 'max-w-md px-2' : 'max-w-2xl'
      }`}>
        {/* 顶部信息 */}
        <div className={`text-center mb-6 sm:mb-8 ${
          isMobile ? 'px-2' : ''
        }`}>
          <div className="flex items-center justify-center mb-4">
            <HzSymbol size={isMobile ? 24 : 32} className="mr-2" />
            <span className={`font-bold text-hz-warm-text-primary font-warm ${
              isMobile ? 'text-lg' : 'text-2xl'
            }`}>赫兹</span>
          </div>
          <h1 className={`font-bold text-hz-warm-text-primary mb-3 font-warm ${
            isMobile ? 'text-lg' : 'text-2xl'
          }`}>
            {isEditMode ? '编辑个人资料' : '你的频道正在调频中...'}
          </h1>
          <div className={`flex items-center justify-center space-x-2 ${
            isMobile ? 'px-4' : ''
          }`}>
            <div className={`bg-hz-warm-border rounded-full h-2 ${
              isMobile ? 'w-32' : 'w-48'
            }`}>
              <div 
                className="bg-hz-orange-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${getProgress()}%` }}
              />
            </div>
            <span className={`text-hz-warm-text-secondary ${
              isMobile ? 'text-xs' : 'text-sm'
            }`}>完成{getProgress()}%即可开启匹配</span>
          </div>
        </div>

        <Card className="shadow-lg border-hz-warm-border">
          <CardContent className={isMobile ? 'p-4' : 'p-8'}>
            <form onSubmit={handleSubmit} className={`space-y-${isMobile ? '5' : '8'}`}>
              {/* 头像上传 */}
              <div className="text-center">
                <div className="relative inline-block">
                  {formData.avatarPreview ? (
                    <img 
                      src={formData.avatarPreview} 
                      alt="头像预览" 
                      className={`rounded-full object-cover border-4 border-hz-orange-500 ${
                        isMobile ? 'w-24 h-24' : 'w-24 h-24'
                      }`}
                    />
                  ) : (
                    <div className={`rounded-full bg-hz-warm-social-warm flex items-center justify-center border-4 border-hz-warm-border ${
                      isMobile ? 'w-24 h-24' : 'w-24 h-24'
                    }`}>
                      <Camera className={`text-hz-warm-text-muted ${
                        isMobile ? 'w-8 h-8' : 'w-8 h-8'
                      }`} />
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className={`absolute -bottom-1 -right-1 bg-hz-orange-500 text-white rounded-full hover:bg-hz-orange-600 active:scale-95 transition-all ${
                      isMobile ? 'p-2 min-w-[44px] min-h-[44px] w-8 h-8 flex items-center justify-center' : 'p-2'
                    }`}
                  >
                    <Camera size={isMobile ? 16 : 16} />
                  </button>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <p className={`text-hz-warm-text-secondary mt-2 ${
                  isMobile ? 'text-sm' : 'text-sm'
                }`}>点击上传头像 *</p>
              </div>

              {/* 基本信息 */}
              <div className={`grid gap-4 ${
                isMobile ? 'grid-cols-1' : 'md:grid-cols-2'
              }`}>
                <div>
                  <label className={`block font-medium text-hz-warm-text-primary mb-2 ${
                    isMobile ? 'text-sm' : 'text-sm'
                  }`}>昵称 *</label>
                  <Input
                    value={formData.nickname}
                    onChange={(e) => setFormData(prev => ({ ...prev, nickname: e.target.value }))}
                    placeholder="请输入昵称"
                    className={`border-hz-warm-border focus:border-hz-orange-500 focus:ring-hz-orange-500/20 ${
                      isMobile ? 'h-12 text-base' : 'h-10'
                    }`}
                  />
                </div>
                <div>
                  <label className={`block font-medium text-hz-warm-text-primary mb-2 ${
                    isMobile ? 'text-sm' : 'text-sm'
                  }`}>年龄 *</label>
                  <Input
                    type="number"
                    min="16"
                    max="26"
                    value={formData.age}
                    onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                    placeholder="16-26岁"
                    className={`border-hz-warm-border focus:border-hz-orange-500 focus:ring-hz-orange-500/20 ${
                      isMobile ? 'h-12 text-base' : 'h-10'
                    }`}
                  />
                </div>
              </div>

              {/* 地址选择 */}
              <div>
                <label className={`block font-medium text-hz-warm-text-primary mb-2 ${
                  isMobile ? 'text-sm' : 'text-sm'
                }`}>地址 *</label>
                <div className={`grid gap-3 ${
                  isMobile ? 'grid-cols-1 space-y-2' : 'md:grid-cols-3'
                }`}>
                  <select
                    value={formData.country}
                    onChange={(e) => setFormData(prev => ({ ...prev, country: e.target.value, province: '', city: '' }))}
                    className={`w-full px-3 border border-hz-warm-border rounded-md focus:outline-none focus:ring-2 focus:ring-hz-orange-500 focus:border-hz-orange-500 text-hz-warm-text-primary ${
                      isMobile ? 'py-3 text-base' : 'py-2'
                    }`}
                  >
                    <option value="">选择国家/地区</option>
                    {COUNTRIES.map(country => (
                      <option key={country} value={country}>{country}</option>
                    ))}
                  </select>
                  
                  {formData.country === '国内' && (
                    <select
                      value={formData.province}
                      onChange={(e) => setFormData(prev => ({ ...prev, province: e.target.value, city: '' }))}
                      className={`w-full px-3 border border-hz-warm-border rounded-md focus:outline-none focus:ring-2 focus:ring-hz-orange-500 focus:border-hz-orange-500 text-hz-warm-text-primary ${
                        isMobile ? 'py-3 text-base' : 'py-2'
                      }`}
                    >
                      <option value="">选择省份</option>
                      {PROVINCES_DOMESTIC.map(province => (
                        <option key={province} value={province}>{province}</option>
                      ))}
                    </select>
                  )}
                  
                  <Input
                    value={formData.city}
                    onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                    placeholder="请输入城市"
                    className={`border-hz-warm-border focus:border-hz-orange-500 focus:ring-hz-orange-500/20 ${
                      isMobile ? 'h-12 text-base' : 'h-10'
                    }`}
                  />
                </div>
              </div>

              {/* 角色 */}
              <div>
                <label className={`block font-medium text-hz-warm-text-primary mb-2 ${
                  isMobile ? 'text-sm' : 'text-sm'
                }`}>角色</label>
                <select
                  value={formData.role}
                  onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value }))}
                  className={`w-full px-3 border border-hz-warm-border rounded-md focus:outline-none focus:ring-2 focus:ring-hz-orange-500 focus:border-hz-orange-500 text-hz-warm-text-primary ${
                    isMobile ? 'py-3 text-base' : 'py-2'
                  }`}
                >
                  <option value="">选择你的角色</option>
                  {ROLES.map(role => (
                    <option key={role} value={role}>{role}</option>
                  ))}
                </select>
              </div>

              {/* 目前在做什么 */}
              <div>
                <label className={`block font-medium text-hz-warm-text-primary mb-2 ${
                  isMobile ? 'text-sm' : 'text-sm'
                }`}>目前在做什么</label>
                <Input
                  value={formData.currentActivity}
                  onChange={(e) => setFormData(prev => ({ ...prev, currentActivity: e.target.value }))}
                  placeholder="简单描述你的现状"
                  className={`border-hz-warm-border focus:border-hz-orange-500 focus:ring-hz-orange-500/20 ${
                    isMobile ? 'h-12 text-base' : 'h-10'
                  }`}
                />
              </div>

              {/* 专业领域 */}
              <div>
                <label className={`block font-medium text-hz-warm-text-primary mb-3 ${
                  isMobile ? 'text-sm' : 'text-sm'
                }`}>专业领域</label>
                <div className={`flex flex-wrap gap-2 mb-4 ${
                  isMobile ? 'gap-2' : 'gap-2'
                }`}>
                  {PROFESSIONAL_FIELDS.map(field => (
                    <button
                      key={field}
                      type="button"
                      onClick={() => toggleProfessionalField(field)}
                      className={`rounded-full border transition-all active:scale-95 font-medium ${
                        isMobile ? 'px-4 py-2 text-sm' : 'px-3 py-1 text-sm'
                      } ${
                        formData.professionalFields.includes(field)
                          ? 'bg-hz-orange-500 text-white border-hz-orange-500 shadow-md'
                          : 'bg-hz-warm-surface text-hz-warm-text-secondary border-hz-warm-border hover:border-hz-orange-500 hover:text-hz-orange-500'
                      }`}
                    >
                      {field}
                    </button>
                  ))}
                </div>
                <div className={`flex gap-2 ${
                  isMobile ? 'flex-col' : ''
                }`}>
                  <Input
                    value={formData.customField}
                    onChange={(e) => setFormData(prev => ({ ...prev, customField: e.target.value }))}
                    placeholder="自定义专业领域"
                    className={`flex-1 border-hz-warm-border focus:border-hz-orange-500 focus:ring-hz-orange-500/20 ${
                      isMobile ? 'h-12 text-base' : 'h-10'
                    }`}
                  />
                  <Button 
                    type="button" 
                    onClick={addCustomField} 
                    variant="outline"
                    className={`border-hz-warm-border hover:border-hz-orange-500 hover:text-hz-orange-500 ${
                      isMobile ? 'h-12 w-full' : 'h-10'
                    }`}
                  >
                    添加
                  </Button>
                </div>
              </div>

              {/* 兴趣标签 */}
              <div>
                <label className={`block font-medium text-hz-warm-text-primary mb-3 ${
                  isMobile ? 'text-sm' : 'text-sm'
                }`}>兴趣标签 *</label>
                <div className={`flex flex-wrap gap-2 mb-4 max-h-${isMobile ? '40' : '32'} overflow-y-auto ${
                  isMobile ? 'gap-2' : 'gap-2'
                }`}>
                  {INTEREST_TAGS.map(tag => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => toggleInterestTag(tag)}
                      className={`rounded-full border transition-all active:scale-95 font-medium ${
                        isMobile ? 'px-4 py-2 text-sm' : 'px-3 py-1 text-sm'
                      } ${
                        formData.interestTags.includes(tag)
                          ? 'bg-hz-orange-500 text-white border-hz-orange-500 shadow-md'
                          : 'bg-hz-warm-surface text-hz-warm-text-secondary border-hz-warm-border hover:border-hz-orange-500 hover:text-hz-orange-500'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
                <div className={`flex gap-2 ${
                  isMobile ? 'flex-col' : ''
                }`}>
                  <Input
                    value={formData.customTag}
                    onChange={(e) => setFormData(prev => ({ ...prev, customTag: e.target.value }))}
                    placeholder="自定义兴趣标签"
                    className={`flex-1 border-hz-warm-border focus:border-hz-orange-500 focus:ring-hz-orange-500/20 ${
                      isMobile ? 'h-12 text-base' : 'h-10'
                    }`}
                  />
                  <Button 
                    type="button" 
                    onClick={addCustomTag} 
                    variant="outline"
                    className={`border-hz-warm-border hover:border-hz-orange-500 hover:text-hz-orange-500 ${
                      isMobile ? 'h-12 w-full' : 'h-10'
                    }`}
                  >
                    添加
                  </Button>
                </div>
              </div>

              {/* 关于我 */}
              <div>
                <label className={`block font-medium text-hz-warm-text-primary mb-2 ${
                  isMobile ? 'text-sm' : 'text-sm'
                }`}>关于我 *</label>
                <textarea
                  value={formData.aboutMe}
                  onChange={(e) => setFormData(prev => ({ ...prev, aboutMe: e.target.value }))}
                  placeholder="介绍一下你自己，让大家更好地了解你..."
                  className={`w-full px-3 py-3 border border-hz-warm-border rounded-md focus:outline-none focus:ring-2 focus:ring-hz-orange-500/20 focus:border-hz-orange-500 resize-none text-hz-warm-text-primary ${
                    isMobile ? 'text-base' : ''
                  }`}
                  rows={isMobile ? 4 : 4}
                  maxLength={150}
                />
                <div className={`text-right text-hz-warm-text-muted mt-1 ${
                  isMobile ? 'text-sm' : 'text-sm'
                }`}>
                  {formData.aboutMe.length}/150
                </div>
              </div>

              {error && (
                <div className="text-hz-error text-sm bg-red-50 border border-red-200 rounded-md p-3">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                variant={isFormValid() ? "warm" : "secondary"}
                className={`w-full font-medium transition-all active:scale-95 ${
                  isMobile ? 'h-14 text-lg' : 'h-12 text-base'
                }`}
                disabled={!isFormValid() || loading}
              >
                {loading ? (isEditMode ? '更新中...' : '保存中...') : (isEditMode ? '保存修改' : '完成设置，开始匹配')}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}