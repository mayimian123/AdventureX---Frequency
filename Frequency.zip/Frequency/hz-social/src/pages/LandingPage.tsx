import React from 'react'
import { Button } from '@/components/ui/button'
import { WaveAnimation } from '@/components/ui/wave-animation'
import { HzLogo } from '@/components/ui/hz-logo'
import { useAuth } from '@/contexts/AuthContext'
import { useNavigate } from 'react-router-dom'

export function LandingPage() {
  const { user } = useAuth()
  const navigate = useNavigate()

  React.useEffect(() => {
    if (user) {
      navigate('/app')
    }
  }, [user, navigate])

  const handleStartMatching = () => {
    console.log('开始匹配按钮被点击')
    try {
      navigate('/login')
      console.log('导航到登录页面')
    } catch (error) {
      console.error('导航错误:', error)
    }
  }

  return (
    <div className="min-h-screen relative bg-gradient-to-br from-hz-warm-bg to-white overflow-hidden">
      {/* 背景波浪动画 */}
      <WaveAnimation className="absolute inset-0 w-full h-full" />
      
      {/* 主内容 */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-cozy">
        <div className="text-center max-w-4xl mx-auto">
          {/* Logo 和 Slogan */}
          <div className="mb-warm">
            <div className="flex items-center justify-center mb-6">
              <HzLogo size="xlarge" animated={true} showText={true} />
            </div>
            <h2 className="text-2xl md:text-3xl font-warm font-medium text-hz-warm-text-secondary mb-2">
              温暖连接，真实社交
            </h2>
          </div>

          {/* 三行文案 */}
          <div className="space-y-6 mb-16 text-lg md:text-xl text-hz-warm-text-secondary leading-relaxed font-warm">
            <p className="animate-pulse-hz">
              16-26岁的你，无论刚入学、刚入职，还是想突破社交圈
            </p>
            <p className="animate-pulse-hz" style={{ animationDelay: '0.5s' }}>
              不用再为“融不进去”焦虑，不用在无效社交里消耗
            </p>
            <p className="animate-pulse-hz" style={{ animationDelay: '1s' }}>
              在这里，找到频率相近的人，让成长像共振一样自然发生
            </p>
          </div>

          {/* 开始按钮 */}
          <Button 
            onClick={handleStartMatching}
            className="px-12 py-4 text-lg font-accent font-semibold bg-hz-orange-500 hover:bg-hz-orange-600 text-white rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 cursor-pointer"
            onMouseEnter={() => console.log('按钮hover')}
          >
            开始匹配
          </Button>
          
          {/* 备用链接按钮，用于调试 */}
          <div className="mt-4">
            <button 
              onClick={() => {
                console.log('备用按钮被点击')
                console.log('当前页面路径:', window.location.pathname)
                try {
                  navigate('/login')
                  console.log('使用navigate跳转到/login')
                } catch (error) {
                  console.error('navigate失败，使用window.location.href:', error)
                  window.location.href = '/login'
                }
              }}
              className="text-hz-orange-500 underline cursor-pointer font-warm hover:text-hz-orange-600 transition-colors"
            >
              直接进入登录页面
            </button>
          </div>

          {/* 频率波纹装饰 */}
          <div className="mt-16">
            <div className="flex justify-center space-x-2">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="w-1 bg-hz-orange-400 rounded-full animate-wave"
                  style={{
                    height: `${20 + Math.random() * 40}px`,
                    animationDelay: `${i * 0.2}s`
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}