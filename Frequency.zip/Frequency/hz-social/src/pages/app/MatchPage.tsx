import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { HzSymbol } from '@/components/ui/wave-animation'
import { UserDetailModal } from '@/components/ui/user-detail-modal'
import { useAuth } from '@/contexts/AuthContext'
import { supabase, getUserProfile } from '@/lib/supabase'
import { Match, HzUser } from '@/types'
import { getMatchScoreColor, getMatchScoreBgColor } from '@/lib/utils'
import { Search, MapPin, Briefcase, Heart, Eye } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

export function MatchPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [userProfile, setUserProfile] = useState<HzUser | null>(null)
  const [matches, setMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredMatches, setFilteredMatches] = useState<Match[]>([])
  const [selectedUser, setSelectedUser] = useState<HzUser | null>(null)
  const [selectedUserScore, setSelectedUserScore] = useState<number>(0)
  const [isModalOpen, setIsModalOpen] = useState(false)

  useEffect(() => {
    loadUserProfile()
  }, [user])

  useEffect(() => {
    if (userProfile) {
      findMatches()
    }
  }, [userProfile])

  useEffect(() => {
    filterMatches()
  }, [matches, searchTerm])

  const loadUserProfile = async () => {
    if (!user) {
      console.log('User not available yet')
      return
    }

    try {
      console.log('Loading user profile for:', user.email)
      
      // 直接从数据库查询用户资料
      const { data: profile, error } = await supabase
        .from('hz_users')
        .select('*')
        .eq('auth_user_id', user.id)
        .maybeSingle()
      
      if (error) {
        console.error('Error loading user profile:', error)
        return
      }
      
      if (profile) {
        console.log('User profile loaded:', profile.nickname)
        setUserProfile(profile)
      } else {
        console.log('No profile found for user')
      }
    } catch (error) {
      console.error('Error loading user profile:', error)
    }
  }

  const findMatches = async () => {
    if (!userProfile) return

    try {
      setLoading(true)
      console.log('开始查找匹配用户，当前用户ID:', userProfile.id)
      
      // 调用匹配算法Edge Function
      const { data, error } = await supabase.functions.invoke('hz-match-users', {
        body: { userId: userProfile.id }
      })

      console.log('匹配算法响应:', { data, error })

      if (error) {
        console.error('Error finding matches:', error)
        // 如果Edge Function失败，fallback到客户端匹配
        await findMatchesClientSide()
        return
      }

      if (data && data.data && data.data.matches) {
        console.log('找到匹配用户:', data.data.matches.length, '个')
        setMatches(data.data.matches)
      } else {
        console.log('Edge Function返回空结果，尝试客户端匹配')
        await findMatchesClientSide()
      }
    } catch (error) {
      console.error('Error finding matches:', error)
      // fallback到客户端匹配
      await findMatchesClientSide()
    } finally {
      setLoading(false)
    }
  }

  // 客户端匹配算法作为fallback
  const findMatchesClientSide = async () => {
    if (!userProfile) return

    try {
      console.log('使用客户端匹配算法')
      // 获取所有其他用户
      const { data: users, error } = await supabase
        .from('hz_users')
        .select('*')
        .neq('id', userProfile.id)
        .eq('is_profile_complete', true)
      
      if (error) {
        console.error('Error fetching users:', error)
        return
      }

      console.log('获取到其他用户:', users?.length || 0, '个')

      if (!users || users.length === 0) {
        setMatches([])
        return
      }

      // 客户端匹配算法
      const calculateMatchScore = (user1: any, user2: any) => {
        let score = 0
        
        // 兴趣标签重叠度 (40%)
        const tags1 = user1.interest_tags || []
        const tags2 = user2.interest_tags || []
        const commonTags = tags1.filter((tag: string) => tags2.includes(tag))
        const totalTags = new Set([...tags1, ...tags2]).size
        const tagScore = totalTags > 0 ? (commonTags.length / totalTags) * 40 : 0
        
        // 城市距离 (20%)
        const cityScore = user1.location_city === user2.location_city ? 20 : 
                         user1.location_province === user2.location_province ? 10 : 0
        
        // 专业领域关联 (20%)
        const fields1 = user1.professional_fields || []
        const fields2 = user2.professional_fields || []
        const commonFields = fields1.filter((field: string) => fields2.includes(field))
        const totalFields = new Set([...fields1, ...fields2]).size
        const fieldScore = totalFields > 0 ? (commonFields.length / totalFields) * 20 : 0
        
        // 年龄互动潜力 (20%)
        const ageDiff = Math.abs(user1.age - user2.age)
        const ageScore = Math.max(0, 20 - ageDiff * 2)
        
        score = Math.round(tagScore + cityScore + fieldScore + ageScore)
        return Math.min(100, Math.max(1, score))
      }

      // 计算所有用户的匹配度
      const matches = users.map(user => ({
        user,
        score: calculateMatchScore(userProfile, user)
      }))

      // 按匹配度排序显示所有用户（不再过滤）
      const allMatches = matches
        .sort((a, b) => b.score - a.score)

      console.log('客户端匹配结果:', allMatches.length, '个用户，按匹配度排序')
      setMatches(allMatches)
    } catch (error) {
      console.error('Client-side matching error:', error)
      setMatches([])
    }
  }

  const filterMatches = () => {
    if (!searchTerm.trim()) {
      setFilteredMatches(matches)
      return
    }

    const filtered = matches.filter(match => {
      const user = match.user
      const searchLower = searchTerm.toLowerCase()
      
      return (
        user.nickname.toLowerCase().includes(searchLower) ||
        user.location_city?.toLowerCase().includes(searchLower) ||
        user.role?.toLowerCase().includes(searchLower) ||
        user.interest_tags.some(tag => tag.toLowerCase().includes(searchLower)) ||
        user.about_me?.toLowerCase().includes(searchLower)
      )
    })
    
    setFilteredMatches(filtered)
  }

  const getCommonTags = (userTags: string[], otherTags: string[]) => {
    return userTags.filter(tag => otherTags.includes(tag))
  }

  const handleSayHello = async (targetUser: HzUser) => {
    if (!userProfile) {
      alert('请先完善个人资料')
      return
    }

    try {
      // 获取匹配度信息
      const targetMatch = filteredMatches.find(match => match.user.id === targetUser.id)
      const matchScore = targetMatch ? targetMatch.score : 50
      
      // 根据匹配度自定义打招呼消息
      let greetingMessage
      if (matchScore >= 80) {
        greetingMessage = `Hi！我是${userProfile.nickname}，看到我们的匹配度是${matchScore}Hz，感觉很有缘分呢！想和你聊聊 ✨`
      } else if (matchScore >= 60) {
        greetingMessage = `你好！我是${userProfile.nickname}，我们有${matchScore}Hz的匹配度，想认识一下你 😊`
      } else {
        greetingMessage = `Hi！我是${userProfile.nickname}，虽然我们的匹配度是${matchScore}Hz，但我觉得你很有趣，想和你聊聊 🌟`
      }

      console.log('发送打招呼消息:', greetingMessage)
      
      // 发送打招呼消息
      const { data, error } = await supabase.functions.invoke('hz-send-message', {
        body: {
          senderId: userProfile.id,
          receiverId: targetUser.id,
          content: greetingMessage,
          messageType: 'text'
        }
      })

      if (error) {
        console.error('Error sending message:', error)
        alert('发送消息失败，请重试')
        return
      }

      console.log('打招呼消息发送成功:', data)
      alert(`已向 ${targetUser.nickname} 发送打招呼消息！你可以在聊天页面查看对话。`)
      setIsModalOpen(false) // 关闭悬浮窗
      navigate('/app/chat')
    } catch (error) {
      console.error('Error sending hello message:', error)
      alert('发送消息失败')
    }
  }

  const handleViewUserDetail = (user: HzUser, score: number) => {
    setSelectedUser(user)
    setSelectedUserScore(score)
    setIsModalOpen(true)
  }

  const handleCloseModal = () => {
    setIsModalOpen(false)
    setSelectedUser(null)
    setSelectedUserScore(0)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin">
          <HzSymbol size={32} />
        </div>
      </div>
    )
  }

  const highMatches = filteredMatches.filter(m => m.score >= 80)
  const allOtherMatches = filteredMatches.filter(m => m.score < 80)

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      {/* 标题和搜索 */}
      <div className="mb-6 md:mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 md:mb-6 space-y-4 md:space-y-0">
          <div className="text-center md:text-left">
            <h1 className="text-xl md:text-3xl font-bold text-gray-900 mb-2">
              为你找到 {filteredMatches.length} 位用户
            </h1>
            {highMatches.length > 0 && (
              <p className="text-hz-orange-500 font-medium text-sm md:text-base">
                其中 {highMatches.length} 位高匹配度用户 (80-100Hz)
              </p>
            )}
          </div>
          <HzSymbol size={32} className="self-center md:self-auto" />
        </div>
        
        {/* 搜索框 */}
        <div className="relative max-w-full md:max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <Input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="搜索用户名、标签或关键词..."
            className="pl-10 h-10 md:h-10 text-sm md:text-base"
          />
        </div>
      </div>

      {/* 高匹配度用户 */}
      {highMatches.length > 0 && (
        <div className="mb-6 md:mb-8">
          <h2 className="text-lg md:text-xl font-bold text-gray-900 mb-4 flex items-center justify-center md:justify-start">
            <Heart className="text-hz-orange-500 mr-2" size={18} />
            高匹配度用户 (80-100Hz)
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {highMatches.map((match) => (
              <MatchCard
                key={match.user.id}
                match={match}
                userProfile={userProfile}
                onSayHello={() => handleSayHello(match.user)}
                onViewDetail={() => handleViewUserDetail(match.user, match.score)}
              />
            ))}
          </div>
        </div>
      )}

      {/* 其他用户 */}
      {allOtherMatches.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">
            其他用户 (按匹配度排序)
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allOtherMatches.map((match) => (
              <MatchCard
                key={match.user.id}
                match={match}
                userProfile={userProfile}
                onSayHello={() => handleSayHello(match.user)}
                onViewDetail={() => handleViewUserDetail(match.user, match.score)}
              />
            ))}
          </div>
        </div>
      )}

      {/* 无结果 */}
      {filteredMatches.length === 0 && (
        <Card>
          <CardContent className="text-center py-16">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">暂无匹配结果</h3>
            <p className="text-gray-600 mb-6">
              {searchTerm ? '试试修改搜索关键词' : '稍后再来看看，或者完善你的资料'}
            </p>
            <Button onClick={() => navigate('/app/profile-edit')} variant="warm">
              完善资料
            </Button>
          </CardContent>
        </Card>
      )}
      
      {/* 用户详情悬浮窗 */}
      {selectedUser && (
        <UserDetailModal
          user={selectedUser}
          matchScore={selectedUserScore}
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          onSayHello={() => handleSayHello(selectedUser)}
        />
      )}
    </div>
  )
}

interface MatchCardProps {
  match: Match
  userProfile: HzUser | null
  onSayHello: () => void
  onViewDetail: () => void
}

function MatchCard({ match, userProfile, onSayHello, onViewDetail }: MatchCardProps) {
  const { user: matchUser, score } = match
  const commonTags = userProfile 
    ? userProfile.interest_tags.filter(tag => matchUser.interest_tags.includes(tag))
    : []

  return (
    <Card className={`transition-all duration-200 hover:shadow-lg ${getMatchScoreBgColor(score)}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <img
              src={matchUser.avatar_url || '/avatars/default.jpg'}
              alt={matchUser.nickname}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <h3 className="font-bold text-gray-900">{matchUser.nickname}</h3>
              <p className="text-sm text-gray-600">{matchUser.age}岁</p>
            </div>
          </div>
          <div className={`px-2 py-1 rounded-full text-sm font-bold ${getMatchScoreColor(score)}`}>
            {score}Hz
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        {/* 位置和职业 */}
        <div className="flex items-center space-x-4 text-sm text-gray-600">
          <div className="flex items-center space-x-1">
            <MapPin size={14} />
            <span>{matchUser.location_city}</span>
          </div>
          {matchUser.role && (
            <div className="flex items-center space-x-1">
              <Briefcase size={14} />
              <span>{matchUser.role}</span>
            </div>
          )}
        </div>
        
        {/* 共同标签 */}
        {commonTags.length > 0 && (
          <div>
            <p className="text-sm font-medium text-gray-700 mb-1">共同兴趣:</p>
            <div className="flex flex-wrap gap-1">
              {commonTags.slice(0, 3).map((tag, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-hz-orange-100 text-hz-orange-600 rounded-md text-xs"
                >
                  {tag}
                </span>
              ))}
              {commonTags.length > 3 && (
                <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded-md text-xs">
                  +{commonTags.length - 3}
                </span>
              )}
            </div>
          </div>
        )}
        
        {/* 关于我精选 */}
        {matchUser.about_me && (
          <p className="text-sm text-gray-600 line-clamp-2">
            {matchUser.about_me.length > 60 
              ? `${matchUser.about_me.substring(0, 60)}...` 
              : matchUser.about_me
            }
          </p>
        )}
        
        {/* 操作按钮 */}
        <div className="flex space-x-2">
          <Button
            onClick={onSayHello}
            variant="warm"
            size="sm"
            className="flex-1"
          >
            打招呼
          </Button>
          <Button
            onClick={onViewDetail}
            variant="outline"
            size="sm"
            className="flex-1 border-hz-orange-200 text-hz-orange-600 hover:bg-hz-orange-50"
          >
            <Eye size={14} className="mr-1" />
            查看信息
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}