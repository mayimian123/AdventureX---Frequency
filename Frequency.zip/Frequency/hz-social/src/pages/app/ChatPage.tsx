import React, { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { HzSymbol } from '@/components/ui/wave-animation'
import { useAuth } from '@/contexts/AuthContext'
import { supabase, getUserProfile } from '@/lib/supabase'
import { Conversation, Message, HzUser } from '@/types'
import { formatTime } from '@/lib/utils'
import { Search, Send, ArrowLeft } from 'lucide-react'
import type { RealtimeChannel } from '@supabase/supabase-js'

interface ConversationWithUser extends Conversation {
  otherUser: HzUser
  lastMessage?: Message
  unreadCount: number
}

export function ChatPage() {
  const { user } = useAuth()
  const [userProfile, setUserProfile] = useState<HzUser | null>(null)
  const [conversations, setConversations] = useState<ConversationWithUser[]>([])
  const [selectedConversation, setSelectedConversation] = useState<ConversationWithUser | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [searchTerm, setSearchTerm] = useState('')
  const [loading, setLoading] = useState(true)
  const [sendingMessage, setSendingMessage] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const realtimeChannelRef = useRef<RealtimeChannel | null>(null)

  useEffect(() => {
    loadUserProfile()
  }, [user])

  useEffect(() => {
    if (userProfile) {
      loadConversations()
    }
  }, [userProfile])

  useEffect(() => {
    if (selectedConversation) {
      loadMessages()
      markMessagesAsRead()
      setupRealtimeSubscription()
    }
    return () => {
      cleanupRealtimeSubscription()
    }
  }, [selectedConversation])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // 清理实时订阅
  useEffect(() => {
    return () => {
      cleanupRealtimeSubscription()
    }
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const loadUserProfile = async () => {
    if (!user) {
      console.log('User not available yet')
      return
    }

    try {
      console.log('Loading user profile for:', user.email)
      
      // 直接从数据库查询用户资料
      const { data: profile, error } = await supabase
        .from('hz_users')
        .select('*')
        .eq('auth_user_id', user.id)
        .maybeSingle()
      
      if (error) {
        console.error('Error loading user profile:', error)
        return
      }
      
      if (profile) {
        console.log('User profile loaded:', profile.nickname)
        setUserProfile(profile)
      } else {
        console.log('No profile found for user')
      }
    } catch (error) {
      console.error('Error loading user profile:', error)
    }
  }

  const loadConversations = async () => {
    if (!userProfile) return

    try {
      setLoading(true)
      
      // 获取对话列表
      const { data: conversationsData, error } = await supabase
        .from('hz_conversations')
        .select('*')
        .or(`participant1_id.eq.${userProfile.id},participant2_id.eq.${userProfile.id}`)
        .order('last_message_at', { ascending: false })

      if (error) throw error

      if (!conversationsData || conversationsData.length === 0) {
        setConversations([])
        return
      }

      // 获取对话中的其他用户信息
      const otherUserIds = conversationsData.map(conv => 
        conv.participant1_id === userProfile.id ? conv.participant2_id : conv.participant1_id
      )

      const { data: usersData } = await supabase
        .from('hz_users')
        .select('*')
        .in('id', otherUserIds)

      // 获取最后一条消息
      const { data: lastMessages } = await supabase
        .from('hz_messages')
        .select('*')
        .in('conversation_id', conversationsData.map(c => c.id))
        .order('created_at', { ascending: false })

      // 获取未读消息数
      const { data: unreadCounts } = await supabase
        .from('hz_messages')
        .select('conversation_id')
        .in('conversation_id', conversationsData.map(c => c.id))
        .eq('is_read', false)
        .neq('sender_id', userProfile.id)

      // 组合数据
      const conversationsWithUsers: ConversationWithUser[] = conversationsData.map(conv => {
        const otherUserId = conv.participant1_id === userProfile.id ? conv.participant2_id : conv.participant1_id
        const otherUser = usersData?.find(u => u.id === otherUserId)
        const lastMessage = lastMessages?.find(m => m.conversation_id === conv.id)
        const unreadCount = unreadCounts?.filter(m => m.conversation_id === conv.id).length || 0

        return {
          ...conv,
          otherUser: otherUser!,
          lastMessage,
          unreadCount
        }
      }).filter(conv => conv.otherUser) // 过滤掉没有用户信息的对话

      setConversations(conversationsWithUsers)
    } catch (error) {
      console.error('Error loading conversations:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadMessages = async () => {
    if (!selectedConversation) return

    try {
      const { data, error } = await supabase
        .from('hz_messages')
        .select('*')
        .eq('conversation_id', selectedConversation.id)
        .order('created_at', { ascending: true })

      if (error) throw error
      setMessages(data || [])
    } catch (error) {
      console.error('Error loading messages:', error)
    }
  }

  const markMessagesAsRead = async () => {
    if (!selectedConversation || !userProfile) return

    try {
      await supabase
        .from('hz_messages')
        .update({ is_read: true })
        .eq('conversation_id', selectedConversation.id)
        .eq('is_read', false)
        .neq('sender_id', userProfile.id)
    } catch (error) {
      console.error('Error marking messages as read:', error)
    }
  }

  // 设置实时订阅
  const setupRealtimeSubscription = () => {
    if (!selectedConversation || !userProfile) return

    cleanupRealtimeSubscription()

    console.log('设置实时消息订阅 for conversation:', selectedConversation.id)
    
    realtimeChannelRef.current = supabase
      .channel(`conversation-${selectedConversation.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'hz_messages',
          filter: `conversation_id=eq.${selectedConversation.id}`
        },
        (payload) => {
          console.log('收到新消息:', payload.new)
          const newMessage = payload.new as Message
          
          // 只添加不是当前用户发送的消息
          if (newMessage.sender_id !== userProfile.id) {
            setMessages(prev => {
              // 检查消息是否已存在，避免重复
              const exists = prev.some(msg => msg.id === newMessage.id)
              if (exists) return prev
              return [...prev, newMessage]
            })
            
            // 标记消息为已读
            markMessageAsRead(newMessage.id)
          }
          
          // 更新对话列表
          loadConversations()
        }
      )
      .subscribe((status) => {
        console.log('实时订阅状态:', status)
      })
  }

  // 清理实时订阅
  const cleanupRealtimeSubscription = () => {
    if (realtimeChannelRef.current) {
      console.log('清理实时订阅')
      supabase.removeChannel(realtimeChannelRef.current)
      realtimeChannelRef.current = null
    }
  }

  // 标记单条消息为已读
  const markMessageAsRead = async (messageId: string) => {
    try {
      await supabase
        .from('hz_messages')
        .update({ is_read: true })
        .eq('id', messageId)
    } catch (error) {
      console.error('Error marking message as read:', error)
    }
  }

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation || !userProfile || sendingMessage) return

    setSendingMessage(true)
    const messageContent = newMessage.trim()
    setNewMessage('') // 立即清空输入框

    try {
      const { data, error } = await supabase.functions.invoke('hz-send-message', {
        body: {
          senderId: userProfile.id,
          receiverId: selectedConversation.otherUser.id,
          content: messageContent,
          messageType: 'text'
        }
      })

      if (error) {
        console.error('发送消息错误:', error)
        throw error
      }

      console.log('消息发送成功:', data)
      
      // 添加到本地消息列表（发送者的消息立即显示）
      if (data && data.message) {
        setMessages(prev => {
          // 检查消息是否已存在，避免重复
          const exists = prev.some(msg => msg.id === data.message.id)
          if (exists) return prev
          return [...prev, data.message]
        })
      }
      
      // 更新对话列表
      loadConversations()
    } catch (error) {
      console.error('Error sending message:', error)
      setNewMessage(messageContent) // 恢复消息内容
      alert('发送消息失败，请重试')
    } finally {
      setSendingMessage(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const filteredConversations = conversations.filter(conv => {
    if (!searchTerm.trim()) return true
    const searchLower = searchTerm.toLowerCase()
    return (
      conv.otherUser.nickname.toLowerCase().includes(searchLower) ||
      conv.lastMessage?.content.toLowerCase().includes(searchLower)
    )
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin">
          <HzSymbol size={32} />
        </div>
      </div>
    )
  }

  return (
    <div className="h-screen flex">
      {/* 对话列表 */}
      <div className={`${selectedConversation ? 'hidden md:block' : 'block'} w-full md:w-80 border-r border-gray-200 flex flex-col`}>
        {/* 搜索框 */}
        <div className="p-3 md:p-4 border-b border-gray-100">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="搜索用户名或消息..."
              className="pl-10"
            />
          </div>
        </div>

        {/* 对话列表 */}
        <div className="flex-1 overflow-y-auto">
          {filteredConversations.length === 0 ? (
            <div className="p-6 md:p-8 text-center">
              <div className="text-3xl md:text-4xl mb-4">💬</div>
              <p className="text-gray-600 mb-4 text-sm md:text-base">暂无聊天记录</p>
              <p className="text-xs md:text-sm text-gray-500">去“匹配”页面找到同频的朋友吧！</p>
            </div>
          ) : (
            filteredConversations.map((conversation) => (
              <div
                key={conversation.id}
                onClick={() => setSelectedConversation(conversation)}
                className={`p-3 md:p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 active:bg-gray-100 transition-colors ${
                  selectedConversation?.id === conversation.id ? 'bg-hz-orange-50' : ''
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="relative flex-shrink-0">
                    <img
                      src={conversation.otherUser.avatar_url || '/avatars/default.jpg'}
                      alt={conversation.otherUser.nickname}
                      className="w-10 md:w-12 h-10 md:h-12 rounded-full object-cover"
                    />
                    {conversation.unreadCount > 0 && (
                      <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full min-w-[20px] h-5 px-1 flex items-center justify-center">
                        {conversation.unreadCount > 9 ? '9+' : conversation.unreadCount}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-medium text-gray-900 truncate text-sm md:text-base">
                        {conversation.otherUser.nickname}
                      </h3>
                      <span className="text-xs text-gray-500 flex-shrink-0">
                        {conversation.lastMessage ? formatTime(conversation.lastMessage.created_at) : ''}
                      </span>
                    </div>
                    
                    <p className="text-xs md:text-sm text-gray-600 truncate">
                      {conversation.lastMessage?.content || '暂无消息'}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* 聊天区域 */}
      <div className={`${selectedConversation ? 'block' : 'hidden md:block'} flex-1 flex flex-col`}>
        {selectedConversation ? (
          <>
            {/* 聊天头部 */}
            <div className="p-3 md:p-4 border-b border-gray-200 flex items-center space-x-3">
              <Button
                onClick={() => setSelectedConversation(null)}
                variant="ghost"
                size="sm"
                className="md:hidden min-w-[44px] min-h-[44px] p-2"
              >
                <ArrowLeft size={18} />
              </Button>
              
              <img
                src={selectedConversation.otherUser.avatar_url || '/avatars/default.jpg'}
                alt={selectedConversation.otherUser.nickname}
                className="w-8 md:w-10 h-8 md:h-10 rounded-full object-cover flex-shrink-0"
              />
              
              <div className="min-w-0 flex-1">
                <h3 className="font-medium text-gray-900 text-sm md:text-base truncate">
                  {selectedConversation.otherUser.nickname}
                </h3>
                <p className="text-xs md:text-sm text-gray-600 truncate">
                  {selectedConversation.otherUser.location_city} · {selectedConversation.otherUser.age}岁
                </p>
              </div>
            </div>

            {/* 消息列表 */}
            <div className="flex-1 overflow-y-auto p-3 md:p-4 space-y-3 md:space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender_id === userProfile?.id ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[280px] md:max-w-xs lg:max-w-md px-3 md:px-4 py-2 rounded-2xl ${
                      message.sender_id === userProfile?.id
                        ? 'bg-hz-orange-500 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="text-sm leading-relaxed">{message.content}</p>
                    <p className={`text-xs mt-1 ${
                      message.sender_id === userProfile?.id ? 'text-white/80' : 'text-gray-500'
                    }`}>
                      {formatTime(message.created_at)}
                    </p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* 消息输入 */}
            <div className="p-3 md:p-4 border-t border-gray-200 bg-white">
              <div className="flex space-x-2">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="输入消息..."
                  className="flex-1 h-10 md:h-10 text-sm md:text-base rounded-full border-gray-300 focus:border-hz-orange-500"
                  disabled={sendingMessage}
                />
                <Button
                  onClick={sendMessage}
                  disabled={!newMessage.trim() || sendingMessage}
                  className="px-3 md:px-4 h-10 md:h-10 min-w-[44px] rounded-full bg-hz-orange-500 hover:bg-hz-orange-600"
                >
                  {sendingMessage ? (
                    <div className="animate-spin">
                      <HzSymbol size={14} />
                    </div>
                  ) : (
                    <Send size={14} />
                  )}
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-start justify-center pt-20 md:pt-32 px-4">
            <div className="text-center">
              <div className="text-4xl md:text-6xl mb-4">💬</div>
              <h3 className="text-lg md:text-xl font-bold text-hz-warm-text-primary mb-2">选择一个对话</h3>
              <p className="text-sm md:text-base text-hz-warm-text-secondary">开始与同频的朋友聊天吧！</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}