import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { HzIcon } from '@/components/ui/hz-logo'
import { useAuth } from '@/contexts/AuthContext'
import { supabase, getUserProfile } from '@/lib/supabase'
import { HzUser } from '@/types'
import { Edit3, Users, Zap, Star, Sparkles } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { 
  AnimatedContainer, 
  CountUp, 
  HoverCard, 
  BackgroundWaves,
  FloatingParticles,
  GradientDecoration,
  ProgressRing
} from '@/components/ui/animation-system'
import { 
  WelcomeBanner,
  ActivityRecommendations,
  SocialStats,
  PersonalizedRecommendations
} from '@/components/ui/home-modules'

export function HomePage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [userProfile, setUserProfile] = useState<HzUser | null>(null)
  const [stats, setStats] = useState({ friends: 0, resonances: 0 })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadUserData()
  }, [user])

  const loadUserData = async () => {
    if (!user) {
      console.log('User not available yet')
      return
    }

    try {
      setLoading(true)
      console.log('Loading user data for HomePage:', user.email)
      
      // 获取用户资料
      const { data: profile, error } = await supabase
        .from('hz_users')
        .select('*')
        .eq('auth_user_id', user.id)
        .maybeSingle()
      
      if (error) {
        console.error('Error loading user profile:', error)
        return
      }
      
      if (profile) {
        console.log('User profile loaded for HomePage:', profile.nickname)
        setUserProfile(profile)
      } else {
        console.log('No profile found for HomePage user')
        return
      }

      // 获取统计数据
      // 同频好友数量（高匹配度的用户）
      const { data: matches } = await supabase
        .from('hz_matches')
        .select('*')
        .eq('user1_id', profile?.id)
        .gte('match_score', 80)

      // 共振次数（发送的消息数）
      const { data: messages } = await supabase
        .from('hz_messages')
        .select('*')
        .eq('sender_id', profile?.id)

      setStats({
        friends: matches?.length || 0,
        resonances: messages?.length || 0
      })
    } catch (error) {
      console.error('Error loading user data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin">
          <HzIcon size={32} />
        </div>
      </div>
    )
  }

  if (!userProfile) {
    return (
      <div className="p-8">
        <Card>
          <CardContent className="text-center py-16">
            <p className="text-gray-600 mb-4">用户资料加载失败</p>
            <Button onClick={() => navigate('/profile-setup')} variant="warm">
              完善资料
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="relative min-h-screen">
      {/* 背景装饰系统 */}
      <BackgroundWaves />
      <FloatingParticles />
      <GradientDecoration />
      
      <div className="relative z-10 p-4 md:p-6 max-w-6xl mx-auto">
        {/* 欢迎横幅 */}
        <WelcomeBanner 
          userName={userProfile.nickname} 
          userAvatar={userProfile.avatar_url}
        />

        {/* 主要内容网格 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-8">
          {/* 左侧列 */}
          <div className="lg:col-span-2 space-y-4 md:space-y-8">
            {/* 用户资料卡片 - 移动端优化 */}
            <AnimatedContainer type="slideUp" className="mb-4 md:mb-8">
              <HoverCard>
                <Card className="border-hz-orange-200 bg-gradient-to-br from-white to-hz-orange-50/50 backdrop-blur-sm">
                  <CardContent className="p-4 md:p-8">
                    <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
                      {/* 头像 */}
                      <div className="relative flex-shrink-0">
                        <div className="w-20 md:w-24 h-20 md:h-24 rounded-full bg-gradient-to-br from-hz-orange-200 to-hz-orange-400 p-1">
                          <img
                            src={userProfile.avatar_url || '/avatars/default.jpg'}
                            alt={userProfile.nickname}
                            className="w-full h-full rounded-full object-cover"
                          />
                        </div>
                        <div className="absolute -bottom-2 -right-2">
                          <div className="bg-white rounded-full p-1 shadow-lg">
                            <HzIcon size={20} animated={true} />
                          </div>
                        </div>
                      </div>
                      
                      {/* 用户信息 */}
                      <div className="flex-1 text-center md:text-left">
                        <div className="flex flex-col md:flex-row md:items-center space-y-2 md:space-y-0 md:space-x-3 mb-3">
                          <h2 className="text-xl md:text-3xl font-bold text-gray-900">
                            {userProfile.nickname}
                          </h2>
                          <span className="text-base md:text-lg text-gray-600">{userProfile.age}岁</span>
                          <span className="px-3 py-1 bg-hz-orange-100 text-hz-orange-700 rounded-full text-sm font-medium self-center md:self-auto">
                            {userProfile.location_city}
                          </span>
                        </div>
                        
                        {/* 角色 */}
                        <p className="text-hz-orange-600 text-base md:text-lg font-medium mb-3">{userProfile.role}</p>
                        
                        {/* 核心标签 */}
                        <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                          {userProfile.interest_tags && userProfile.interest_tags.slice(0, 3).map((tag, index) => (
                            <span
                              key={index}
                              className="px-2 md:px-3 py-1 bg-white/80 text-gray-700 rounded-lg text-xs md:text-sm border border-gray-200 backdrop-blur-sm"
                            >
                              {tag}
                            </span>
                          ))}
                          {userProfile.interest_tags && userProfile.interest_tags.length > 3 && (
                            <span className="px-2 md:px-3 py-1 bg-gray-100 text-gray-500 rounded-lg text-xs md:text-sm">
                              +{userProfile.interest_tags.length - 3}
                            </span>
                          )}
                        </div>
                      </div>
                      
                      {/* 编辑按钮 */}
                      <Button
                        onClick={() => navigate('/profile-setup')}
                        className="bg-hz-orange-500 hover:bg-hz-orange-600 text-white shadow-lg hover:shadow-xl transition-all duration-200 w-full md:w-auto mt-4 md:mt-0"
                      >
                        <Edit3 size={14} className="mr-2" />
                        <span className="text-sm md:text-base">编辑资料</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </HoverCard>
            </AnimatedContainer>

            {/* 数据统计 - 移动端优化 */}
            <AnimatedContainer delay={100} type="slideUp">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <HoverCard>
                  <Card className="border-hz-orange-200 bg-gradient-to-br from-white to-blue-50/50 backdrop-blur-sm">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                        <div className="text-center md:text-left">
                          <div className="flex items-center space-x-3 mb-3 justify-center md:justify-start">
                            <div className="p-2 bg-blue-100 rounded-lg">
                              <Users className="text-blue-600" size={20} />
                            </div>
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">同频好友</h3>
                          </div>
                          <div className="text-2xl md:text-3xl font-bold text-blue-600 mb-1">
                            <CountUp end={stats.friends} delay={300} />
                          </div>
                          <p className="text-gray-600 text-xs md:text-sm">高匹配度的朋友</p>
                        </div>
                        <div className="flex justify-center md:justify-end">
                          <ProgressRing percentage={(stats.friends / 50) * 100} size={60}>
                            <div className="text-xs font-bold text-blue-600">
                              {Math.round((stats.friends / 50) * 100)}%
                            </div>
                          </ProgressRing>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </HoverCard>
                
                <HoverCard>
                  <Card className="border-hz-orange-200 bg-gradient-to-br from-white to-purple-50/50 backdrop-blur-sm">
                    <CardContent className="p-4 md:p-6">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                        <div className="text-center md:text-left">
                          <div className="flex items-center space-x-3 mb-3 justify-center md:justify-start">
                            <div className="p-2 bg-purple-100 rounded-lg">
                              <Zap className="text-purple-600" size={20} />
                            </div>
                            <h3 className="text-base md:text-lg font-semibold text-gray-900">共振次数</h3>
                          </div>
                          <div className="text-2xl md:text-3xl font-bold text-purple-600 mb-1">
                            <CountUp end={stats.resonances} delay={500} />
                          </div>
                          <p className="text-gray-600 text-xs md:text-sm">与朋友的交流次数</p>
                        </div>
                        <div className="flex justify-center md:justify-end">
                          <ProgressRing percentage={(stats.resonances / 100) * 100} size={60}>
                            <div className="text-xs font-bold text-purple-600">
                              {Math.round((stats.resonances / 100) * 100)}%
                            </div>
                          </ProgressRing>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </HoverCard>
              </div>
            </AnimatedContainer>

            {/* 活动推荐 */}
            <ActivityRecommendations />

            {/* 社交动态 */}
            <SocialStats />
          </div>

          {/* 右侧列 */}
          <div className="space-y-8">
            {/* 个性化推荐 */}
            <PersonalizedRecommendations />

            {/* 关于我 - 增强版 */}
            {userProfile.about_me && (
              <AnimatedContainer delay={800} type="slideRight">
                <HoverCard>
                  <Card className="border-hz-orange-200 bg-gradient-to-br from-white to-green-50/30">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Star className="text-yellow-500" size={20} />
                        <span>关于我</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                        {userProfile.about_me}
                      </p>
                    </CardContent>
                  </Card>
                </HoverCard>
              </AnimatedContainer>
            )}

            {/* 兴趣爱好 - 增强版 */}
            {userProfile.interest_tags && userProfile.interest_tags.length > 0 && (
              <AnimatedContainer delay={1000} type="slideRight">
                <HoverCard>
                  <Card className="border-hz-orange-200 bg-gradient-to-br from-white to-pink-50/30">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Sparkles className="text-pink-500" size={20} />
                        <span>兴趣爱好</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {userProfile.interest_tags.map((tag, index) => (
                          <span
                            key={index}
                            className="px-3 py-2 bg-gradient-to-r from-hz-orange-100 to-pink-100 text-hz-orange-700 rounded-full text-sm border border-hz-orange-200 hover:from-hz-orange-200 hover:to-pink-200 transition-all duration-200 cursor-default"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </HoverCard>
              </AnimatedContainer>
            )}

            {/* 专业领域 - 增强版 */}
            {userProfile.professional_fields && userProfile.professional_fields.length > 0 && (
              <AnimatedContainer delay={1200} type="slideRight">
                <HoverCard>
                  <Card className="border-hz-orange-200 bg-gradient-to-br from-white to-indigo-50/30">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Zap className="text-indigo-500" size={20} />
                        <span>专业领域</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {userProfile.professional_fields.map((field, index) => (
                          <span
                            key={index}
                            className="px-3 py-2 bg-gradient-to-r from-indigo-100 to-blue-100 text-indigo-700 rounded-full text-sm border border-indigo-200 hover:from-indigo-200 hover:to-blue-200 transition-all duration-200 cursor-default"
                          >
                            {field}
                          </span>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </HoverCard>
              </AnimatedContainer>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}