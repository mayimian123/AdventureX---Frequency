import React, { useState, useEffect, useCallback, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { HzSymbol } from '@/components/ui/wave-animation'
import { useAuth } from '@/contexts/AuthContext'
import { supabase, getUserProfile } from '@/lib/supabase'
import { CoffeeChatActivity, HzUser } from '@/types'
import { getMatchScoreColor } from '@/lib/utils'
import { Search, MapPin, Calendar, Users, Clock, Target, Navigation, AlertTriangle } from 'lucide-react'
import { formatDateTime } from '@/lib/utils'
import { DistanceFilter } from '@/components/ui/distance-filter'

// 🚨 **全页面错误边界组件**
function CoffeeChatErrorBoundary({ children }: { children: React.ReactNode }) {
  const [hasError, setHasError] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      console.error('🚨 Coffee Chat页面全局错误:', event.error)
      setHasError(true)
      setErrorMessage(event.error?.message || '未知错误')
    }

    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      console.error('🚨 Coffee Chat页面Promise拒绝:', event.reason)
      setHasError(true)
      setErrorMessage('网络请求或数据处理错误')
    }

    window.addEventListener('error', handleError)
    window.addEventListener('unhandledrejection', handleUnhandledRejection)

    return () => {
      window.removeEventListener('error', handleError)
      window.removeEventListener('unhandledrejection', handleUnhandledRejection)
    }
  }, [])

  if (hasError) {
    return (
      <div className="flex items-center justify-center min-h-screen p-8">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">
              Coffee Chat页面出现问题
            </h2>
            <p className="text-gray-600 mb-4">
              位置功能或页面加载出现错误，请尝试以下解决方案：
            </p>
            <div className="space-y-2 text-left text-sm text-gray-700 mb-6">
              <p>• 刷新页面重试</p>
              <p>• 检查浏览器位置权限设置</p>
              <p>• 确保网站使用HTTPS访问</p>
              <p>• 清理浏览器缓存</p>
            </div>
            <div className="space-y-3">
              <Button 
                onClick={() => window.location.reload()}
                className="w-full bg-hz-orange-500 hover:bg-hz-orange-600"
              >
                刷新页面
              </Button>
              <Button 
                variant="outline"
                onClick={() => setHasError(false)}
                className="w-full"
              >
                重试加载
              </Button>
            </div>
            {errorMessage && (
              <div className="mt-4 p-3 bg-gray-50 rounded text-xs text-gray-500">
                错误信息: {errorMessage}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  return <>{children}</>
}

function CoffeeChatJoinPageInner() {
  const { user } = useAuth()
  const [userProfile, setUserProfile] = useState<HzUser | null>(null)
  const [activities, setActivities] = useState<CoffeeChatActivity[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredActivities, setFilteredActivities] = useState<CoffeeChatActivity[]>([])
  const [joinLoading, setJoinLoading] = useState<string | null>(null)
  const [showJoinModal, setShowJoinModal] = useState(false)
  const [selectedActivity, setSelectedActivity] = useState<CoffeeChatActivity | null>(null)
  const [joinForm, setJoinForm] = useState({
    whatToBring: '',
    whatToGet: ''
  })
  
  // 距离筛选相关状态
  const [userLocation, setUserLocation] = useState<{latitude: number, longitude: number, address?: string, city?: string} | null>(null)
  const [maxDistance, setMaxDistance] = useState<number | null>(null)
  const [activitiesWithDistance, setActivitiesWithDistance] = useState<(CoffeeChatActivity & {distance_km?: number, distance_display?: string})[]>([])

  useEffect(() => {
    loadUserProfile()
  }, [user])

  const loadUserProfile = async () => {
    if (!user) {
      console.log('User not available yet')
      return
    }

    try {
      console.log('Loading user profile for Coffee Chat:', user.email)
      
      // 直接从数据库查询用户资料
      const { data: profile, error } = await supabase
        .from('hz_users')
        .select('*')
        .eq('auth_user_id', user.id)
        .maybeSingle()
      
      if (error) {
        console.error('Error loading user profile:', error)
        return
      }
      
      if (profile) {
        console.log('User profile loaded for Coffee Chat:', profile.nickname)
        setUserProfile(profile)
      } else {
        console.log('No profile found for Coffee Chat user')
      }
    } catch (error) {
      console.error('Error loading user profile:', error)
    }
  }

  const loadActivities = useCallback(async () => {
    try {
      setLoading(true)
      console.log('加载Coffee Chat活动列表...', { userLocation, maxDistance })
      
      // 如果有用户位置，使用距离筛选功能
      if (userLocation) {
        console.log('使用距离筛选加载活动')
        await loadActivitiesWithDistance()
      } else {
        console.log('使用普通方式加载活动')
        // 获取所有recruiting状态的活动，不过滤时间
        const { data, error } = await supabase
          .from('hz_coffee_chat_activities')
          .select('*')
          .eq('status', 'recruiting')
          .order('start_datetime', { ascending: true })

        console.log('活动列表查询结果:', { data, error })
        
        if (error) {
          console.error('加载活动列表失败:', error)
          throw error
        }
        
        // 显示所有recruiting状态的活动，不进行时间过滤
        // 让用户可以看到所有正在招募的活动
        setActivities(data || [])
        setActivitiesWithDistance(data || [])
        console.log('成功加载', (data || []).length, '个recruiting活动')
      }
    } catch (error) {
      console.error('Error loading activities:', error)
      setActivities([])
      setActivitiesWithDistance([])
    } finally {
      setLoading(false)
    }
  }, [userLocation, maxDistance])

  // 加载带距离信息的活动列表
  const loadActivitiesWithDistance = useCallback(async () => {
    if (!userLocation) return

    try {
      console.log('调用Location服务获取带距离的活动')
      
      // 首先尝试从Supabase获取基础活动数据
      const { data, error } = await supabase
        .from('hz_coffee_chat_activities')
        .select('*')
        .eq('status', 'recruiting')
        .order('start_datetime', { ascending: true })

      if (error) {
        throw error
      }

      if (!data || data.length === 0) {
        setActivities([])
        setActivitiesWithDistance([])
        return
      }

      // 计算距离（前端计算），增加错误处理
      const activitiesWithCalcDistance = data.map(activity => {
        try {
          if (activity.latitude && activity.longitude && userLocation) {
            const lat = parseFloat(activity.latitude)
            const lng = parseFloat(activity.longitude)
            
            // 验证坐标有效性
            if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
              console.warn('无效的活动坐标:', { lat, lng, activity: activity.title })
              return activity
            }
            
            const distance = calculateDistance(
              userLocation.latitude, 
              userLocation.longitude,
              lat,
              lng
            )
            
            // 验证距离计算结果
            if (isNaN(distance) || distance < 0) {
              console.warn('距离计算结果无效:', distance)
              return activity
            }
            
            return {
              ...activity,
              distance_km: distance,
              distance_display: formatDistance(distance)
            }
          }
          return activity
        } catch (error) {
          console.error('计算活动距离时出错:', error, '活动:', activity.title)
          return activity
        }
      })

      // 按距离筛选
      let filteredActivities = activitiesWithCalcDistance
      if (maxDistance !== null) {
        filteredActivities = activitiesWithCalcDistance.filter(activity => 
          !activity.distance_km || activity.distance_km <= maxDistance
        )
      }

      // 按距离排序
      filteredActivities.sort((a, b) => (a.distance_km || 999) - (b.distance_km || 999))

      setActivities(filteredActivities)
      setActivitiesWithDistance(filteredActivities)
      console.log('成功加载', filteredActivities.length, '个带距离的活动')

    } catch (error) {
      console.error('加载带距离活动失败:', error)
      
      // 回退到普通模式
      const { data, error: dbError } = await supabase
        .from('hz_coffee_chat_activities')
        .select('*')
        .eq('status', 'recruiting')
        .order('start_datetime', { ascending: true })

      if (!dbError && data) {
        setActivities(data)
        setActivitiesWithDistance(data)
      }
    }
  }, [userLocation, maxDistance])

  // 计算距离（Haversine公式）- 增强错误处理
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    try {
      // 验证输入参数
      if (isNaN(lat1) || isNaN(lng1) || isNaN(lat2) || isNaN(lng2)) {
        console.warn('距离计算参数包含NaN:', { lat1, lng1, lat2, lng2 })
        return 999 // 返回一个大数，表示距离很远
      }
      
      // 验证坐标范围
      if (lat1 < -90 || lat1 > 90 || lat2 < -90 || lat2 > 90 ||
          lng1 < -180 || lng1 > 180 || lng2 < -180 || lng2 > 180) {
        console.warn('距离计算参数超出有效范围:', { lat1, lng1, lat2, lng2 })
        return 999
      }
      
      const R = 6371 // 地球半径（公里）
      const dLat = (lat2 - lat1) * Math.PI / 180
      const dLng = (lng2 - lng1) * Math.PI / 180
      const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLng/2) * Math.sin(dLng/2)
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
      const distance = R * c
      
      // 验证计算结果
      if (isNaN(distance) || distance < 0) {
        console.warn('距离计算结果无效:', distance)
        return 999
      }
      
      return distance
    } catch (error) {
      console.error('距离计算出错:', error)
      return 999
    }
  }

  // 格式化距离显示 - 增强错误处理
  const formatDistance = (distanceKm: number): string => {
    try {
      if (isNaN(distanceKm) || distanceKm < 0) {
        return '距离未知'
      }
      
      if (distanceKm >= 999) {
        return '很远'
      }
      
      if (distanceKm < 1) {
        const meters = Math.round(distanceKm * 1000)
        return `${meters}米`
      } else if (distanceKm < 10) {
        return `${distanceKm.toFixed(1)}公里`
      } else {
        return `${Math.round(distanceKm)}公里`
      }
    } catch (error) {
      console.error('格式化距离出错:', error)
      return '距离未知'
    }
  }

  // 处理距离筛选变化
  const handleDistanceFilterChange = useCallback((distance: number | null) => {
    console.log('距离筛选变化:', distance)
    setMaxDistance(distance)
  }, [])

  // 处理用户位置变化
  const handleUserLocationChange = useCallback((location: {latitude: number, longitude: number, address?: string, city?: string} | null) => {
    console.log('用户位置变化:', location)
    setUserLocation(location)
  }, [])

  const filterActivities = useCallback(() => {
    if (!searchTerm.trim()) {
      setFilteredActivities(activities)
      return
    }

    const filtered = activities.filter(activity => {
      const searchLower = searchTerm.toLowerCase()
      return (
        activity.title.toLowerCase().includes(searchLower) ||
        activity.description?.toLowerCase().includes(searchLower) ||
        activity.location_city?.toLowerCase().includes(searchLower) ||
        activity.target_tags.some(tag => tag.toLowerCase().includes(searchLower))
      )
    })
    
    setFilteredActivities(filtered)
  }, [activities, searchTerm])

  const calculateMatchScore = (activity: CoffeeChatActivity) => {
    if (!userProfile) return 0

    let score = 0
    const totalFactors = 4

    // 兴趣标签匹配 (40%)
    const commonTags = userProfile.interest_tags.filter(tag => 
      activity.target_tags.includes(tag)
    )
    const tagScore = activity.target_tags.length > 0 
      ? (commonTags.length / activity.target_tags.length) * 40 
      : 0

    // 地理位置 (30%)
    const locationScore = userProfile.location_city === activity.location_city ? 30 : 0

    // 专业领域关联 (20%)
    const fieldScore = userProfile.professional_fields.some(field => 
      activity.target_tags.includes(field)
    ) ? 20 : 0

    // 活动时间合理性 (10%)
    const activityDate = new Date(activity.start_datetime)
    const now = new Date()
    const timeDiff = (activityDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
    const timeScore = timeDiff >= 1 && timeDiff <= 7 ? 10 : 5

    score = Math.round(tagScore + locationScore + fieldScore + timeScore)
    return Math.min(100, Math.max(0, score))
  }

  const openJoinModal = (activity: CoffeeChatActivity) => {
    setSelectedActivity(activity)
    setShowJoinModal(true)
    setJoinForm({ whatToBring: '', whatToGet: '' })
  }

  const closeJoinModal = () => {
    setShowJoinModal(false)
    setSelectedActivity(null)
    setJoinForm({ whatToBring: '', whatToGet: '' })
  }

  const joinActivity = async () => {
    if (!userProfile || !selectedActivity) return

    // 验证问卷填写
    if (!joinForm.whatToBring.trim() || !joinForm.whatToGet.trim()) {
      alert('请完整填写申请问卷')
      return
    }

    setJoinLoading(selectedActivity.id)

    try {
      console.log('尝试加入活动:', selectedActivity.id, '用户ID:', userProfile.id)
      console.log('申请问卷:', joinForm)
      
      const { data, error } = await supabase.functions.invoke('hz-coffee-chat-management', {
        body: {
          action: 'join_activity',
          activityId: selectedActivity.id,
          userId: userProfile.id,
          whatToBring: joinForm.whatToBring.trim(),
          whatToGet: joinForm.whatToGet.trim()
        }
      })
      
      console.log('加入活动响应:', { data, error })

      if (error) {
        console.error('加入活动错误:', error)
        if (error.message && error.message.includes('Already joined')) {
          alert('你已经加入过这个活动了')
        } else {
          throw error
        }
      } else {
        alert('申请已提交，等待组织者审核！')
        closeJoinModal()
        await loadActivities() // 重新加载活动列表
      }
    } catch (error) {
      console.error('Error joining activity:', error)
      alert('加入活动失败，请重试')
    } finally {
      setJoinLoading(null)
    }
  }

  // 🔧 **修复关键点：防止useEffect循环依赖导致的崩溃**
  // 使用 useRef 来追踪加载状态，避免依赖循环
  const loadingRef = useRef(false)
  const lastLocationRef = useRef<string | null>(null)
  const lastDistanceRef = useRef<number | null>(null)

  // 安全的活动加载函数 - 防止重复调用
  const safeLoadActivities = useCallback(async () => {
    if (loadingRef.current) {
      console.log('⚠️ 活动加载中，跳过重复请求')
      return
    }

    try {
      loadingRef.current = true
      await loadActivities()
    } catch (error) {
      console.error('❌ 安全加载活动失败:', error)
    } finally {
      loadingRef.current = false
    }
  }, [loadActivities])

  // 初始加载活动（仅一次）
  useEffect(() => {
    console.log('🎯 组件初始化，开始首次加载活动')
    safeLoadActivities()
  }, []) // 移除依赖，避免循环

  // 搜索和过滤 - 简化依赖
  useEffect(() => {
    try {
      filterActivities()
    } catch (error) {
      console.error('❌ 过滤活动时出错:', error)
    }
  }, [activities, searchTerm]) // 只依赖实际的数据

  // 🚨 **关键修复：位置变化时的安全处理**
  useEffect(() => {
    try {
      const locationKey = userLocation ? `${userLocation.latitude},${userLocation.longitude}` : null
      
      // 只有位置真正改变时才重新加载
      if (locationKey !== lastLocationRef.current) {
        console.log('📍 位置发生实际变化:', { 
          old: lastLocationRef.current, 
          new: locationKey 
        })
        
        lastLocationRef.current = locationKey
        
        // 延迟加载，避免快速连续调用
        setTimeout(() => {
          if (!loadingRef.current) {
            safeLoadActivities()
          }
        }, 100)
      }
    } catch (error) {
      console.error('❌ 处理位置变化时出错:', error)
    }
  }, [userLocation]) // 仅依赖位置数据

  // 🚨 **关键修复：距离筛选变化时的安全处理**  
  useEffect(() => {
    try {
      // 只有距离真正改变且有位置时才重新加载
      if (maxDistance !== lastDistanceRef.current && userLocation) {
        console.log('📐 距离筛选发生实际变化:', { 
          old: lastDistanceRef.current, 
          new: maxDistance 
        })
        
        lastDistanceRef.current = maxDistance
        
        // 延迟加载，避免快速连续调用
        setTimeout(() => {
          if (!loadingRef.current) {
            safeLoadActivities()
          }
        }, 100)
      }
    } catch (error) {
      console.error('❌ 处理距离筛选变化时出错:', error)
    }
  }, [maxDistance]) // 仅依赖距离数据

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin">
          <HzSymbol size={32} />
        </div>
      </div>
    )
  }

  // 🔧 **渲染错误保护**
  try {
    return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      {/* 标题和搜索 */}
      <div className="mb-6 md:mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 md:mb-6 space-y-4 md:space-y-0">
          <div className="text-center md:text-left">
            <h1 className="text-xl md:text-3xl font-bold text-gray-900 mb-2">
              Coffee Chat 活动
            </h1>
            <p className="text-sm md:text-base text-gray-600">加入心仪的活动，与同频的朋友面对面交流</p>
          </div>
          <HzSymbol size={32} className="self-center md:self-auto" />
        </div>
        
        {/* 距离筛选器 */}
        <div className="mb-6">
          <DistanceFilter
            onDistanceFilterChange={handleDistanceFilterChange}
            onUserLocationChange={handleUserLocationChange}
          />
        </div>
        
        {/* 搜索框 */}
        <div className="relative max-w-full md:max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <Input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="搜索活动主题、地点或标签..."
            className="pl-10 h-10 md:h-10 text-sm md:text-base"
          />
        </div>
      </div>

      {/* 活动列表 */}
      {filteredActivities.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12 md:py-16">
            <div className="text-4xl md:text-6xl mb-4">☕</div>
            <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-2">暂无活动</h3>
            <p className="text-sm md:text-base text-gray-600 mb-6">
              {searchTerm ? '没有找到匹配的活动' : '暂时没有活动，去创建一个吧！'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4 md:space-y-6">
          {filteredActivities.map((activity) => {
            const matchScore = calculateMatchScore(activity)
            const isHighMatch = matchScore >= 80
            
            return (
              <Card 
                key={activity.id}
                className={`transition-all duration-200 hover:shadow-lg ${
                  isHighMatch ? 'border-hz-orange-200 bg-hz-orange-50' : ''
                }`}
              >
                <CardHeader className="p-4 md:p-6">
                  <div className="flex flex-col md:flex-row md:items-start justify-between space-y-2 md:space-y-0">
                    <div className="flex-1">
                      <div className="flex flex-col md:flex-row md:items-center space-y-2 md:space-y-0 md:space-x-3 mb-2">
                        <CardTitle className="text-lg md:text-xl">{activity.title}</CardTitle>
                        {isHighMatch && (
                          <span className="px-2 py-1 bg-hz-orange-100 text-hz-orange-600 rounded-full text-xs font-medium self-start">
                            高匹配
                          </span>
                        )}
                      </div>
                      
                      <div className="flex flex-col md:flex-row md:items-center space-y-2 md:space-y-0 md:space-x-4 text-xs md:text-sm text-gray-600 mb-3">
                        <div className="flex items-center space-x-1">
                          <Calendar size={12} />
                          <span>{formatDateTime(activity.start_datetime)}</span>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <MapPin size={12} />
                          <span>{activity.location_city}</span>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <Users size={12} />
                          <span>{activity.current_participants}/{activity.max_participants}人</span>
                        </div>
                      </div>
                      
                      {activity.description && (
                        <p className="text-sm md:text-base text-gray-700 mb-3 line-clamp-2">{activity.description}</p>
                      )}
                    </div>
                    
                    <div className={`px-3 py-1 rounded-full text-sm font-bold self-end md:self-start ${
                      getMatchScoreColor(matchScore)
                    }`}>
                      {matchScore}Hz
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="p-4 md:p-6 pt-0 space-y-3 md:space-y-4">
                  {/* 目标 */}
                  {activity.goal && (
                    <div className="flex items-start space-x-2">
                      <Target className="text-gray-400 mt-1 flex-shrink-0" size={14} />
                      <div className="min-w-0">
                        <p className="text-xs md:text-sm font-medium text-gray-700 mb-1">活动目标:</p>
                        <p className="text-xs md:text-sm text-gray-600">{activity.goal}</p>
                      </div>
                    </div>
                  )}
                  
                  {/* 目标标签 */}
                  {activity.target_tags.length > 0 && (
                    <div>
                      <p className="text-xs md:text-sm font-medium text-gray-700 mb-2">目标群体:</p>
                      <div className="flex flex-wrap gap-1.5 md:gap-2">
                        {activity.target_tags.map((tag, index) => {
                          const isUserTag = userProfile?.interest_tags.includes(tag) || 
                                           userProfile?.professional_fields.includes(tag)
                          return (
                            <span
                              key={index}
                              className={`px-2 py-1 rounded-md text-xs ${
                                isUserTag 
                                  ? 'bg-hz-orange-100 text-hz-orange-600 font-medium'
                                  : 'bg-gray-100 text-gray-600'
                              }`}
                            >
                              {tag}
                            </span>
                          )
                        })}
                      </div>
                    </div>
                  )}
                  
                  {/* 地址信息 */}
                  <div className="flex items-start space-x-2">
                    <MapPin className="text-gray-400 mt-1 flex-shrink-0" size={14} />
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-col md:flex-row md:items-center justify-between mb-1 space-y-2 md:space-y-0">
                        <p className="text-xs md:text-sm font-medium text-gray-700">详细地址:</p>
                        {activity.distance_display && userLocation && (
                          <div className="flex items-center space-x-1 text-xs text-hz-orange-600 bg-hz-orange-50 px-2 py-1 rounded-full self-start">
                            <Navigation className="w-3 h-3 flex-shrink-0" />
                            <span className="font-medium">距您 {activity.distance_display}</span>
                          </div>
                        )}
                      </div>
                      <p className="text-xs md:text-sm text-gray-600">
                        {activity.location_name && (
                          <span className="font-medium text-gray-700">{activity.location_name}</span>
                        )}
                        {activity.location_name && activity.location_address && <br />}
                        {activity.location_address}
                        {activity.location_detailed_address && (
                          <><br />补充信息：{activity.location_detailed_address}</>
                        )}
                      </p>
                    </div>
                  </div>
                  
                  {/* 操作按钮 */}
                  <div className="flex flex-col md:flex-row md:items-center justify-between pt-3 md:pt-4 border-t border-gray-100 space-y-3 md:space-y-0">
                    <div className="text-xs md:text-sm text-gray-600">
                      进度: {activity.current_participants}/{activity.max_participants} 人
                      {activity.current_participants >= activity.max_participants && (
                        <span className="ml-2 text-orange-600">已满</span>
                      )}
                    </div>
                    
                    <Button
                      onClick={() => openJoinModal(activity)}
                      disabled={activity.current_participants >= activity.max_participants || 
                               activity.organizer_id === userProfile?.id}
                      variant="warm"
                      size="sm"
                      className="min-w-20"
                    >
                      {activity.organizer_id === userProfile?.id ? (
                        '你的活动'
                      ) : activity.current_participants >= activity.max_participants ? (
                        '已满'
                      ) : (
                        '申请加入'
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
      
      {/* 申请加入问卷弹窗 */}
      {showJoinModal && selectedActivity && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              申请加入「{selectedActivity.title}」
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  你能带来什么？ *
                </label>
                <textarea
                  value={joinForm.whatToBring}
                  onChange={(e) => setJoinForm(prev => ({ ...prev, whatToBring: e.target.value }))}
                  placeholder="分享你的技能、经验或资源..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-hz-orange-500 resize-none"
                  rows={3}
                  maxLength={150}
                />
                <div className="text-right text-xs text-gray-500 mt-1">
                  {joinForm.whatToBring.length}/150
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  你希望获得什么？ *
                </label>
                <textarea
                  value={joinForm.whatToGet}
                  onChange={(e) => setJoinForm(prev => ({ ...prev, whatToGet: e.target.value }))}
                  placeholder="你想在这个活动中获得什么？"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-hz-orange-500 resize-none"
                  rows={3}
                  maxLength={150}
                />
                <div className="text-right text-xs text-gray-500 mt-1">
                  {joinForm.whatToGet.length}/150
                </div>
              </div>
            </div>
            
            <div className="flex space-x-3 mt-6">
              <Button
                onClick={joinActivity}
                disabled={!joinForm.whatToBring.trim() || !joinForm.whatToGet.trim() || joinLoading === selectedActivity.id}
                variant="warm"
                className="flex-1"
              >
                {joinLoading === selectedActivity.id ? (
                  <div className="flex items-center space-x-2">
                    <div className="animate-spin">
                      <HzSymbol size={16} />
                    </div>
                    <span>提交中...</span>
                  </div>
                ) : (
                  '提交申请'
                )}
              </Button>
              
              <Button
                onClick={closeJoinModal}
                disabled={joinLoading === selectedActivity.id}
                variant="outline"
                className="flex-1"
              >
                取消
              </Button>
            </div>
          </div>
        </div>
      )}
      </div>
    )
  } catch (error) {
    console.error('❌ CoffeeChatJoinPage渲染错误:', error)
    
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <Card>
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <h2 className="text-lg font-bold text-gray-900 mb-2">
              页面渲染错误
            </h2>
            <p className="text-gray-600 mb-4">
              Coffee Chat页面出现问题，请刷新重试
            </p>
            <Button 
              onClick={() => window.location.reload()}
              className="bg-hz-orange-500 hover:bg-hz-orange-600"
            >
              刷新页面
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }
}

// 🚨 **主导出组件：使用错误边界包装**
export function CoffeeChatJoinPage() {
  return (
    <CoffeeChatErrorBoundary>
      <CoffeeChatJoinPageInner />
    </CoffeeChatErrorBoundary>
  )
}