import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { HzSymbol } from '@/components/ui/wave-animation'
import { ActivityDetailModal } from '@/components/ui/activity-detail-modal'
import { ApplicantDetailModal } from '@/components/ui/applicant-detail-modal'
import { VipStatusDisplay } from '@/components/ui/vip-status-display'
import { useAuth } from '@/contexts/AuthContext'
import { supabase, getUserProfile } from '@/lib/supabase'
import { CoffeeChatActivity, HzUser, ActivityParticipant } from '@/types'
import { formatDateTime } from '@/lib/utils'
import { Plus, Calendar, MapPin, Users, Clock, Check, X, Edit, Eye, Trash2 } from 'lucide-react'
import { LocationPicker, SelectedLocation } from '@/components/ui/location-picker'
import toast from 'react-hot-toast'

interface ActivityWithParticipants extends CoffeeChatActivity {
  participants: (ActivityParticipant & { user: HzUser })[]
}

// 从地址中提取城市信息的辅助函数
function extractCityFromAddress(address: string): string {
  // 简单的城市提取逻辑，匹配常见的城市名称
  const cityPatterns = [
    /([^省]+省)([^市]+市)/,
    /([^市]+市)/,
    /北京|上海|天津|重庆/
  ]
  
  for (const pattern of cityPatterns) {
    const match = address.match(pattern)
    if (match) {
      if (match[2]) return match[2] // 省+市的情况
      return match[1] // 直辖市或单独市的情况
    }
  }
  
  // 如果没有匹配到，返回默认值
  return address.split(/[区县]/)[0] || '未知城市'
}

export function CoffeeChatMyPage() {
  const { user } = useAuth()
  const [userProfile, setUserProfile] = useState<HzUser | null>(null)
  const [organizedActivities, setOrganizedActivities] = useState<ActivityWithParticipants[]>([])
  const [participatedActivities, setParticipatedActivities] = useState<ActivityWithParticipants[]>([])
  const [activeTab, setActiveTab] = useState<'participated' | 'organized'>('participated')
  const [loading, setLoading] = useState(true)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [selectedActivity, setSelectedActivity] = useState<ActivityWithParticipants | null>(null)
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false)
  const [selectedApplicant, setSelectedApplicant] = useState<(ActivityParticipant & { user: HzUser }) | null>(null)
  const [isApplicantModalOpen, setIsApplicantModalOpen] = useState(false)
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [activityToDelete, setActivityToDelete] = useState<ActivityWithParticipants | null>(null)
  const [deleteLoading, setDeleteLoading] = useState(false)


  // 创建活动表单数据
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    startDate: '',
    startTime: '',
    endDate: '',
    endTime: '',
    country: '国内',
    province: '',
    city: '',
    address: '',
    detailedAddress: '',
    maxParticipants: 4,
    goal: '',
    targetTags: ''
  })

  // 选中的地点信息
  const [selectedLocation, setSelectedLocation] = useState<SelectedLocation | null>(null)

  useEffect(() => {
    loadUserProfile()
  }, [user])

  useEffect(() => {
    if (userProfile) {
      loadMyActivities()
    }
  }, [userProfile])

  const loadUserProfile = async () => {
    if (!user) {
      console.log('User not available yet')
      return
    }

    try {
      console.log('Loading user profile for My Coffee Chat:', user.email)
      
      // 直接从数据库查询用户资料
      const { data: profile, error } = await supabase
        .from('hz_users')
        .select('*')
        .eq('auth_user_id', user.id)
        .maybeSingle()
      
      if (error) {
        console.error('Error loading user profile:', error)
        return
      }
      
      if (profile) {
        console.log('User profile loaded for My Coffee Chat:', profile.nickname)
        setUserProfile(profile)
      } else {
        console.log('No profile found for My Coffee Chat user')
      }
    } catch (error) {
      console.error('Error loading user profile:', error)
    }
  }

  const loadMyActivities = async () => {
    if (!userProfile) {
      console.log('User profile not available for loading activities')
      return
    }

    try {
      setLoading(true)
      console.log('加载我的活动，用户ID:', userProfile.id)
      console.log('用户完整信息:', userProfile)
      
      const { data, error } = await supabase.functions.invoke('hz-coffee-chat-management', {
        body: {
          action: 'get_my_activities',
          userId: userProfile.id
        }
      })
      
      console.log('我的活动响应:', { data, error })
      console.log('原始响应数据:', JSON.stringify(data, null, 2))

      if (error) {
        console.error('加载我的活动失败:', error)
        alert('加载活动失败：' + error.message)
        return
      }

      // 直接使用data而不是data.data
      const responseData = data.data || data

      console.log('处理我的活动数据:', responseData)
      console.log('组织的活动数量:', responseData.organized?.length || 0)
      console.log('参与的活动数量:', responseData.participated?.length || 0)

      // 加载参与者信息
      const organizedWithParticipants = await Promise.all(
        (responseData.organized || []).map(async (activity: CoffeeChatActivity) => {
          console.log('加载组织活动参与者:', activity.id, activity.title)
          const participants = await loadActivityParticipants(activity.id)
          return { ...activity, participants }
        })
      )

      const participatedWithParticipants = await Promise.all(
        (responseData.participated || []).map(async (participant: ActivityParticipant) => {
          console.log('加载参与活动详情:', participant.activity_id)
          // 获取活动详情
          const { data: activityData, error: activityError } = await supabase
            .from('hz_coffee_chat_activities')
            .select('*')
            .eq('id', participant.activity_id)
            .maybeSingle()
          
          if (activityError) {
            console.error('获取活动详情失败:', activityError)
            return null
          }
          
          if (activityData) {
            console.log('获取到活动详情:', activityData.title)
            const participants = await loadActivityParticipants(activityData.id)
            return { ...activityData, participants }
          }
          return null
        })
      )

      const validParticipated = participatedWithParticipants.filter(Boolean) as ActivityWithParticipants[]
      
      console.log('最终组织活动数量:', organizedWithParticipants.length)
      console.log('最终参与活动数量:', validParticipated.length)
      
      // 使用真实的数据库数据
      const finalOrganizedData = organizedWithParticipants
      
      setOrganizedActivities(finalOrganizedData)
      setParticipatedActivities(validParticipated)
    } catch (error) {
      console.error('Error loading my activities:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadActivityParticipants = async (activityId: string) => {
    try {
      console.log('加载活动参与者:', activityId)
      const { data: participantsData, error: participantsError } = await supabase
        .from('hz_activity_participants')
        .select('*')
        .eq('activity_id', activityId)

      if (participantsError) {
        console.error('获取参与者失败:', participantsError)
        return []
      }

      if (!participantsData || participantsData.length === 0) {
        console.log('暂无参与者数据')
        return []
      }

      console.log('找到参与者:', participantsData.length, '个')

      // 获取参与者用户信息
      const userIds = participantsData.map(p => p.user_id)
      const { data: usersData, error: usersError } = await supabase
        .from('hz_users')
        .select('*')
        .in('id', userIds)

      if (usersError) {
        console.error('获取用户信息失败:', usersError)
        return []
      }

      const result = participantsData.map(participant => ({
        ...participant,
        user: usersData?.find(u => u.id === participant.user_id)!
      })).filter(p => p.user)
      
      console.log('处理后的参与者数据:', result.length, '个')
      return result
    } catch (error) {
      console.error('Error loading participants:', error)
      return []
    }
  }

  const handleParticipantAction = async (participantId: string, action: 'approve' | 'reject') => {
    console.log('开始处理参与者操作:', { participantId, action })
    setActionLoading(participantId)

    try {
      // 方法1：尝试使用Edge Function
      console.log('方法1：尝试Edge Function...')
      try {
        const { data, error } = await supabase.functions.invoke('hz-coffee-chat-management', {
          body: {
            action: action === 'approve' ? 'approve_participant' : 'reject_participant',
            participantId
          }
        })

        console.log('Edge Function响应:', { data, error })

        if (error) {
          console.error('Edge Function错误:', error)
          throw new Error(`Edge Function错误: ${error.message || JSON.stringify(error)}`)
        }

        console.log('Edge Function操作成功')
        alert(action === 'approve' ? '✅ 已批准参与' : '❌ 已拒绝参与')
        
      } catch (edgeFunctionError) {
        console.warn('Edge Function失败，尝试备选方案:', edgeFunctionError)
        
        // 方法2：直接使用Supabase客户端
        console.log('方法2：使用Supabase客户端直接更新...')
        
        const updateData = action === 'approve' 
          ? { 
              status: 'confirmed', 
              confirmed_at: new Date().toISOString() 
            }
          : { 
              status: 'rejected' 
            }
        
        console.log('更新数据:', updateData)
        
        const { data, error: updateError } = await supabase
          .from('hz_activity_participants')
          .update(updateData)
          .eq('id', participantId)
          .select()
        
        console.log('直接更新响应:', { data, error: updateError })
        
        if (updateError) {
          console.error('直接更新失败:', updateError)
          throw new Error(`直接更新失败: ${updateError.message}`)
        }
        
        console.log('直接更新成功:', data)
        alert(action === 'approve' ? '✅ 已批准参与（直接更新）' : '❌ 已拒绝参与（直接更新）')
      }
      
      // 关闭申请者详情弹窗
      if (isApplicantModalOpen) {
        setIsApplicantModalOpen(false)
        setSelectedApplicant(null)
      }
      
      // 重新加载活动数据
      console.log('重新加载活动数据...')
      await loadMyActivities()
      
    } catch (error) {
      console.error('所有方法都失败了:', error)
      
      // 显示详细的错误信息
      let errorMessage = '操作失败，请重试'
      
      if (error instanceof Error) {
        errorMessage = `操作失败: ${error.message}`
      } else if (typeof error === 'string') {
        errorMessage = `操作失败: ${error}`
      } else if (error && typeof error === 'object') {
        errorMessage = `操作失败: ${JSON.stringify(error)}`
      }
      
      alert(errorMessage)
    } finally {
      setActionLoading(null)
    }
  }

  const handleViewApplicant = (applicant: ActivityParticipant & { user: HzUser }) => {
    setSelectedApplicant(applicant)
    setIsApplicantModalOpen(true)
  }

  const handleApproveFromModal = () => {
    if (selectedApplicant) {
      handleParticipantAction(selectedApplicant.id, 'approve')
    }
  }

  const handleRejectFromModal = () => {
    if (selectedApplicant) {
      handleParticipantAction(selectedApplicant.id, 'reject')
    }
  }

  const handleDeleteActivity = (activity: ActivityWithParticipants) => {
    setActivityToDelete(activity)
    setDeleteConfirmOpen(true)
  }

  const confirmDeleteActivity = async () => {
    if (!activityToDelete || !userProfile) {
      return
    }

    console.log('开始删除活动:', { activityId: activityToDelete.id, title: activityToDelete.title })
    setDeleteLoading(true)

    try {
      // 方法1：尝试使用Edge Function删除
      console.log('方法1：尝试Edge Function删除...')
      try {
        const { data, error } = await supabase.functions.invoke('hz-coffee-chat-management', {
          body: {
            action: 'delete_activity',
            activityId: activityToDelete.id,
            organizerId: userProfile.id
          }
        })

        console.log('Edge Function删除响应:', { data, error })

        if (error) {
          console.error('Edge Function删除错误:', error)
          throw new Error(`Edge Function删除失败: ${error.message || JSON.stringify(error)}`)
        }

        console.log('Edge Function删除成功')
        
        // 显示详细的删除成功信息
        const successMessage = data?.notificationsSent 
          ? `✅ 活动删除成功！已通知 ${data.notificationsSent} 位申请者`
          : '✅ 活动删除成功！'
        alert(successMessage)
        
      } catch (edgeFunctionError) {
        console.warn('Edge Function删除失败，尝试备选方案:', edgeFunctionError)
        
        // 方法2：直接使用Supabase客户端删除
        console.log('方法2：使用Supabase客户端直接删除...')
        
        // 步骤1：验证权限（确保是活动组织者）
        console.log('验证删除权限...')
        const { data: activityCheck, error: checkError } = await supabase
          .from('hz_coffee_chat_activities')
          .select('id, title, organizer_id')
          .eq('id', activityToDelete.id)
          .eq('organizer_id', userProfile.id)
          .single()
        
        console.log('权限检查结果:', { activityCheck, checkError })
        
        if (checkError || !activityCheck) {
          throw new Error('无权限删除此活动或活动不存在')
        }
        
        // 步骤2：删除参与者记录
        console.log('删除参与者记录...')
        const { error: participantsDeleteError } = await supabase
          .from('hz_activity_participants')
          .delete()
          .eq('activity_id', activityToDelete.id)
        
        console.log('删除参与者记录结果:', { error: participantsDeleteError })
        
        if (participantsDeleteError) {
          console.warn('删除参与者记录失败，继续删除活动:', participantsDeleteError)
        } else {
          console.log('参与者记录删除成功')
        }
        
        // 步骤3：删除活动记录
        console.log('删除活动记录...')
        const { error: activityDeleteError } = await supabase
          .from('hz_coffee_chat_activities')
          .delete()
          .eq('id', activityToDelete.id)
          .eq('organizer_id', userProfile.id)
        
        console.log('删除活动记录结果:', { error: activityDeleteError })
        
        if (activityDeleteError) {
          console.error('直接删除活动失败:', activityDeleteError)
          throw new Error(`直接删除失败: ${activityDeleteError.message}`)
        }
        
        console.log('直接删除成功')
        alert('✅ 活动删除成功！（直接删除）')
      }
      
      // 关闭确认对话框
      setDeleteConfirmOpen(false)
      setActivityToDelete(null)
      
      // 重新加载活动列表
      console.log('重新加载活动列表...')
      await loadMyActivities()
      
    } catch (error) {
      console.error('所有删除方法都失败了:', error)
      
      // 显示详细的错误信息
      let errorMessage = '删除活动失败，请重试'
      
      if (error instanceof Error) {
        errorMessage = `删除失败: ${error.message}`
      } else if (typeof error === 'string') {
        errorMessage = `删除失败: ${error}`
      } else if (error && typeof error === 'object') {
        errorMessage = `删除失败: ${JSON.stringify(error)}`
      }
      
      alert(errorMessage)
    } finally {
      setDeleteLoading(false)
    }
  }

  const cancelDeleteActivity = () => {
    setDeleteConfirmOpen(false)
    setActivityToDelete(null)
  }



  const createActivity = async () => {
    if (!userProfile) {
      toast.error('用户信息不存在，请刷新页面')
      return
    }

    // 验证表单
    if (!formData.title || !formData.startDate || !formData.startTime) {
      toast.error('请填写必要信息：活动主题、开始日期、开始时间')
      return
    }

    if (!selectedLocation) {
      toast.error('请选择活动地点')
      return
    }

    try {
      console.log('开始创建活动，用户ID:', userProfile.id)
      console.log('表单数据:', formData)
      
      const startDateTime = new Date(`${formData.startDate}T${formData.startTime}`).toISOString()
      const endDateTime = formData.endDate && formData.endTime
        ? new Date(`${formData.endDate}T${formData.endTime}`).toISOString()
        : new Date(new Date(startDateTime).getTime() + 2 * 60 * 60 * 1000).toISOString() // 默认2小时

      console.log('时间转换:', { startDateTime, endDateTime })
      
      const createPayload = {
        action: 'create_activity',
        organizerId: userProfile.id,
        title: formData.title,
        description: formData.description,
        startDatetime: startDateTime,
        endDatetime: endDateTime,
        location: {
          country: formData.country,
          province: formData.province,
          city: formData.city || extractCityFromAddress(selectedLocation.address),
          address: formData.address || selectedLocation.address,
          detailed_address: formData.detailedAddress || selectedLocation.address,
          // 新增地点定位信息
          location_name: selectedLocation.name,
          latitude: selectedLocation.latitude,
          longitude: selectedLocation.longitude,
          place_id: selectedLocation.place_id
        },
        maxParticipants: formData.maxParticipants,
        goal: formData.goal,
        targetTags: formData.targetTags ? formData.targetTags.split(',').map(t => t.trim()) : []
      }
      
      console.log('创建活动请求载荷:', createPayload)

      const { data, error } = await supabase.functions.invoke('hz-coffee-chat-management', {
        body: createPayload
      })

      console.log('创建活动响应:', { data, error })

      if (error) {
        console.error('创建活动失败:', error)
        toast.error('创建活动失败：' + error.message)
        return
      }

      toast.success('🎉 活动创建成功！')
      setShowCreateForm(false)
      // 重置状态
      setSelectedLocation(null)
      setFormData({
        title: '',
        description: '',
        startDate: '',
        startTime: '',
        endDate: '',
        endTime: '',
        country: '国内',
        province: '',
        city: '',
        address: '',
        detailedAddress: '',
        maxParticipants: 4,
        goal: '',
        targetTags: ''
      })
      
      // 重新加载活动列表
      await loadMyActivities()
    } catch (error) {
      console.error('Error creating activity:', error)
      toast.error('创建活动失败：' + (error.message || '未知错误'))
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin">
          <HzSymbol size={32} />
        </div>
      </div>
    )
  }

  return (
    <div className="p-8 max-w-6xl mx-auto">
      {/* 标题和操作 */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            我的 Coffee Chat
          </h1>
          <p className="text-gray-600">管理你的活动和参与记录</p>
        </div>
      </div>

      {/* VIP状态显示 */}
      <div className="mb-8">
        <VipStatusDisplay showUpgradeButton={true} />
      </div>

      {/* 创建活动按钮区域 */}
      <div className="mb-8">
        <div className="flex justify-start md:justify-end">
          <Button
            onClick={() => setShowCreateForm(!showCreateForm)}
            variant="warm"
            className="flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>创建Coffee Chat活动</span>
          </Button>
        </div>
      </div>

      {/* 创建活动表单 */}
      {showCreateForm && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>创建新活动</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">活动主题 *</label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="请输入活动主题"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">最大人数</label>
                <Input
                  type="number"
                  min="2"
                  max="10"
                  value={formData.maxParticipants}
                  onChange={(e) => setFormData(prev => ({ ...prev, maxParticipants: parseInt(e.target.value) || 4 }))}
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">活动描述</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="描述一下活动内容..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-hz-orange-500 resize-none"
                rows={3}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">开始日期 *</label>
                <Input
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">开始时间 *</label>
                <Input
                  type="time"
                  value={formData.startTime}
                  onChange={(e) => setFormData(prev => ({ ...prev, startTime: e.target.value }))}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">结束日期 *</label>
                <Input
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">结束时间 *</label>
                <Input
                  type="time"
                  value={formData.endTime}
                  onChange={(e) => setFormData(prev => ({ ...prev, endTime: e.target.value }))}
                />
              </div>
            </div>
            
            {/* 地点选择组件 */}
            <LocationPicker
              onLocationSelect={setSelectedLocation}
              initialLocation={selectedLocation}
              placeholder="搜索咖啡厅、餐厅、会议室等活动地点..."
              className="mb-4"
            />
            
            {/* 可选的额外地址信息 */}
            {selectedLocation && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">补充地址信息（可选）</label>
                  <Input
                    value={formData.detailedAddress}
                    onChange={(e) => setFormData(prev => ({ ...prev, detailedAddress: e.target.value }))}
                    placeholder="如：3楼、靠窗位置、包间号等"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">国家/地区</label>
                  <select 
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-hz-orange-500"
                    value={formData.country}
                    onChange={(e) => setFormData(prev => ({ ...prev, country: e.target.value }))}
                  >
                    <option value="国内">国内</option>
                    <option value="国外">国外</option>
                  </select>
                </div>
              </div>
            )}
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">活动目标</label>
              <Input
                value={formData.goal}
                onChange={(e) => setFormData(prev => ({ ...prev, goal: e.target.value }))}
                placeholder="你希望通过这个活动获得什么？"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">目标标签</label>
              <Input
                value={formData.targetTags}
                onChange={(e) => setFormData(prev => ({ ...prev, targetTags: e.target.value }))}
                placeholder="用逗号分隔，如：编程,创业,设计"
              />
            </div>
            
            <div className="flex space-x-4">
              <Button onClick={createActivity} variant="warm">
                创建活动
              </Button>
              <Button onClick={() => setShowCreateForm(false)} variant="outline">
                取消
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 标签页 */}
      <div className="flex space-x-4 mb-6">
        <button
          onClick={() => setActiveTab('participated')}
          className={`px-4 py-2 rounded-md transition-colors ${
            activeTab === 'participated'
              ? 'bg-hz-orange-500 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          我参加的 ({participatedActivities.length})
        </button>
        
        <button
          onClick={() => setActiveTab('organized')}
          className={`px-4 py-2 rounded-md transition-colors ${
            activeTab === 'organized'
              ? 'bg-hz-orange-500 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          我创办的 ({organizedActivities.length})
        </button>
      </div>

      {/* 活动列表 */}
      <div className="space-y-6">
        {activeTab === 'participated' && (
          participatedActivities.length === 0 ? (
            <Card>
              <CardContent className="text-center py-16">
                <div className="text-6xl mb-4">☕</div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">暂无参加的活动</h3>
                <p className="text-gray-600">去活动列表找找心仪的活动吧！</p>
              </CardContent>
            </Card>
          ) : (
            participatedActivities.map((activity) => (
              <ActivityCard
                key={activity.id}
                activity={activity}
                isOrganizer={false}
                onParticipantAction={handleParticipantAction}
                actionLoading={actionLoading}
                onViewDetail={() => {
                  setSelectedActivity(activity)
                  setIsDetailModalOpen(true)
                }}
                onViewApplicant={handleViewApplicant}
                onDeleteActivity={undefined}
                userProfile={userProfile}
              />
            ))
          )
        )}
        
        {activeTab === 'organized' && (
          organizedActivities.length === 0 ? (
            <Card>
              <CardContent className="text-center py-16">
                <div className="text-6xl mb-4">🎆</div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">暂无创办的活动</h3>
                <p className="text-gray-600">创建你的第一个 Coffee Chat 活动吧！</p>
              </CardContent>
            </Card>
          ) : (
            organizedActivities.map((activity) => (
              <ActivityCard
                key={activity.id}
                activity={activity}
                isOrganizer={true}
                onParticipantAction={handleParticipantAction}
                actionLoading={actionLoading}
                onViewDetail={() => {
                  setSelectedActivity(activity)
                  setIsDetailModalOpen(true)
                }}
                onViewApplicant={handleViewApplicant}
                onDeleteActivity={handleDeleteActivity}
                userProfile={userProfile}
              />
            ))
          )
        )}
      </div>
      
      {/* 活动详情弹窗 */}
      <ActivityDetailModal
        activity={selectedActivity}
        isOpen={isDetailModalOpen}
        onClose={() => {
          setIsDetailModalOpen(false)
          setSelectedActivity(null)
        }}
        isOrganizer={activeTab === 'organized'}
      />
      
      {/* 申请者详情弹窗 */}
      <ApplicantDetailModal
        applicant={selectedApplicant}
        isOpen={isApplicantModalOpen}
        onClose={() => {
          setIsApplicantModalOpen(false)
          setSelectedApplicant(null)
        }}
        onApprove={handleApproveFromModal}
        onReject={handleRejectFromModal}
        actionLoading={actionLoading === selectedApplicant?.id}
      />

      {/* 删除确认对话框 - 高级设计 */}
      {deleteConfirmOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl border border-red-100">
            {/* 警告图标和标题 */}
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative">
                <div className="w-14 h-14 bg-gradient-to-br from-red-100 to-red-200 rounded-full flex items-center justify-center">
                  <Trash2 className="w-7 h-7 text-red-600" />
                </div>
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-bold">!</span>
                </div>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-gray-900 mb-1">确认删除活动</h3>
                <p className="text-sm text-gray-500">此操作无法撤销</p>
              </div>
            </div>
            
            {/* 警告内容 */}
            <div className="mb-8">
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
                <p className="text-red-800 font-medium mb-2">
                  ⚠️ 确定要删除这个Coffee Chat活动吗？
                </p>
                <p className="text-red-700 text-sm">
                  删除后将无法恢复，所有申请者将收到活动取消通知。
                </p>
              </div>
              
              {activityToDelete && (
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-3 h-3 bg-hz-orange-500 rounded-full"></div>
                    <p className="font-semibold text-gray-900">{activityToDelete.title}</p>
                  </div>
                  <div className="space-y-1 text-sm text-gray-600">
                    <p>📅 {formatDateTime(activityToDelete.start_datetime)}</p>
                    <p>📍 {activityToDelete.location_city}</p>
                    {activityToDelete.participants.length > 0 && (
                      <p className="font-medium text-red-600">
                        📧 将通知 {activityToDelete.participants.filter(p => p.user_id !== userProfile?.id).length} 位申请者
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
            
            {/* 操作按钮 */}
            <div className="flex space-x-3">
              <Button
                onClick={confirmDeleteActivity}
                disabled={deleteLoading}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-medium py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
              >
                {deleteLoading ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>删除中...</span>
                  </div>
                ) : (
                  <div className="flex items-center justify-center space-x-2">
                    <Trash2 size={18} />
                    <span>确认删除</span>
                  </div>
                )}
              </Button>
              <Button
                onClick={cancelDeleteActivity}
                disabled={deleteLoading}
                variant="outline"
                className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50 font-medium py-3 rounded-lg transition-all duration-200"
              >
                取消
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

interface ActivityCardProps {
  activity: ActivityWithParticipants
  isOrganizer: boolean
  onParticipantAction: (participantId: string, action: 'approve' | 'reject') => void
  actionLoading: string | null
  onViewDetail: () => void
  onViewApplicant?: (applicant: ActivityParticipant & { user: HzUser }) => void
  onDeleteActivity?: (activity: ActivityWithParticipants) => void
  userProfile?: HzUser | null
}

function ActivityCard({ activity, isOrganizer, onParticipantAction, actionLoading, onViewDetail, onViewApplicant, onDeleteActivity, userProfile }: ActivityCardProps) {
  const confirmedParticipants = activity.participants.filter(p => p.status === 'confirmed')
  const pendingParticipants = activity.participants.filter(p => p.status === 'pending')
  
  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-start justify-between mb-2">
              <CardTitle 
                className="text-xl cursor-pointer hover:text-hz-orange-600 transition-colors flex-1"
                onClick={onViewDetail}
              >
                {activity.title}
              </CardTitle>
              <div className="flex items-center space-x-1">
                <Button
                  onClick={onViewDetail}
                  variant="ghost"
                  size="sm"
                  className="text-gray-400 hover:text-hz-orange-600"
                >
                  <Eye size={16} />
                </Button>
                {isOrganizer && onDeleteActivity && (
                  <Button
                    onClick={() => onDeleteActivity(activity)}
                    variant="ghost"
                    size="sm"
                    className="text-gray-400 hover:text-red-600 hover:bg-red-50 transition-all duration-200 group"
                    title="删除活动"
                  >
                    <Trash2 size={16} className="group-hover:scale-110 transition-transform duration-200" />
                  </Button>
                )}
              </div>
            </div>
            
            <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
              <div className="flex items-center space-x-1">
                <Calendar size={14} />
                <span>{formatDateTime(activity.start_datetime)}</span>
              </div>
              
              <div className="flex items-center space-x-1">
                <MapPin size={14} />
                <span>{activity.location_city}</span>
              </div>
              
              <div className="flex items-center space-x-1">
                <Users size={14} />
                <span>{confirmedParticipants.length}/{activity.max_participants}人</span>
              </div>
            </div>
            
            {activity.description && (
              <p className="text-gray-700">{activity.description}</p>
            )}
          </div>
          
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
            activity.status === 'recruiting' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'
          }`}>
            {activity.status === 'recruiting' ? '招募中' : '已结束'}
          </span>
        </div>
      </CardHeader>
      
      <CardContent>
        {/* 参与者列表 */}
        {isOrganizer && (
          <div className="space-y-4">
            {/* 已确认参与者 */}
            {confirmedParticipants.length > 0 && (
              <div>
                <h4 className="font-medium text-gray-900 mb-2">已确认参与者:</h4>
                <div className="space-y-2">
                  {confirmedParticipants.map((participant) => (
                    <div key={participant.id} className="flex items-center space-x-3 p-2 bg-green-50 rounded-md">
                      <img
                        src={participant.user.avatar_url || '/avatars/default.jpg'}
                        alt={participant.user.nickname}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <span className="flex-1 text-sm font-medium">{participant.user.nickname}</span>
                      <Check className="text-green-500" size={16} />
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* 待审核参与者 */}
            {pendingParticipants.length > 0 && (
              <div>
                <h4 className="font-medium text-gray-900 mb-2">待审核申请:</h4>
                <div className="space-y-2">
                  {pendingParticipants.map((participant) => (
                    <div key={participant.id} className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-md">
                      <img
                        src={participant.user.avatar_url || '/avatars/default.jpg'}
                        alt={participant.user.nickname}
                        className="w-10 h-10 rounded-full object-cover cursor-pointer hover:ring-2 hover:ring-hz-orange-500"
                        onClick={() => onViewApplicant?.(participant)}
                        title="点击查看详情"
                      />
                      <div className="flex-1">
                        <div 
                          className="text-sm font-medium cursor-pointer hover:text-hz-orange-600 transition-colors"
                          onClick={() => onViewApplicant?.(participant)}
                        >
                          {participant.user.nickname}
                        </div>
                        <div className="text-xs text-gray-600">{participant.user.role}</div>
                        {/* 显示简略的申请问卷 */}
                        {participant.what_to_bring && (
                          <div className="text-xs text-gray-500 mt-1 truncate">
                            能带来: {participant.what_to_bring.substring(0, 30)}
                            {participant.what_to_bring.length > 30 ? '...' : ''}
                          </div>
                        )}
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button
                          onClick={() => onViewApplicant?.(participant)}
                          size="sm"
                          variant="outline"
                          className="h-8 px-2 text-xs"
                        >
                          查看
                        </Button>
                        
                        <Button
                          onClick={() => onParticipantAction(participant.id, 'approve')}
                          disabled={actionLoading === participant.id}
                          size="sm"
                          variant="warm"
                          className="h-8 px-3"
                        >
                          <Check size={14} />
                        </Button>
                        
                        <Button
                          onClick={() => onParticipantAction(participant.id, 'reject')}
                          disabled={actionLoading === participant.id}
                          size="sm"
                          variant="destructive"
                          className="h-8 px-3"
                        >
                          <X size={14} />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
        
        {/* 非组织者查看 */}
        {!isOrganizer && (
          <div className="space-y-4">
            {/* 我的申请状态 */}
            {(() => {
              const myParticipation = activity.participants.find(p => p.user_id === userProfile?.id)
              if (myParticipation) {
                return (
                  <div className="border-l-4 border-hz-orange-500 pl-4 py-2 bg-hz-orange-50 rounded-r-md">
                    <h4 className="font-medium text-gray-900 mb-2">我的申请状态:</h4>
                    <div className="flex items-center space-x-3">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        myParticipation.status === 'pending' ? 'bg-yellow-100 text-yellow-600' :
                        myParticipation.status === 'confirmed' ? 'bg-green-100 text-green-600' :
                        'bg-red-100 text-red-600'
                      }`}>
                        {myParticipation.status === 'pending' ? '⏳ 审核中' :
                         myParticipation.status === 'confirmed' ? '✅ 审核成功' : '❌ 审核失败'}
                      </span>
                      <span className="text-sm text-gray-600">
                        申请时间: {new Date(myParticipation.applied_at).toLocaleDateString('zh-CN')}
                      </span>
                      {myParticipation.confirmed_at && (
                        <span className="text-sm text-gray-600">
                          审核时间: {new Date(myParticipation.confirmed_at).toLocaleDateString('zh-CN')}
                        </span>
                      )}
                    </div>
                    {/* 显示我的申请问卷 */}
                    {(myParticipation.what_to_bring || myParticipation.what_to_get) && (
                      <div className="mt-3 space-y-2 text-sm">
                        {myParticipation.what_to_bring && (
                          <div>
                            <span className="font-medium text-gray-700">我能带来: </span>
                            <span className="text-gray-600">{myParticipation.what_to_bring}</span>
                          </div>
                        )}
                        {myParticipation.what_to_get && (
                          <div>
                            <span className="font-medium text-gray-700">我希望获得: </span>
                            <span className="text-gray-600">{myParticipation.what_to_get}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )
              }
              return null
            })()}
            
            {/* 其他参与者 */}
            {confirmedParticipants.length > 0 && (
              <div>
                <h4 className="font-medium text-gray-900 mb-2">其他参与者:</h4>
                <div className="flex flex-wrap gap-2">
                  {confirmedParticipants
                    .filter(participant => participant.user_id !== userProfile?.id)
                    .map((participant) => (
                    <div key={participant.id} className="flex items-center space-x-2 px-3 py-1 bg-gray-100 rounded-full">
                      <img
                        src={participant.user.avatar_url || '/avatars/default.jpg'}
                        alt={participant.user.nickname}
                        className="w-6 h-6 rounded-full object-cover"
                      />
                      <span className="text-sm">{participant.user.nickname}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}