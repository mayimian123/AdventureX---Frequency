import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider, useAuth } from '@/contexts/AuthContext'
import { HzFullScreenLoading } from '@/components/ui/hz-loading'
import { LandingPage } from '@/pages/LandingPage'
import { LoginPage } from '@/pages/LoginPage'
import { RegisterPage } from '@/pages/RegisterPage'
import { ProfileSetupPage } from '@/pages/ProfileSetupPage'
import { AppLayout } from '@/pages/AppLayout'
import { HomePage } from '@/pages/app/HomePage'
import { MatchPage } from '@/pages/app/MatchPage'
import { ChatPage } from '@/pages/app/ChatPage'
import { CoffeeChatJoinPage } from '@/pages/app/CoffeeChatJoinPage'
import { CoffeeChatMyPage } from '@/pages/app/CoffeeChatMyPage'
import './index.css'

// 受保护的路由组件
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()
  
  if (loading) {
    return <HzFullScreenLoading text="身份验证中" subText="正在连接到赫兹社交网络" />
  }
  
  if (!user) {
    return <Navigate to="/login" replace />
  }
  
  return <>{children}</>
}

// 公开路由组件（已登录用户不能访问）
function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()
  
  if (loading) {
    return <HzFullScreenLoading text="正在初始化" subText="欢迎来到赫兹社交世界" />
  }
  
  if (user) {
    return <Navigate to="/app" replace />
  }
  
  return <>{children}</>
}

function App() {
  return (
    <AuthProvider>
      <Router>
        {/* Toast通知组件 */}
        <Toaster
          position="top-center"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#ffffff',
              color: '#374151',
              boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
              border: '1px solid #e5e7eb',
              borderRadius: '12px',
              padding: '16px',
              fontSize: '14px',
              fontWeight: '500'
            },
            success: {
              iconTheme: {
                primary: '#10b981',
                secondary: '#ffffff'
              }
            },
            error: {
              iconTheme: {
                primary: '#ef4444',
                secondary: '#ffffff'
              }
            }
          }}
        />
        
        <Routes>
          {/* 公开页面 */}
          <Route path="/" element={
            <PublicRoute>
              <LandingPage />
            </PublicRoute>
          } />
          
          <Route path="/login" element={
            <PublicRoute>
              <LoginPage />
            </PublicRoute>
          } />
          
          <Route path="/register" element={
            <PublicRoute>
              <RegisterPage />
            </PublicRoute>
          } />
          
          {/* 资料完善页面 */}
          <Route path="/profile-setup" element={
            <ProtectedRoute>
              <ProfileSetupPage />
            </ProtectedRoute>
          } />
          
          {/* 主应用页面 */}
          <Route path="/app" element={
            <ProtectedRoute>
              <AppLayout />
            </ProtectedRoute>
          }>
            <Route index element={<HomePage />} />
            <Route path="match" element={<MatchPage />} />
            <Route path="chat" element={<ChatPage />} />
            <Route path="coffee-join" element={<CoffeeChatJoinPage />} />
            <Route path="coffee-my" element={<CoffeeChatMyPage />} />
          </Route>
          
          {/* 默认重定向 */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  )
}

export default App