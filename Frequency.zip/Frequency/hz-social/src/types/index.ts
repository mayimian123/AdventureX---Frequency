// 用户类型定义
export interface HzUser {
  id: string
  auth_user_id?: string
  email: string
  nickname: string
  age: number
  avatar_url?: string
  location_country?: string
  location_province?: string
  location_city?: string
  role?: string
  current_activity?: string
  professional_fields: string[]
  interest_tags: string[]
  about_me?: string
  is_profile_complete: boolean
  created_at: string
  updated_at: string
}

// 匹配类型定义
export interface Match {
  user: HzUser
  score: number
}

// 对话类型定义
export interface Conversation {
  id: string
  participant1_id: string
  participant2_id: string
  last_message_at: string
  created_at: string
  updated_at: string
}

// 消息类型定义
export interface Message {
  id: string
  conversation_id: string
  sender_id: string
  content: string
  message_type: string
  is_read: boolean
  created_at: string
}

// Coffee Chat活动类型定义
export interface CoffeeChatActivity {
  id: string
  title: string
  organizer_id: string
  description?: string
  start_datetime: string
  end_datetime: string
  location_country?: string
  location_province?: string
  location_city?: string
  location_address?: string
  location_detailed_address?: string
  // 新增地点定位字段
  location_name?: string
  latitude?: string
  longitude?: string
  place_id?: string
  // 距离计算字段（运行时添加）
  distance_km?: number
  distance_display?: string
  max_participants: number
  current_participants: number
  goal?: string
  target_tags: string[]
  status: string
  created_at: string
  updated_at: string
}

// 活动参与者类型定义
export interface ActivityParticipant {
  id: string
  activity_id: string
  user_id: string
  status: string
  applied_at: string
  confirmed_at?: string
  what_to_bring?: string
  what_to_get?: string
  created_at: string
}

// 地址类型定义
export interface LocationType {
  country: string
  province: string
  city: string
  address?: string
  detailed_address?: string
}