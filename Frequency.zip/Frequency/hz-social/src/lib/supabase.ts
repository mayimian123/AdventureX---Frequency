import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://xyjsbpahmcisxvydbkxr.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh5anNicGFobWNpc3h2eWRia3hyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNjcwMDUsImV4cCI6MjA2ODk0MzAwNX0.DWMcfP28qQKCVmhJvrFyU1ROglbtKaPPRlQSPQemwTI'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Helper function to get current user
export async function getCurrentUser() {
  const { data: { user }, error } = await supabase.auth.getUser()
  if (error) {
    console.error('Error getting user:', error)
    return null
  }
  return user
}

// Helper function to get user profile
export async function getUserProfile(userId: string) {
  const { data, error } = await supabase
    .from('hz_users')
    .select('*')
    .eq('id', userId)
    .maybeSingle()
  
  if (error) {
    console.error('Error getting user profile:', error)
    return null
  }
  
  return data
}