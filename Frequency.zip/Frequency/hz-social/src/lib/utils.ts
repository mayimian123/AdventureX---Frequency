import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// 格式化时间
export function formatTime(dateString: string): string {
  const date = new Date(dateString)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  
  const minutes = Math.floor(diff / (1000 * 60))
  const hours = Math.floor(diff / (1000 * 60 * 60))
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  
  if (minutes < 1) return '刚刚'
  if (minutes < 60) return `${minutes}分钟前`
  if (hours < 24) return `${hours}小时前`
  if (days < 7) return `${days}天前`
  
  return date.toLocaleDateString('zh-CN')
}

// 格式化日期时间
export function formatDateTime(dateString: string): string {
  const date = new Date(dateString)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// 获取匹配度颜色
export function getMatchScoreColor(score: number): string {
  if (score >= 80) return 'text-hz-orange-500'
  if (score >= 50) return 'text-gray-600'
  return 'text-gray-400'
}

// 获取匹配度背景色
export function getMatchScoreBgColor(score: number): string {
  if (score >= 80) return 'bg-hz-orange-50 border-hz-orange-200'
  if (score >= 50) return 'bg-gray-50 border-gray-200'
  return 'bg-gray-50 border-gray-100'
}