/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // Hz温暖品牌色彩
        hz: {
          // 温暖橙色系
          orange: {
            DEFAULT: '#F97316',  // 主品牌色
            50: '#FFF7ED',
            100: '#FFEDD5',
            200: '#FED7AA',
            300: '#FDBA74',
            400: '#FB923C',
            500: '#F97316',     // 主品牌色
            600: '#EA580C',     // 强调深橙
            700: '#C2410C',
            800: '#9A3412',
            900: '#7C2D12',
          },
          // 社交温暖色系
          warm: {
            bg: '#FEF7F0',      // 主背景暖白
            surface: '#FFFFFF',  // 卡片背景纯白
            border: '#FED7AA',   // 边框浅橙
            text: {
              primary: '#1F2937',   // 主要文字深灰
              secondary: '#4B5563', // 次要文字中灰
              muted: '#9CA3AF',     // 辅助文字浅灰
            },
            social: {
              warm: '#FEF3C7',    // 温暖背景
              active: '#F59E0B',  // 活跃状态
              offline: '#D1D5DB', // 离线状态
            }
          },
          // 功能色系
          success: '#10B981',
          warning: '#F59E0B',
          error: '#EF4444',
          // 保留部分灰色系
          gray: {
            50: '#FAFAFA',
            100: '#F5F5F5',
            200: '#EEEEEE',
            300: '#E0E0E0',
            400: '#BDBDBD',
            500: '#9E9E9E',
            600: '#757575',
            700: '#616161',
            800: '#424242',
            900: '#212121',
          }
        }
      },
      borderRadius: {
        lg: "var(--radius-lg)",    // 20px
        DEFAULT: "var(--radius)",  // 16px
        md: "var(--radius-sm)",    // 12px
        sm: "calc(var(--radius) - 4px)", // 12px
      },
      fontFamily: {
        'warm': ['Nunito', 'PingFang SC', 'sans-serif'],
        'accent': ['Poppins', 'sans-serif'],
        'primary': ['var(--font-primary)'],
      },
      spacing: {
        'intimate': 'var(--spacing-intimate)', // 12px
        'cozy': 'var(--spacing-cozy)',         // 20px
        'warm': 'var(--spacing-warm)',         // 28px
        // 安全区域支持
        'safe-area-inset-top': 'env(safe-area-inset-top)',
        'safe-area-inset-bottom': 'env(safe-area-inset-bottom)',
        'safe-area-inset-left': 'env(safe-area-inset-left)',
        'safe-area-inset-right': 'env(safe-area-inset-right)',
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "wave": {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        "pulse-hz": {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '0.7', transform: 'scale(1.05)' },
        }
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "wave": "wave 2s ease-in-out infinite",
        "pulse-hz": "pulse-hz 2s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}